--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:21:51

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96762 (class 0 OID 62740617)
-- Dependencies: 23218
-- Data for Name: st_vw_linienmarkierungen; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_linienmarkierungen (id, betriebsstatus, medium, eigentuemer, min_length, spacing, symbol, grose, schrichbreite, fullfarbe, symbol2, grose2, schrichbreite2, fullfarbe2, versatz_x2, id_st_vw_projekt, abstand_start, abstand_ende) VALUES ('16fa9b93-397f-4536-a92b-85dbaa8c557e', '{ib,st,aube}', '{KR_SIL,KR_SIGL}', NULL, 8, 4, 'circle', '0.8', '0.1', 'white', 'line', '0.8', '0.18', 'white', '0.5,0', '00000000-0000-0000-0000-000000000000', 0, 1);
INSERT INTO verundentsorgung.st_vw_linienmarkierungen (id, betriebsstatus, medium, eigentuemer, min_length, spacing, symbol, grose, schrichbreite, fullfarbe, symbol2, grose2, schrichbreite2, fullfarbe2, versatz_x2, id_st_vw_projekt, abstand_start, abstand_ende) VALUES ('cf6eab7b-c329-4238-b946-1cb1000761b1', '{ib,st,aube}', '{KR_DRL,KR_DRGL}', NULL, 10, 4, 'circle', '0.5', '0.1', 'transparent', '', '0', '0', 'transparent', '0,0', '00000000-0000-0000-0000-000000000000', 0, 0);
INSERT INTO verundentsorgung.st_vw_linienmarkierungen (id, betriebsstatus, medium, eigentuemer, min_length, spacing, symbol, grose, schrichbreite, fullfarbe, symbol2, grose2, schrichbreite2, fullfarbe2, versatz_x2, id_st_vw_projekt, abstand_start, abstand_ende) VALUES ('d1e2a310-ee6c-4655-a00c-2dcb404a6a02', '{ib,st,aube}', '{KR_SEL_RI}', NULL, 0, 4, 'square', '0.8', '0', 'white', 'line', '0', '0', 'white', '0.5,0', '00000000-0000-0000-0000-000000000000', 0, 0);
INSERT INTO verundentsorgung.st_vw_linienmarkierungen (id, betriebsstatus, medium, eigentuemer, min_length, spacing, symbol, grose, schrichbreite, fullfarbe, symbol2, grose2, schrichbreite2, fullfarbe2, versatz_x2, id_st_vw_projekt, abstand_start, abstand_ende) VALUES ('26908d16-ef9c-4466-83a5-23112cbec39c', '{ib,st,aube}', '{KR_SEL_MU}', NULL, 8, 4, 'circle', '0.8', '0.1', 'yellow', 'line', '0', '0', 'white', '0.5,0', '00000000-0000-0000-0000-000000000000', 0, 0);


-- Completed on 2026-09-17 14:21:53

--
-- PostgreSQL database dump complete
--


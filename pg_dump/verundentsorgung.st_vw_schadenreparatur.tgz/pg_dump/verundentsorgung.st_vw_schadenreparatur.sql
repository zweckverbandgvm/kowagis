--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:22:21

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 39686576)
-- Dependencies: 12405
-- Data for Name: st_vw_schadenreparatur; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', '', '001', '2024-11-13 10:39:50.731071+01', '2100-01-01 00:00:00+01', '2024-11-13 10:39:50.731071+01', 'unbekannt', '2024-11-13 10:39:50.731071+01', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('21a7f154-0891-42b7-bf42-c17bbb2dea27', 'unbekannt', 'Hutprofil', 'Hutprofil', NULL, '001', '2024-11-13 10:46:55.015732+01', '2100-01-01 00:00:00+01', '2024-11-13 10:46:55.015732+01', 'unbekannt', '2024-11-13 10:46:55.015732+01', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('4ecf06d9-7863-4f75-a4ed-95a251b9c8e0', 'unbekannt', 'Kurzliner', 'Kurzliner', NULL, '001', '2024-11-13 10:46:55.015732+01', '2100-01-01 00:00:00+01', '2024-11-13 10:46:55.015732+01', 'unbekannt', '2024-11-13 10:46:55.015732+01', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('a43fe6c3-9c15-4fb7-be84-d83c487b3013', 'unbekannt', 'nicht angegeben', 'nicht angegeben', NULL, '001', '2024-11-13 10:46:55.015732+01', '2100-01-01 00:00:00+01', '2024-11-13 10:46:55.015732+01', 'unbekannt', '2024-11-13 10:46:55.015732+01', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('c40b3180-f5dd-4909-a4c5-7ea58dbda30a', 'unbekannt', 'Quick-Lock Manschette', 'Quick-Lock Manschette', NULL, '001', '2024-11-13 10:46:55.015732+01', '2100-01-01 00:00:00+01', '2024-11-13 10:46:55.015732+01', 'unbekannt', '2024-11-13 10:46:55.015732+01', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('fbc6783c-5920-480e-bbed-adc4deca1307', 'unbekannt', 'unbekannt', 'unbekannt', '', '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('7cab62a8-ac03-4500-9a46-255995b58507', 'unbekannt', 'Hutprofil', 'Hutprofil', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('787c3cdb-56dd-4570-a81c-36ffcdc89b23', 'unbekannt', 'Kurzliner', 'Kurzliner', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('98a82cc3-f34d-4716-9388-769e98f19bf9', 'unbekannt', 'nicht angegeben', 'nicht angegeben', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('4861d6e4-23a8-4a02-8f99-ddc170960144', 'unbekannt', 'Quick-Lock Manschette', 'Quick-Lock Manschette', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('fc20834b-4bea-429f-9d79-d0db1de8db21', 'unbekannt', 'unbekannt', 'unbekannt', '', '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('356f31c1-e261-4554-b3e9-0f78cd04d0c1', 'unbekannt', 'Hutprofil', 'Hutprofil', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('7b89218a-bac2-4b17-afb0-8d682562627f', 'unbekannt', 'Kurzliner', 'Kurzliner', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('24e3b265-f79c-4ac4-956d-00d73f2c9f67', 'unbekannt', 'nicht angegeben', 'nicht angegeben', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_schadenreparatur (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('3ff12060-7d1c-4196-bf2f-e83d8291b858', 'unbekannt', 'Quick-Lock Manschette', 'Quick-Lock Manschette', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:22:23

--
-- PostgreSQL database dump complete
--


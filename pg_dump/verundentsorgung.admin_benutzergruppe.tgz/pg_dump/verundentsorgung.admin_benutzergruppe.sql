--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:18:44

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96763 (class 0 OID 50119745)
-- Dependencies: 21428
-- Data for Name: admin_benutzergruppe; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.admin_benutzergruppe (id, benutzergruppe, beschreibung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('9750204a-cc40-41e9-b2db-107681164770', 'verundentsorgung_viewer_zkwal_gruppe', 'unbekannt', '2025-08-14 09:25:04.309238+02', '2100-01-01 00:00:00+01', '2025-08-14 09:25:04.309238+02', 'unbekannt', '2025-08-14 09:25:04.309238+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.admin_benutzergruppe (id, benutzergruppe, beschreibung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('21574301-d47f-4ba7-9fa1-48ef4904ebeb', 'verundentsorgung_erfasser_aw_zvg_gruppe', 'unbekannt', '2025-08-14 09:25:04.309238+02', '2100-01-01 00:00:00+01', '2025-08-14 09:25:04.309238+02', 'unbekannt', '2025-08-14 09:25:04.309238+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.admin_benutzergruppe (id, benutzergruppe, beschreibung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('e287b4ce-df07-4b0d-bcec-93bae98f5768', 'verundentsorgung_viewer_zvg_gruppe', 'unbekannt', '2025-08-14 09:25:04.309238+02', '2100-01-01 00:00:00+01', '2025-08-14 09:25:04.309238+02', 'unbekannt', '2025-08-14 09:25:04.309238+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.admin_benutzergruppe (id, benutzergruppe, beschreibung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('58eb42ed-ed16-4e2a-90d3-88e1cf4f0197', 'verundentsorgung_erfasser_so_zvg_gruppe', 'unbekannt', '2025-08-14 09:25:04.309238+02', '2100-01-01 00:00:00+01', '2025-08-14 09:25:04.309238+02', 'unbekannt', '2025-08-14 09:25:04.309238+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.admin_benutzergruppe (id, benutzergruppe, beschreibung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('20bf2ffd-c268-4e0b-8571-8914f5a8233d', 'verundentsorgung_erfasser_ta_zvg_gruppe', 'unbekannt', '2025-08-14 09:25:04.309238+02', '2100-01-01 00:00:00+01', '2025-08-14 09:25:04.309238+02', 'unbekannt', '2025-08-14 09:25:04.309238+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.admin_benutzergruppe (id, benutzergruppe, beschreibung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('a17076bf-159b-4472-b3c5-1f14877fd73f', 'verundentsorgung_viewer_zvwis_gruppe', 'unbekannt', '2025-08-14 09:25:04.309238+02', '2100-01-01 00:00:00+01', '2025-08-14 09:25:04.309238+02', 'unbekannt', '2025-08-14 09:25:04.309238+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.admin_benutzergruppe (id, benutzergruppe, beschreibung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('f855e317-ff65-4e93-a26c-14bc592e3a86', 'verundentsorgung_erfasser_zvg_gruppe', 'unbekannt', '2025-08-14 09:25:04.309238+02', '2100-01-01 00:00:00+01', '2025-08-14 09:25:04.309238+02', 'unbekannt', '2025-08-14 09:25:04.309238+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.admin_benutzergruppe (id, benutzergruppe, beschreibung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('86f27f3d-aad6-4b4a-aef2-f77ab06adbf8', 'verundentsorgung_erfasser_wa_zvg_gruppe', 'unbekannt', '2025-08-14 09:25:04.309238+02', '2100-01-01 00:00:00+01', '2025-08-14 09:25:04.309238+02', 'unbekannt', '2025-08-14 09:25:04.309238+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.admin_benutzergruppe (id, benutzergruppe, beschreibung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('e3f1409c-6492-4a50-b1fa-036a76e48b5e', 'verundentsorgung_erfasser_al_zvg_gruppe', 'unbekannt', '2025-08-14 09:25:04.309238+02', '2100-01-01 00:00:00+01', '2025-08-14 09:25:04.309238+02', 'unbekannt', '2025-08-14 09:25:04.309238+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.admin_benutzergruppe (id, benutzergruppe, beschreibung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('425e3d95-3381-47ed-90f6-d87f54f0a5da', 'verundentsorgung_erfasser_ka_zvg_gruppe', 'unbekannt', '2025-08-14 09:25:04.309238+02', '2100-01-01 00:00:00+01', '2025-08-14 09:25:04.309238+02', 'unbekannt', '2025-08-14 09:25:04.309238+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');


-- Completed on 2026-09-17 14:18:46

--
-- PostgreSQL database dump complete
--


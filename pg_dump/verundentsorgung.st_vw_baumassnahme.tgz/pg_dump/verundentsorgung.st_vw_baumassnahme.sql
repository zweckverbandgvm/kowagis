--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:19:58

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 66362681)
-- Dependencies: 24713
-- Data for Name: st_vw_baumassnahme; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_baumassnahme (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2026-06-12 14:08:03.581817+02', '2100-01-01 00:00:00+01', '2026-06-12 14:08:03.581817+02', 'unbekannt', '2026-06-12 14:08:03.581817+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_baumassnahme (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000003', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2026-06-12 14:08:30.727453+02', '2100-01-01 00:00:00+01', '2026-06-12 14:08:30.727453+02', 'unbekannt', '2026-06-12 14:08:30.727453+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_baumassnahme (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('4933b01b-6e70-4ce7-8224-4c3e2059a2c5', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:20:00

--
-- PostgreSQL database dump complete
--


--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:19:41

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96767 (class 0 OID 39684850)
-- Dependencies: 12321
-- Data for Name: st_suche__nach_name_number; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--



-- Completed on 2026-09-17 14:19:43

--
-- PostgreSQL database dump complete
--


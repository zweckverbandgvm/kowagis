--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:20:05

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 39684973)
-- Dependencies: 12328
-- Data for Name: st_vw_beckenfunktion; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2024-07-29 13:24:56.729483+02', '2100-01-01 00:00:00+01', '2024-07-29 13:24:56.729483+02', 'unbekannt', '2024-07-29 13:24:56.729483+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('7e591dea-07d8-417c-95cc-dcfddb4dd42f', 'unbekannt', 'RRG', 'Regenrückhaltegraben', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('c51d5123-5534-44b3-9fa2-d65e35011f62', 'unbekannt', 'tbd', 'noch festzulegen', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('399c9f5c-4bc3-463d-bd2d-96822b378dbf', 'unbekannt', 'RKBOD', 'Regenklärbecken ohne Dauerstau', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('46c7d8e3-72f7-4142-8a63-45e20ddd8b76', 'unbekannt', 'RRB', 'Regenrückhaltebecken', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('78df78a3-8116-494d-9e23-bd44d3875b50', 'unbekannt', 'o', 'andere', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('29aabe8f-44e8-4e5d-abdd-7c305ca45188', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2024-07-29 13:24:56.729483+02', '2100-01-01 00:00:00+01', '2024-07-29 13:24:56.729483+02', 'unbekannt', '2024-07-29 13:24:56.729483+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('01d6ec3b-c4c2-4f5c-b02c-2d3b944f9994', 'unbekannt', 'RRG', 'Regenrückhaltegraben', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('b7c03634-69ee-4a62-88b3-d47ccbf3935c', 'unbekannt', 'tbd', 'noch festzulegen', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('383e81f0-1cf0-4280-8b9c-1a7be3200291', 'unbekannt', 'RKBOD', 'Regenklärbecken ohne Dauerstau', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('fc7294c5-32b6-48fc-aa05-f1dadeb1dd0a', 'unbekannt', 'RRB', 'Regenrückhaltebecken', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('3e04167d-d7d0-4471-ae10-d483fcddf802', 'unbekannt', 'o', 'andere', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('75eec712-d87d-494c-91df-c0b4fb8b2168', 'unbekannt', 'RUEB
', 'Regenüberlaufbecken
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('1f6a5387-a334-43d9-9a79-119e89492e2a', 'unbekannt', 'RKBMD
', 'Regenklärbecken mit Dauerstau
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('d21b0190-9793-4f51-a17e-0f31bc389b74', 'unbekannt', 'RRSB
', 'Regenrückstaubecken
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('57ac1e84-7a95-40e6-a074-99f17388ae87', 'unbekannt', 'MFVR
', 'Mechanischer Retentionsfilter mit vorgeschalteter Retention
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('9e15414c-9d4f-4214-978c-095176c79b23', 'unbekannt', 'MRF
', 'Mechanischer Retetionsfilter
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('5b18e883-05bb-4f6f-b606-dd9355fbab6d', 'unbekannt', 'BFVR
', 'Bodenfilter mit vorgeschalteter Retention
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('5b5522c0-eea7-4213-b46f-d2bcd8bc3d0f', 'unbekannt', 'RBF
', 'Retentionsbodenfilter
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('7cec1525-40ac-4533-bbf0-74b704b1ab8c', 'unbekannt', 'RUEB
', 'Regenüberlaufbecken
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('e9a65c7c-28e0-4249-bb2a-36b028683cfa', 'unbekannt', 'RKBMD
', 'Regenklärbecken mit Dauerstau
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('2089d526-be6c-4207-8300-87be7d9c97e1', 'unbekannt', 'RRSB
', 'Regenrückstaubecken
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('0384da6c-8ad2-4470-85a8-91d5410d3f31', 'unbekannt', 'MFVR
', 'Mechanischer Retentionsfilter mit vorgeschalteter Retention
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('f7b11881-f452-4e82-8a95-90dae23015e2', 'unbekannt', 'MRF
', 'Mechanischer Retetionsfilter
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('fa6bf372-0d68-430d-a25b-c9fb6b2776f6', 'unbekannt', 'BFVR
', 'Bodenfilter mit vorgeschalteter Retention
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('a8cff183-b939-4496-9240-5191ba7cb430', 'unbekannt', 'RBF
', 'Retentionsbodenfilter
', NULL, '001', '2024-07-29 14:49:05.350311+02', '2100-01-01 00:00:00+01', '2024-07-29 14:49:05.350311+02', 'unbekannt', '2024-07-29 14:49:05.350311+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('1aa358fe-8c4d-407c-9b13-fe1d1ff95953', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('c0c5b6d6-6f9d-4935-b349-263bfab834d0', 'unbekannt', 'RRG', 'Regenrückhaltegraben', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('008af33f-4f5b-4a7c-be47-2094692e3544', 'unbekannt', 'tbd', 'noch festzulegen', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('b8fed8aa-b648-4d9a-9259-cc7028d1fa63', 'unbekannt', 'RKBOD', 'Regenklärbecken ohne Dauerstau', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('a80e8424-74c3-4e62-9739-fcf9a12c5101', 'unbekannt', 'RRB', 'Regenrückhaltebecken', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('213c83b8-5cc2-42b0-a62b-e1f12f854ed7', 'unbekannt', 'o', 'andere', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('871ca5b1-e76c-4841-8c99-59e2b8cfb2f9', 'unbekannt', 'RUEB
', 'Regenüberlaufbecken
', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('2dc6661d-32dd-4fae-a77d-00b2bc408b69', 'unbekannt', 'RKBMD
', 'Regenklärbecken mit Dauerstau
', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('80401d65-629b-4832-a1ce-397ada856861', 'unbekannt', 'RRSB
', 'Regenrückstaubecken
', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('0a8d80e4-5fc6-40b8-91af-6c28824869ea', 'unbekannt', 'MFVR
', 'Mechanischer Retentionsfilter mit vorgeschalteter Retention
', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('19f6e114-d0f7-43f0-bdc6-62eb0695adc9', 'unbekannt', 'MRF
', 'Mechanischer Retetionsfilter
', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('fbd494c2-b5a9-4170-991d-ac3b2071a19d', 'unbekannt', 'BFVR
', 'Bodenfilter mit vorgeschalteter Retention
', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beckenfunktion (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('07191fb1-f7b3-4934-8263-109cf5427e7c', 'unbekannt', 'RBF
', 'Retentionsbodenfilter
', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:20:06

--
-- PostgreSQL database dump complete
--


--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:22:40

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 44380726)
-- Dependencies: 16544
-- Data for Name: st_vw_typ2objektklasse; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_typ2objektklasse (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2025-07-02 12:04:07.709598+02', '2100-01-01 00:00:00+01', '2025-07-02 12:04:07.709598+02', 'unbekannt', '2025-07-02 12:04:07.709598+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'unbekannt', 'unbekannt');
INSERT INTO verundentsorgung.st_vw_typ2objektklasse (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name) VALUES ('da171de5-0245-482d-9b6a-f993223ed605', 'unbekannt', 'id_st_vw_schacht_typ', 'st_vw_schacht_typ', NULL, '001', '2025-03-18 10:21:24.53808+01', '2100-01-01 00:00:00+01', '2025-03-18 10:21:24.53808+01', 'unbekannt', '2025-03-18 10:21:24.53808+01', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schacht');
INSERT INTO verundentsorgung.st_vw_typ2objektklasse (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name) VALUES ('8195af76-6bc4-421c-8aac-ae325e2631f2', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2025-07-02 12:04:07.709598+02', '2100-01-01 00:00:00+01', '2025-07-02 12:04:07.709598+02', 'unbekannt', '2025-07-02 12:04:07.709598+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'unbekannt', 'unbekannt');
INSERT INTO verundentsorgung.st_vw_typ2objektklasse (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name) VALUES ('4e24e9ba-9ac4-4098-a46d-b1261e531966', 'unbekannt', 'id_st_vw_schacht_typ', 'st_vw_schacht_typ', NULL, '001', '2025-03-18 10:21:24.53808+01', '2100-01-01 00:00:00+01', '2025-03-18 10:21:24.53808+01', 'unbekannt', '2025-03-18 10:21:24.53808+01', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schacht');
INSERT INTO verundentsorgung.st_vw_typ2objektklasse (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name) VALUES ('6d2074c7-cbf7-4490-b4b8-853a79ea5e02', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2025-07-02 12:04:07.709598+02', '2100-01-01 00:00:00+01', '2025-07-02 12:04:07.709598+02', 'unbekannt', '2025-07-02 12:04:07.709598+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'unbekannt', 'unbekannt');
INSERT INTO verundentsorgung.st_vw_typ2objektklasse (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name) VALUES ('8c2b11e5-9d79-453b-a028-15615fde6567', 'unbekannt', 'id_st_vw_schacht_typ', 'st_vw_schacht_typ', NULL, '001', '2025-03-18 10:21:24.53808+01', '2100-01-01 00:00:00+01', '2025-03-18 10:21:24.53808+01', 'unbekannt', '2025-03-18 10:21:24.53808+01', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schacht');


-- Completed on 2026-09-17 14:22:42

--
-- PostgreSQL database dump complete
--


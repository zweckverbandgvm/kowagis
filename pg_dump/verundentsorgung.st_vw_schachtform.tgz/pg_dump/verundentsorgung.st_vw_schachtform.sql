--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:22:19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 39685601)
-- Dependencies: 12363
-- Data for Name: st_vw_schachtform; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2024-08-05 07:44:10.170837+02', '2100-01-01 00:00:00+01', '2024-08-05 07:44:10.170837+02', 'unbekannt', '2024-08-05 07:44:10.170837+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('26fb7987-e36d-4d8d-8a13-532118167dda', 'unbekannt', 'Z', 'andere', NULL, '001', '2024-08-05 08:29:46.148659+02', '2100-01-01 00:00:00+01', '2024-08-05 08:29:46.148659+02', 'unbekannt', '2024-08-05 08:29:46.148659+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('19a4bf0b-544c-4398-b8d7-1c794cb2906b', 'unbekannt', 'Q', 'quadratisch', NULL, '001', '2024-08-05 08:29:46.148659+02', '2100-01-01 00:00:00+01', '2024-08-05 08:29:46.148659+02', 'unbekannt', '2024-08-05 08:29:46.148659+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('ee0f8a56-0482-403a-9632-12feb9eee0f4', 'unbekannt', 'R', 'rund', NULL, '001', '2024-08-05 08:29:46.148659+02', '2100-01-01 00:00:00+01', '2024-08-05 08:29:46.148659+02', 'unbekannt', '2024-08-05 08:29:46.148659+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('8aa6767f-f4aa-474c-9997-2eca2c2ea3ce', 'unbekannt', 'S', 'Sonderform', NULL, '001', '2024-08-05 08:29:46.148659+02', '2100-01-01 00:00:00+01', '2024-08-05 08:29:46.148659+02', 'unbekannt', '2024-08-05 08:29:46.148659+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('d7beb355-f1af-4fae-8b29-5b5784d0849b', 'unbekannt', 'REE', 'rechteckig', NULL, '001', '2024-08-05 08:29:46.148659+02', '2100-01-01 00:00:00+01', '2024-08-05 08:29:46.148659+02', 'unbekannt', '2024-08-05 08:29:46.148659+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('486c0c20-34fa-4422-9a00-e31e9ac52210', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('20023b12-0036-4216-b5b4-041874190134', 'unbekannt', 'Z', 'andere', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('aa301b9e-79c8-40f7-b661-428d6b641276', 'unbekannt', 'Q', 'quadratisch', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('42314b63-b070-407c-b58a-4b3b374ab9ad', 'unbekannt', 'R', 'rund', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('2c50583e-e399-4686-a15d-b89113fdf25d', 'unbekannt', 'S', 'Sonderform', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('c38e7f02-27ca-4131-8118-e5829cb23d77', 'unbekannt', 'REE', 'rechteckig', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('e3c94de2-0334-4909-bf14-a6f754f3ef44', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('515e5235-b4ff-4305-b57b-9645a2492308', 'unbekannt', 'Z', 'andere', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('c19882f3-9d03-44db-ab33-4e35484fd5b5', 'unbekannt', 'Q', 'quadratisch', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('cb35569b-331d-443f-8893-85717e93dcbd', 'unbekannt', 'R', 'rund', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('88b0ed13-3031-427e-833c-01e926e03f6d', 'unbekannt', 'S', 'Sonderform', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_schachtform (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('e5042704-1754-40eb-aac6-c4f943824ca7', 'unbekannt', 'REE', 'rechteckig', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:22:21

--
-- PostgreSQL database dump complete
--


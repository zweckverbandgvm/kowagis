--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:20:21

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 39685099)
-- Dependencies: 12335
-- Data for Name: st_vw_beschichtung; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2024-08-05 07:45:06.199544+02', '2100-01-01 00:00:00+01', '2024-08-05 07:45:06.199544+02', 'unbekannt', '2024-08-05 07:45:06.199544+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('5e37fb52-9ad1-4162-8888-623c41c04c17', 'unbekannt', 'B', 'Beschichtung', NULL, '001', '2024-08-05 08:29:46.148659+02', '2100-01-01 00:00:00+01', '2024-08-05 08:29:46.148659+02', 'unbekannt', '2024-08-05 08:29:46.148659+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('685a3bb7-ce77-43eb-a275-8e20e30ca035', 'unbekannt', 'BET', 'Beton', NULL, '001', '2024-08-05 08:29:46.148659+02', '2100-01-01 00:00:00+01', '2024-08-05 08:29:46.148659+02', 'unbekannt', '2024-08-05 08:29:46.148659+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('634334f1-62d0-4b77-a73f-de2227192fc7', 'unbekannt', 'KKIW', 'Auskleidung mit Kanalklinkern im Bereich der Wandung', NULL, '001', '2024-08-05 08:29:46.148659+02', '2100-01-01 00:00:00+01', '2024-08-05 08:29:46.148659+02', 'unbekannt', '2024-08-05 08:29:46.148659+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('76f079ab-9cfb-4275-8c2c-b4ff54aaae03', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2026-01-12 14:00:10.317734+01', '2100-01-01 00:00:00+01', '2026-01-12 14:00:10.317734+01', 'unbekannt', '2026-01-12 14:00:10.317734+01', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('fd19fcc5-a043-4a36-90c7-a2573aaa4d2a', 'unbekannt', 'B', 'Beschichtung', NULL, '001', '2026-01-12 14:00:10.317734+01', '2100-01-01 00:00:00+01', '2026-01-12 14:00:10.317734+01', 'unbekannt', '2026-01-12 14:00:10.317734+01', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('9a4f3631-0c40-4949-81d1-dba0a3c9824d', 'unbekannt', 'BET', 'Beton', NULL, '001', '2026-01-12 14:00:10.317734+01', '2100-01-01 00:00:00+01', '2026-01-12 14:00:10.317734+01', 'unbekannt', '2026-01-12 14:00:10.317734+01', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('481fbcff-e48c-4c73-acf6-4585d4572998', 'unbekannt', 'KKIW', 'Auskleidung mit Kanalklinkern im Bereich der Wandung', NULL, '001', '2026-01-12 14:00:10.317734+01', '2100-01-01 00:00:00+01', '2026-01-12 14:00:10.317734+01', 'unbekannt', '2026-01-12 14:00:10.317734+01', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('138d4f2b-8b50-4fc4-a048-c77256b6ad79', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('870f7ff3-01bc-4e90-86d2-3d9e878973c1', 'unbekannt', 'B', 'Beschichtung', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('a7aa9373-d1b0-4633-b3e2-80798a1288b6', 'unbekannt', 'BET', 'Beton', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beschichtung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('2920dfab-8a89-4d17-ae3a-f69d42eabe16', 'unbekannt', 'KKIW', 'Auskleidung mit Kanalklinkern im Bereich der Wandung', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:20:23

--
-- PostgreSQL database dump complete
--


--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:21:00

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 55072486)
-- Dependencies: 21852
-- Data for Name: st_vw_hilfsfilter; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('b62b64e5-c175-456c-a1d1-26af5fc1cbae', 'unbekannt', 'Ausgabe', 'Betriebsstatus inbetrieb, stillgelegt und außer Betrieb', '"id_st_vw_betriebsstatus" IN ( ''1329884d-a1ca-4f85-ae83-025bb5c90780'' , ''3eba2ee1-bb59-40d5-9531-52116954d6e4'', ''e3b51a21-2974-4ad3-833e-3082115fa8d4'')', 'Von Ronald', '001', '2025-11-20 10:28:00.154899+01', '2100-01-01 00:00:00+01', '2025-11-20 10:28:00.154899+01', 'unbekannt', '2025-11-20 10:28:00.154899+01', 'unbekannt', '00000000-0000-0000-0000-000000000001', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('71cc8ce9-00ee-4a9a-a09b-7979077872ca', 'unbekannt', 'Betreiber ZVG', 'Betreiber nur ZVG', '"id_st_vw_betreiber" = ''05caad03-383c-454c-9f17-f235750a2b48''', 'Von Ronald', '001', '2025-11-20 10:30:43.956306+01', '2100-01-01 00:00:00+01', '2025-11-20 10:30:43.956306+01', 'unbekannt', '2025-11-20 10:30:43.956306+01', 'unbekannt', '00000000-0000-0000-0000-000000000001', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('51851593-b7eb-4f6a-88fd-45980f5b8ab5', 'unbekannt', 'Ausgabe', 'Betriebsstatus inbetrieb, stillgelegt und außer Betrieb', '"id_st_vw_betriebsstatus" IN ( ''99b6700e-2a1c-4fa6-846f-bf1642495cc6'', ''54bfce0b-7cf8-49ef-a25c-49b544113c6f'', ''f5a9419f-90bf-419a-a3bc-15996eebf398'')', 'Von Jens', '001', '2026-01-20 07:52:05.608472+01', '2100-01-01 00:00:00+01', '2026-01-20 07:52:05.608472+01', 'unbekannt', '2026-01-20 07:52:05.608472+01', 'unbekannt', '00000000-0000-0000-0000-000000000003', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('bc26e415-5dfb-48ba-9e37-0eb776f95bcc', 'unbekannt', 'Betreiber ZVG', 'Betreiber nur ZKWAL', '"id_st_vw_betreiber" = ''10df17aa-ac4d-4dad-b659-2e30acbeb68b''', 'Von Jens', '001', '2026-01-20 07:52:05.620114+01', '2100-01-01 00:00:00+01', '2026-01-20 07:52:05.620114+01', 'unbekannt', '2026-01-20 07:52:05.620114+01', 'unbekannt', '00000000-0000-0000-0000-000000000003', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('1335bad6-238b-49d3-8439-370f4b287136', 'unbekannt', 'Planung', 'Betriebsstatus inbetrieb, stillgelegt, geplant und außer Betrieb ', '"id_st_vw_betriebsstatus" IN ( ''99b6700e-2a1c-4fa6-846f-bf1642495cc6'', ''54bfce0b-7cf8-49ef-a25c-49b544113c6f'', ''f5a9419f-90bf-419a-a3bc-15996eebf398'',''4d6b4ec5-1099-4edd-adfd-95b7b368adac'')', 'Von Jens', '001', '2026-01-20 07:52:05.622299+01', '2100-01-01 00:00:00+01', '2026-01-20 07:52:05.622299+01', 'unbekannt', '2026-01-20 07:52:05.622299+01', 'unbekannt', '00000000-0000-0000-0000-000000000003', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('c7baf3fb-88b7-41b6-b8a6-29aa569fdd0d', 'unbekannt', 'Test', 'Test', '"id_st_vw_betriebsstatus" IN ( ''1329884d-a1ca-4f85-ae83-025bb5c90780'' , ''3eba2ee1-bb59-40d5-9531-52116954d6e4'', ''e3b51a21-2974-4ad3-833e-3082115fa8d4'', ''8fb4f24b-9648-4a9a-8b08-a3d3b030d776'' )', 'Von Jens', '001', '2026-01-20 07:52:05.624172+01', '2100-01-01 00:00:00+01', '2026-01-20 07:52:05.624172+01', 'unbekannt', '2026-01-20 07:52:05.624172+01', 'unbekannt', '00000000-0000-0000-0000-000000000003', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('5752e8d8-5145-4762-9659-61df8350ff38', 'unbekannt', 'Gültig von', 'Gültig von', 'gueltig_von >= ''$1''', 'Von Dominik', '001', '2025-11-20 10:42:49.277992+01', '2100-01-01 00:00:00+01', '2025-11-20 10:42:49.277992+01', 'unbekannt', '2025-11-20 10:42:49.277992+01', 'unbekannt', '00000000-0000-0000-0000-000000000001', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('0e1f7063-1bf0-4920-a7c2-4cabc123e018', 'unbekannt', 'Planung', 'Betriebsstatus inbetrieb, stillgelegt, geplant und außer Betrieb ', '"id_st_vw_betriebsstatus" = ''8fb4f24b-9648-4a9a-8b08-a3d3b030d776''', 'Von Ronald', '001', '2025-11-20 10:42:49.277992+01', '2100-01-01 00:00:00+01', '2025-11-20 10:42:49.277992+01', 'unbekannt', '2025-11-20 10:42:49.277992+01', 'unbekannt', '00000000-0000-0000-0000-000000000001', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('21126af5-4b92-4081-a59b-ba51f9991be5', 'unbekannt', 'Ausgabe', 'Betriebsstatus inbetrieb, stillgelegt und außer Betrieb', 'unbekannt', 'Von Ronald', '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('7980c5dc-d93a-4230-be22-1ee98b8b9897', 'unbekannt', 'Betreiber ZVG', 'Betreiber nur ZVG', 'unbekannt', 'Von Ronald', '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('9aa56d92-e9fd-466f-a143-d5c881bf6493', 'unbekannt', 'Gültig von', 'Gültig von', 'unbekannt', 'Von Dominik', '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', NULL);
INSERT INTO verundentsorgung.st_vw_hilfsfilter (id, ident_hist, kurztext, langtext, filtertext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, aktiv_for) VALUES ('825f39d6-80bc-4052-9b36-f4d0e446badc', 'unbekannt', 'Planung', 'Betriebsstatus inbetrieb, stillgelegt, geplant und außer Betrieb ', 'unbekannt', 'Von Ronald', '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', NULL);


-- Completed on 2026-09-17 14:21:02

--
-- PostgreSQL database dump complete
--


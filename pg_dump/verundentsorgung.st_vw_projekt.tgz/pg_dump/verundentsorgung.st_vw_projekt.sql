--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:22:08

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 39685530)
-- Dependencies: 12359
-- Data for Name: st_vw_projekt; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_projekt (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', 'noch keine Bemerkung', '001', '2022-12-19 20:41:10.871036+01', '2100-01-01 00:00:00+01', '2022-12-19 20:41:10.871036+01', 'unbekannt', '2022-12-19 20:41:10.871036+01', 'unbekannt', '00000000-0000-0000-0000-000000000000');
INSERT INTO verundentsorgung.st_vw_projekt (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000001', 'unbekannt', 'ZVG', 'ZVG', 'noch keine Bemerkung', '001', '2022-12-19 20:41:10.871036+01', '2100-01-01 00:00:00+01', '2022-12-19 20:41:10.871036+01', 'unbekannt', '2022-12-19 20:41:10.871036+01', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_projekt (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000002', 'unbekannt', 'ZVK', 'ZVK', 'noch keine Bemerkung', '001', '2022-12-19 20:41:10.871036+01', '2100-01-01 00:00:00+01', '2022-12-19 20:41:10.871036+01', 'unbekannt', '2022-12-19 20:41:10.871036+01', 'unbekannt', '00000000-0000-0000-0000-000000000002');
INSERT INTO verundentsorgung.st_vw_projekt (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000003', 'unbekannt', 'ZKWAL', 'ZKWAL', 'noch keine Bemerkung', '001', '2022-12-19 20:41:10.871036+01', '2100-01-01 00:00:00+01', '2022-12-19 20:41:10.871036+01', 'unbekannt', '2022-12-19 20:41:10.871036+01', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_projekt (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000004', 'unbekannt', 'ZVWIS', 'ZVWIS', 'noch keine Bemerkung', '001', '2026-05-26 14:28:53.281116+02', '2100-01-01 00:00:00+01', '2026-05-26 14:28:53.281116+02', 'unbekannt', '2026-05-26 14:28:53.281116+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:22:10

--
-- PostgreSQL database dump complete
--


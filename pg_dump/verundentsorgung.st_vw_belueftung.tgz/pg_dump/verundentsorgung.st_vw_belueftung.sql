--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:20:15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 39685045)
-- Dependencies: 12332
-- Data for Name: st_vw_belueftung; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2024-07-24 08:20:14.415918+02', '2100-01-01 00:00:00+01', '2024-07-24 08:20:14.415918+02', 'unbekannt', '2024-07-24 08:20:14.415918+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('6c835081-a312-4580-a1dd-b87fb6f7ad22', 'unbekannt', 'mit Belüftungsöffnung', 'mit Belüftungsöffnung', NULL, '001', '2024-07-24 08:22:39.657917+02', '2100-01-01 00:00:00+01', '2024-07-24 08:22:39.657917+02', 'unbekannt', '2024-07-24 08:22:39.657917+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('dabf21ef-91a0-4ada-b043-4baa66cb7f41', 'unbekannt', 'mit Lüfter', 'mit Lüfter', NULL, '001', '2024-07-24 08:22:39.657917+02', '2100-01-01 00:00:00+01', '2024-07-24 08:22:39.657917+02', 'unbekannt', '2024-07-24 08:22:39.657917+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('c870c595-7090-43b5-94f3-3fb0ce4fc899', 'unbekannt', 'belüftet mit Wasserstopsystem', 'belüftet mit Wasserstopsystem', NULL, '001', '2024-07-24 08:22:39.657917+02', '2100-01-01 00:00:00+01', '2024-07-24 08:22:39.657917+02', 'unbekannt', '2024-07-24 08:22:39.657917+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('0ed23fb9-44b0-4a38-b88a-c9477c9f16b0', 'unbekannt', 'ohne Belüftungsöffnung', 'ohne Belüftungsöffnung', NULL, '001', '2024-07-24 08:22:39.657917+02', '2100-01-01 00:00:00+01', '2024-07-24 08:22:39.657917+02', 'unbekannt', '2024-07-24 08:22:39.657917+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('3de410b6-ccd7-488e-8920-219b04ed914a', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('f2a7cb57-4a00-417c-b722-a8d0dfd35efd', 'unbekannt', 'mit Belüftungsöffnung', 'mit Belüftungsöffnung', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('0e0d24a9-179e-4ca7-804d-0e60ccf0ddb0', 'unbekannt', 'mit Lüfter', 'mit Lüfter', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('b57603ce-b4bd-4633-8b2d-6100f18f3593', 'unbekannt', 'belüftet mit Wasserstopsystem', 'belüftet mit Wasserstopsystem', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('4f4129c3-b9f1-4447-8c2c-d5e0687e4f11', 'unbekannt', 'ohne Belüftungsöffnung', 'ohne Belüftungsöffnung', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('51efde34-a312-40b1-a6e9-dac996323258', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('67615c08-06b1-4432-93c8-524bcf9b8f44', 'unbekannt', 'mit Belüftungsöffnung', 'mit Belüftungsöffnung', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('7bef2db9-62e2-4793-942e-6e8e5cac1b11', 'unbekannt', 'mit Lüfter', 'mit Lüfter', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('ff09be9e-9d45-4637-85fc-f8b24d3b3d92', 'unbekannt', 'belüftet mit Wasserstopsystem', 'belüftet mit Wasserstopsystem', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_belueftung (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('86e2601f-6fb0-45af-91c0-6bcbd2c69ed7', 'unbekannt', 'ohne Belüftungsöffnung', 'ohne Belüftungsöffnung', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:20:17

--
-- PostgreSQL database dump complete
--


--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:20:36

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 39685189)
-- Dependencies: 12340
-- Data for Name: st_vw_druckminderertyp; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_druckminderertyp (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2024-08-06 10:37:54.236247+02', '2100-01-01 00:00:00+01', '2024-08-06 10:37:54.236247+02', 'unbekannt', '2024-08-06 10:37:54.236247+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_druckminderertyp (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('010b4bb7-3ef1-499b-8280-02d457f2e529', 'unbekannt', 'DREG', 'Druckminderer', NULL, '001', '2024-08-14 15:05:06.938817+02', '2100-01-01 00:00:00+01', '2024-08-14 15:05:06.938817+02', 'unbekannt', '2024-08-14 15:05:06.938817+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_druckminderertyp (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('c8064339-7855-44f3-b09d-c0675485e532', 'unbekannt', 'SIVE', 'Sicherheitsventil', NULL, '001', '2024-08-14 15:05:06.938817+02', '2100-01-01 00:00:00+01', '2024-08-14 15:05:06.938817+02', 'unbekannt', '2024-08-14 15:05:06.938817+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_druckminderertyp (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('57bcdb1d-c6f7-47d0-85ab-b07ac1f6be3d', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_druckminderertyp (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('5e4fdc31-97a2-4f19-818e-42387c75cde6', 'unbekannt', 'DREG', 'Druckminderer', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_druckminderertyp (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('fbae602d-4d27-4803-905e-fd9ea4738a73', 'unbekannt', 'SIVE', 'Sicherheitsventil', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_druckminderertyp (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('ec2acbff-e52e-4ff9-bcde-81c0fccc72ee', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_druckminderertyp (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('988b98dc-b398-41ab-9a4a-d36c5dcb22ac', 'unbekannt', 'DREG', 'Druckminderer', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_druckminderertyp (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('1521b94a-a677-4734-86f6-b57169723dac', 'unbekannt', 'SIVE', 'Sicherheitsventil', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:20:38

--
-- PostgreSQL database dump complete
--


--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:19:15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96767 (class 0 OID 39684620)
-- Dependencies: 12309
-- Data for Name: st_amt; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', 'unbekannt', 'noch keine Bemerkung', '2024-04-12 07:49:37.232665+02', '2100-01-01 00:00:00+01', '2024-04-12 07:49:37.232665+02', 'unbekannt', '2024-04-12 07:49:37.232665+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('385289b4-8d99-478e-8be8-6623ef72fe6b', '7', 'Amt Dorf Mecklenburg-Bad Kleinen', NULL, '2026-04-03 20:21:47.033715+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:47.033715+02', 'unbekannt', '2026-04-03 20:21:47.033715+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('fc1d11d6-0dd0-4d1e-a018-d6302b68560b', '2', 'Amt Grevesmühlen Land', NULL, '2026-04-03 20:21:47.033715+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:47.033715+02', 'unbekannt', '2026-04-03 20:21:47.033715+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('ce535fc1-7d60-4a1c-8aa0-dcb1575e780a', '3', 'Amt Klützer Winkel', NULL, '2026-04-03 20:21:47.033715+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:47.033715+02', 'unbekannt', '2026-04-03 20:21:47.033715+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('fb80f1bb-6670-433b-974b-61d4de74b2c2', '5352', 'Amt Neukloster-Warin', NULL, '2026-04-03 20:21:47.033715+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:47.033715+02', 'unbekannt', '2026-04-03 20:21:47.033715+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('6e413628-2d3f-46f8-84a0-c572c40dc0da', '5', 'Amt Schönberger Land', NULL, '2026-04-03 20:21:47.033715+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:47.033715+02', 'unbekannt', '2026-04-03 20:21:47.033715+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('2b57cbbe-f7fd-4cc7-a18c-70ad287c262d', '6', 'Amt Stralendorf', NULL, '2026-04-03 20:21:47.033715+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:47.033715+02', 'unbekannt', '2026-04-03 20:21:47.033715+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('edbde0c0-643d-442f-a949-6fa30ff4b6f6', '1', 'Stadt Grevesmühlen', NULL, '2026-04-03 20:21:47.033715+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:47.033715+02', 'unbekannt', '2026-04-03 20:21:47.033715+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('f3043732-e3fb-41d8-bd93-d4392f7c117a', '5242', 'Amt Rehna', NULL, '2026-04-03 20:21:47.033715+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:47.033715+02', 'unbekannt', '2026-04-03 20:21:47.033715+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('7e648ea9-c663-49f5-ab82-b26d0d505896', '00000000-0000-0000-0000-000000000003', 'unbekannt', NULL, '2026-04-03 20:21:51.018411+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:51.018411+02', 'unbekannt', '2026-04-03 20:21:51.018411+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('6768e781-674e-4389-9538-fdf2e8c9c9dd', '11699', 'Grabow', NULL, '2026-04-03 20:21:51.018411+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:51.018411+02', 'unbekannt', '2026-04-03 20:21:51.018411+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('94ffe87d-f030-42c6-8e7b-754ad7ee6a46', '11850', 'Neustadt-Glewe', NULL, '2026-04-03 20:21:51.018411+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:51.018411+02', 'unbekannt', '2026-04-03 20:21:51.018411+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('2ec334c3-9f50-4529-a735-90e6d16528d9', '11851', 'Ludwigslust-Land', NULL, '2026-04-03 20:21:51.018411+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:51.018411+02', 'unbekannt', '2026-04-03 20:21:51.018411+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('84a20edb-87f8-4200-825a-e047271c0ff3', '11852', 'Ludwigslust, Stadt', NULL, '2026-04-03 20:21:51.018411+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:51.018411+02', 'unbekannt', '2026-04-03 20:21:51.018411+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00947b76-edf0-416c-8a9b-d2c0959d25ee', '11853', 'Dömitz-Malliß', NULL, '2026-04-03 20:21:51.018411+02', '2100-01-01 00:00:00+01', '2026-04-03 20:21:51.018411+02', 'unbekannt', '2026-04-03 20:21:51.018411+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('457abee7-d363-4d21-affb-fadc5133f632', '00000000-0000-0000-0000-000000000004', 'unbekannt', NULL, '2026-08-11 07:55:21.852846+02', '2100-01-01 00:00:00+01', '2026-08-11 07:55:21.852846+02', 'unbekannt', '2026-08-11 07:55:21.852846+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('7d7dcdbe-daf3-4277-8af7-13b3eef2c214', '004', 'Insel Poel, amtsfrei', NULL, '2026-08-11 07:55:35.372313+02', '2100-01-01 00:00:00+01', '2026-08-11 07:55:35.372313+02', 'unbekannt', '2026-08-11 07:55:35.372313+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('ec19ead0-c250-49ab-b39c-88a45fdde922', '007', 'Amt Lützow-Lübstorf', NULL, '2026-08-11 07:55:35.372313+02', '2100-01-01 00:00:00+01', '2026-08-11 07:55:35.372313+02', 'unbekannt', '2026-08-11 07:55:35.372313+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('4ec7c1ce-6b02-41ac-a81a-ef2b06c44036', '001', 'Neuburg', NULL, '2026-08-11 07:55:35.372313+02', '2100-01-01 00:00:00+01', '2026-08-11 07:55:35.372313+02', 'unbekannt', '2026-08-11 07:55:35.372313+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('8de802eb-5efd-438d-a18d-4ab7275b7698', '008', 'Wismar, Stadt', NULL, '2026-08-11 07:55:35.372313+02', '2100-01-01 00:00:00+01', '2026-08-11 07:55:35.372313+02', 'unbekannt', '2026-08-11 07:55:35.372313+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('f7393bad-022d-402d-9de8-272d9c1b12a6', '074', 'Amt Dorf Mecklenburg-Bad Kleinen', NULL, '2026-08-11 07:55:35.372313+02', '2100-01-01 00:00:00+01', '2026-08-11 07:55:35.372313+02', 'unbekannt', '2026-08-11 07:55:35.372313+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('26e04fc2-7207-4557-8917-8a77d78d73ff', '003', 'Amt Grevesmühlen-Land', NULL, '2026-08-11 07:55:35.372313+02', '2100-01-01 00:00:00+01', '2026-08-11 07:55:35.372313+02', 'unbekannt', '2026-08-11 07:55:35.372313+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('dff3c143-bc8c-42a5-ae67-cb8bc54bfa94', '006', 'Amt Neukloster-Warin', NULL, '2026-08-11 07:55:35.372313+02', '2100-01-01 00:00:00+01', '2026-08-11 07:55:35.372313+02', 'unbekannt', '2026-08-11 07:55:35.372313+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_amt (id, ident_hist, amt, bemerkung, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('74301032-0e77-4395-8f56-901bc9bc3202', '002', 'Amt Klützer Winkel', NULL, '2026-08-11 07:55:35.372313+02', '2100-01-01 00:00:00+01', '2026-08-11 07:55:35.372313+02', 'unbekannt', '2026-08-11 07:55:35.372313+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:19:17

--
-- PostgreSQL database dump complete
--


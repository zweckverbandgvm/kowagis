--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:19:13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96760 (class 0 OID 39686892)
-- Dependencies: 12408
-- Data for Name: qkan_kanalexport_exportfilter; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.qkan_kanalexport_exportfilter (id, geometry, anz_dokumente, id_suche, kanio_id, dbschema, fid, fido) VALUES ('1', '01060000000100000001030000000100000005000000BC35B0F5F8600E413C6BB77391CB56411D87338F05770E4149684BDA7DCB5641BD28B36192740E41890C2B26D3CA5641C28A1A0C2D5A0E41C3BB5C29DFCA5641BC35B0F5F8600E413C6BB77391CB5641', NULL, NULL, NULL, NULL, NULL, NULL);


-- Completed on 2026-09-17 14:19:15

--
-- PostgreSQL database dump complete
--


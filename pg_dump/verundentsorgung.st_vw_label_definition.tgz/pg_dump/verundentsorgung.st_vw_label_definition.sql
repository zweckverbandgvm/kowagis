--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:21:41

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96771 (class 0 OID 45135885)
-- Dependencies: 21023
-- Data for Name: st_vw_label_definition; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('c0cd20ca-68fa-48b3-a90f-6c82b6ed195d', 'deckelhoehe nicht geführt', '1032', 'Orginal(1032)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_koaleszenzabscheider', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and ((Z is not null and Z != 0) or ( okg is not null and okg !=0)) THEN
            NAME_NUMBER||''\P''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN Z IS NOT NULL AND Z != 0 AND Z IS NOT NULL AND Z !=0 THEN
            ''OKD: ''||trim(to_char(Z,''99990.00''))||''\P''
            WHEN Z IS NOT NULL and Z != 0 then
            ''OKD: ''||trim(to_char(Z,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okg IS NOT NULL and okg !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') as
       LABEL
from wa_pkt_schachtdeckel  where ID = $id;', 'select $1 geometry', '0', '0', 'fb66c593-1b6b-4c2f-bdfb-3c9822efd59a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a91f8c75-ae46-48eb-9a0c-e40b648ce28d', '9', '214', 'Pumpe Name', 8, '8', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_pumpwerk', 'select max(coalesce(case when p.name_number is not null and ( c.deckelhoehe  != 0 or p.sohlhoehe !=0) then
            p.name_number||''\''
       else p.NAME_NUMBER
       end, '''') ||
       coalesce(case when c.deckelhoehe != 0 and p.sohlhoehe !=0 then
            ''D: ''||c.deckelhoehe||''\''
            WHEN  c.deckelhoehe != 0 then
            ''D: ''||c.deckelhoehe::numeric
       end, '''') ||
       coalesce(CASE WHEN  p.sohlhoehe !=0 THEN
            ''S: ''||p.sohlhoehe::numeric
       end, '''') 
)     as  label  
from verundentsorgung.aw_pkt_pumpwerk p, verundentsorgung.aw_pkt_schachtdeckel c 
where c.name_number_objekt = p.name_number
and p.id = $id', 'select $1 geometry', '0', '0', 'd22ebf13-23c4-4c3f-babf-c65ec1907462', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9c3b7af3-5a19-437e-aa80-8ec1452ff9aa', '1', '10017', 'Kodierung, Station', 1, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_beobachtungspunkt', 'SELECT OBSERVATION_CODE || TO_CHAR(POSITION::numeric, ''99.0'')
FROM verundentsorgung.aw_pkt_beobachtungspunkt
WHERE POSITION::numeric < 100 AND ID = $id', 'select $1 geometry', '0', '0', '996a5b3e-c39b-4f73-a74e-861afa12fd38', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b8c2406f-cb0f-4a21-a6f2-1cb68eccfab5', '4', '201', 'Einleitungsstelle Name', 4, '4', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_einleitungsstellen', 'select
coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (sohlhoehe IS NOT NULL AND sohlhoehe != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN sohlhoehe IS NOT NULL and sohlhoehe  != 0 THEN
            ''RSE: ''||trim(to_char(sohlhoehe ,''99990.00''))
       end, '''' ) as LABEL
FROM verundentsorgung.aw_pkt_einleitungsstellen
WHERE id = $id', 'select $1 geometry', '0', '0', '3f9b099d-fae6-4c27-afc8-15f75064443c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('29c666aa-8c9b-4124-9396-fe6bddd2317e', 'unbekannt', '10005', 'Material, Profilart, Länge, Gefälle ', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_lin_haltung', 'select verundentsorgung.label_def($id)


', 'select $1 geometry', '0', '0', 'ba2d11ef-77d7-49fd-ab29-1f262daee092', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('afe47d65-ea9d-4e8e-b4b1-53203596d33a', 'unbekannt', 'zvg_wa_lin_bauwerkskante_dummy', 'zvg_wa_lin_bauwerkskante_dummy', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_lin_bauwerkskante', 'select $1 name_number', 'select $1 geometry', '0', '0', '42c776e5-8748-423b-ac8a-73c9816f271d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('20272a37-fd0e-4466-a52c-ac6f5d555c8f', 'unbekannt', 'zvg_wa_lin_wasserleitung_dummy', 'zvg_wa_lin_wasserleitung_dummy', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_lin_wasserleitung', 'select $1 name_number', 'select $1 geometry', '0', '0', 'c31890f0-4b91-403b-a9c2-7727189d498e', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('0b7393a0-ca67-4319-a1fc-290eedaa4891', 'unbekannt', '28', 'Druckmindere name _number ', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_druckminderer', 'select name_number 
from verundentsorgung.wa_pkt_druckminderer
where id = $id;', 'select $1 geometry', '0', '0', 'ae39eba3-8e62-461e-9425-2c4a965e7900', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('688fb423-9acd-4d61-a212-316d1448ac63', 'unbekannt', '20', 'Pumpwerk', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_pumpwerk', 'select name_number 
from verundentsorgung.wa_pkt_pumpwerk
where id = $id;', 'select $1 geometry', '0', '0', '99708376-a2ef-405f-98e5-230af3d1d0f0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('5a0ddfd2-856b-46a1-817d-171d4795c495', 'unbekannt', '104', 'Orginal(104)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_sonstige_anlage where ID = $id', 'select $1 geometry', '0', '0', '9a73a257-b9f5-4eeb-b62c-f23b14263c4a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ca1f8cd1-a315-472b-85fe-0577a84ab9a3', 'unbekannt', 'zvg_wa_lin_schutzrohr_dummy', 'zvg_wa_lin_schutzrohr_dummy', NULL, '004', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_lin_schutzrohr', 'select $1 name_number', 'select $1 geometry', '0', '0', 'd1aeff45-1972-4ba2-97ea-af589dac5f6c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('68c3b33b-6da7-4824-b4d7-c12ada52112d', 'unbekannt', '18', 'Behaelter Symbol', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_behaelter', 'SELECT COALESCE(layout->>''pkt_symbolname'', '''')||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            NAME_NUMBER
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_behaelter 
where ID = $id;', 'select $1 geometry', '0', '0', 'ab489551-ad40-40dd-8674-446a7e515714', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('7a348c2e-6904-40d2-9425-c7fbd8f44cea', 'unbekannt', '26', 'Brunnen Symbol', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_brunnen', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_brunnen  
where ID = $id;', 'select $1 geometry', '0', '0', '07994ab1-91b2-4bf6-84c1-fa393f083f42', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('19705fb3-3d17-4d86-a92b-97268c6546c0', 'unbekannt', '10011', 'Komplexer Schacht-Anschrieb', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schacht', 'select verundentsorgung.label_schacht($id);', 'select $1 geometry', '0', '0', '38dea46b-5dfb-4885-a0ed-e31b25fbdba0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ed17ec76-36d2-45d8-bfff-3b75ce46b5ac', '10', '10034', 'Becken Beschriftung', 9, '10', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_becken', 'SELECT  
  COALESCE(
    CASE 
      WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric IS NOT NULL) 
      THEN NAME_NUMBER || ''\'' 
      ELSE NAME_NUMBER 
    END, 
    ''''
  )
  ||
  COALESCE(
    CASE 
      WHEN OKG IS NOT NULL AND OKG::numeric is not null 
      THEN ''GH: '' || TRIM(TO_CHAR(OKG::numeric, ''99990.00'')) || ''\'' 
    END, 
    ''''
  ) AS label
FROM verundentsorgung.aw_pkt_becken
WHERE id = $id', 'select $1 geometry', '0', '0', 'aacd98bc-296f-4349-828f-a0e675727fe9', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('8b5daebe-58a5-4d12-9afe-7b2e359ab1b3', 'unbekannt', '128_wa', 'Schadensbeschriftung_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_wasserschaden', 'select NAME_NUMBER 
from verundentsorgung.wa_pkt_wasserschaden 
where ID = $id;', 'select $1 geometry', '0', '0', '45a8cd1c-a738-4234-841c-77b2fd9843e5', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a87ad30d-005e-4fd7-be7b-543fd2888c7d', 'unbekannt', 'zvg_wa_pkt_hausanschlusspunkt_dummy', 'zvg_wa_pkt_hausanschlusspunkt_dummy', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_hausanschlusspunkt', 'select $1 name_number', 'select $1 geometry', '0', '0', 'f1c82a68-fc8f-4ab1-8701-ed3da8ce8b1f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d045f226-16bb-4b8a-afc7-d0942f5ad526', 'unbekannt', '10053', 'Spühlhydrant - Bezeichnung', 17, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_spuehlhydrant', 'select NAME_NUMBER  from verundentsorgung.aw_pkt_spuehlhydrant where ID = $id

', 'select $1 geometry', '0', '0', 'bd947336-571e-475d-ab60-d0c20c9421bf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ee940f4c-7d96-4f9f-9bc9-1bf5733232d2', 'gibt es gerade nicht', '118', 'Anlagenbeschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_wehr', 'SELECT name_number FROM wa_facility WHERE id = $id', 'select $1 geometry', '0', '0', '531a29c7-f87a-455e-a42b-6234c7587f14', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('217890a1-c1e7-43b1-98f6-48946c1ff15d', 'unbekannt', '2', 'Loeschwasser', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_loeschwasserentnahmestelle', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG != 0 THEN
            ''GH: ''||trim(to_char(OKG ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_loeschwasserentnahmestelle
where ID = $id', 'select $1 geometry', '0', '0', '31ff9686-c314-4b55-a23a-721f2c70bb0a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d18e4b88-0ebb-43c2-ada1-ee0ffb802d86', 'unbekannt', '101', 'Orginal(101)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schutzrohr', 'select ZVG_MANTELROHRTEXT  from WW_FITTING where FID = $id', 'select $1 geometry', '0', '0', 'ef24ad4e-e41a-4dbc-ac29-8fb18b179499', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('408d394f-7f12-447f-aec5-bd465222ba9f', 'unbekannt', '203', 'Verbindung label_dev', NULL, '003', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_verbindungen', 'select verundentsorgung.label_def_knoten($id)', 'select $1 geometry', '0', '0', '2c491d08-ea29-4bf8-b0d3-49fed93ea66a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('8db5087d-c8d4-4006-ac44-d11b0d5209e5', 'unbekannt', '17', 'wa druckstation', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_druckstation', 'SELECT COALESCE(layout->>''pkt_symbolname'', '''')||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            NAME_NUMBER
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_druckstation
where ID = id;', 'select $1 geometry', '0', '0', '43c9fed7-2e82-45e8-a7d8-f152ba573317', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1d3a0143-9d85-4d58-9716-60b618dc379d', 'unbekannt', '128', 'Schadensbeschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schlammfang', 'select NAME_NUMBER from wa_pkt_wasserschaden  where ID = $id', 'select $1 geometry', '0', '0', '5125b950-7204-4707-bae8-b292eb100995', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a6981028-ecea-4473-b461-ef5a788360c3', 'unbekannt', 'zvg_ka_pkt_kabelnetzknoten_dummy', 'zvg_ka_pkt_kabelnetzknoten_dummy', NULL, '009', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select mantelrohrtext 
FROM verundentsorgung.ka_pkt_kabelnetzknoten a
where id = $id;', 'select $1 geometry', '0', '0', '72c47630-bd3f-4999-8a2b-15f88a97a10f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('dc3adb09-6010-4f2e-be3f-0e5aac37c271', '5', '216', 'Aufbereitungsanlage Name', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_klaeranlage', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric <> 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_klaeranlage WHERE id = $id', 'select $1 geometry', '0', '0', '4f532dd8-e7ea-48d8-9873-6e5f72b6f4d3', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('6a999c0c-fc6b-4c18-b946-e4f8f50d654c', 'unbekannt', '112_wa', 'Original(112)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_hydrant', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (OKHYD != 0 or  hoehe_okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKHYD != 0 AND hoehe_okr !=0 THEN
            ''OKHY: ''||trim(to_char(OKHYD,''99990.00''))||''\''
            WHEN OKHYD != 0 THEN
            ''OKHY: ''||trim(to_char(OKHYD,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN hoehe_okr !=0 THEN
            ''OKR: ''||trim(to_char(hoehe_okr ,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_hydrant 
where ID = $id;', 'select $1 geometry', '0', '0', '57131dd6-c225-4fb9-b10e-22e395baac27', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('118c4bf1-5e0d-4607-bede-1328c08785d8', 'unbekannt', '217', 'Schieber Name', 12, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schieber', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( OKS != 0 OR OKR !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKS != 0 AND OKR !=0 THEN
            ''OKS: ''||OKS||''\''
            WHEN  OKS != 0 then
            ''OKS: ''||OKS
       end, '''') ||
       coalesce(CASE WHEN  OKR !=0 THEN
            ''OKR: ''||OKR
       end, '''') as  
       LABEL
from verundentsorgung.aw_pkt_schieber WHERE id = $id', 'select $1 geometry', '0', '0', '6a583623-5f05-48d4-bc06-de220cc1f522', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('424c7a3f-bf2a-4d73-8170-86d9924de47c', '7', '10041', 'Komlexer Schacht-Anschrieb-Zuordnung', 6, '6', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schacht', 'select ID||coalesce(label_zusatz,'''') from verundentsorgung.aw_pkt_schacht where ID = $id', 'select $1 geometry', '0', '0', '38dea46b-5dfb-4885-a0ed-e31b25fbdba0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('5c01e74f-c410-47c7-9f80-dbacc4070e4e', '2', '10004', 'Fliesspfeil', 2, '002', '2025-04-30 15:53:48.256753+02', '2100-01-01 00:00:00+01', '2025-04-30 15:53:48.256753+02', 'unbekannt', '2025-04-30 15:53:48.256753+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_lin_haltung', 'select ''.'' from verundentsorgung.aw_lin_haltung 
where ID = $id;', 'SELECT round(degrees(st_azimuth(st_startpoint( $1 ), st_endpoint( $1 )))::numeric, 2) AS richtungswinkel, st_lineinterpolatepoint(st_makeline(st_startpoint( $1 ), st_endpoint( $1 )), 0.5::double precision) AS pkt_haltungsmitte WHERE ( $2  = ANY (ARRAY[''''Regenwasserkanal''''::text, ''''Schmutzwasserkanal''''::text, ''''Mischwasserkanal''''::text])) AND st_length( $1 ) > 5::double precision', '1', '1', 'ba2d11ef-77d7-49fd-ab29-1f262daee092', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('21c7c60a-99f8-4c0e-9ce7-75e15c24fb44', 'unbekannt', '212', 'Abscheider', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_abscheider', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (sohlhoehe  IS NOT NULL AND sohlhoehe  != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN sohlhoehe  IS NOT NULL and sohlhoehe  != 0 THEN
            ''GH: ''||trim(to_char(sohlhoehe  ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_abscheider where ID = $id', 'select $1 geometry', '0', '0', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('dca89feb-bf1c-42ff-899c-f1e3e7180aec', 'unbekannt', '10024', 'Sonstige Anlagen Name', NULL, '001', '2025-07-02 14:18:14.729696+02', '2100-01-01 00:00:00+01', '2025-07-02 14:18:14.729696+02', 'unbekannt', '2025-07-02 14:18:14.729696+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\P''
       else NAME_NUMBER
       end, '''') ||
      coalesce( CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\P''
       end, '''' )as LABEL
from aw_pkt_sonstige_anlage  where ID = $id', 'select $1 geometry', '0', '0', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('bc06a844-4b22-425e-9233-91b1cb2acb5c', 'unbekannt', '10029', 'Verschiedenes Name_number', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_verschiedenes', 'select name_number 
 from verundentsorgung.wa_pkt_verschiedenes
  where ID = $id;', 'select $1 geometry', '0', '0', '355a01ba-2c37-4072-9f8c-8f05f8886d64', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('12438df6-a21f-4b35-9b18-c2e5c18e423b', 'unbekannt', '113', 'Orginal(113)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_hausanschlusspunkt', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '' '' 
       )
       ||
      coalesce( CASE WHEN okg != 0 AND okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, ''''
       )
       ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_hausanschlusspunkt
WHERE id = $id;
', 'select $1 geometry', '0', '0', 'f1c82a68-fc8f-4ab1-8701-ed3da8ce8b1f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('76dcf305-4b34-4701-849f-68eae210cd53', 'unbekannt', '1011_wa', 'Orginal(1011)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_schieber', 'select coalesce(case when name_number is not null and (oks  != 0 or  okr !=0) then
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN oks  != 0 AND okr !=0 THEN
            ''OKS: ''||trim(to_char(oks ,''99990.00''))||''\''
            WHEN oks  != 0 THEN
            ''OKS: ''||trim(to_char(oks ,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       end, '''') as
       LABEL
FROM verundentsorgung.wa_pkt_schieber
where id = $id
and id_st_vw_schiebertyp != ''bda881cd-bca9-4296-8db7-1f968d9eb3ef'';', 'select $1 geometry', '0', '0', '63f0c549-5f24-4e69-90c6-33a2bf4513e4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b49ac26b-ce07-464b-b3fe-cc78dd4054f7', 'unbekannt', '1019_wa', 'Orginal VA(1019)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_schachtdeckel', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and ((deckelhoehe  is not null and deckelhoehe  != 0) or (okg is not null and okg !=0)) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN deckelhoehe IS NOT NULL AND deckelhoehe != 0 AND deckelhoehe IS NOT NULL AND deckelhoehe !=0 THEN
            ''OKD: ''||trim(to_char(deckelhoehe,''99990.00''))||''\''
            WHEN deckelhoehe IS NOT NULL and deckelhoehe != 0 then
            ''OKD: ''||trim(to_char(deckelhoehe,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okg IS NOT NULL and okg !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') as
       LABEL
from verundentsorgung.wa_pkt_schachtdeckel  where ID = $id;', 'select $1 geometry', '0', '0', 'f70f3426-e182-4cfc-91c9-d59d74a4b407', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('6f8c3177-22ac-4941-af7c-17e021a3b9a1', '3', '10001', 'Name, Deckel- und Sohlhöhe (10001)', 3, '3', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schacht', 'SELECT coalesce(CASE WHEN M.NAME_NUMBER IS NOT NULL AND ( C.deckelhoehe  != 0 OR M.Sohlhoehe  !=0) THEN
            M.NAME_NUMBER||''\''
       else m.NAME_NUMBER
       end, '''' )||
       coalesce(CASE WHEN C.deckelhoehe  <> 0 AND M.Sohlhoehe !=0 THEN
            ''D: ''||trim(TO_CHAR(C.deckelhoehe ,''9990.00''))||''\''
            WHEN  C.deckelhoehe  != 0 THEN
            ''D: ''||trim(TO_CHAR(C.deckelhoehe ,''9990.00''))
       end, '''') ||
       coalesce(CASE WHEN  M.Sohlhoehe !=0 THEN
            ''S: ''||trim(TO_CHAR(M.Sohlhoehe,''990.00''))
       end, '''' )||coalesce(label_zusatz,'''')
       as label
FROM verundentsorgung.aw_pkt_schachtdeckel C, verundentsorgung.aw_pkt_schacht M WHERE name_number_objekt = M.name_number
and m.ID = $id', 'select $1 geometry', '0', '0', '38dea46b-5dfb-4885-a0ed-e31b25fbdba0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('2174d0c1-a438-4c0e-bf9e-a1ea810298e1', 'unbekannt', '114_wa', 'Orginal(114)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_verbindungen', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 AND okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       END , '''')||coalesce(label_zusatz,'''')
       as LABEL
FROM verundentsorgung.wa_pkt_verbindungen 
WHERE id = $id;', 'select $1 geometry', '0', '0', '1b43644a-80ee-4908-b526-a20d6c10f051', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('241fcfe5-3e5c-4a35-aabb-0b0cee1531a4', 'unbekannt', '101_wa', 'Orginal(101)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_armatur', 'select coalesce(case when name_number is not null and (okg != 0 or  okr !=0) then
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(case when okg  != 0 and okr !=0 then
            ''GH: ''||trim(to_char(okg ,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg ,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       end, '''') 
       as label
from verundentsorgung.wa_pkt_armatur 
WHERE id = $id;', 'select $1 geometry', '0', '0', 'ffc32c06-8ce2-44bf-9dd3-c7647572a665', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('00be5571-734c-4733-b187-6906041254c1', 'unbekannt', '104_wa', 'Original(104)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_entlueftung', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  hoehe_okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 AND hoehe_okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''')  ||
       coalesce(CASE WHEN hoehe_okr  !=0 THEN
            ''OKR: ''||trim(to_char(hoehe_okr,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_entlueftung 
WHERE id = $id;', 'select $1 geometry', '0', '0', 'f0f2c59c-4176-40b0-a282-911107e7bb9d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('3609ec1c-ad97-42e9-bd6b-3393ea95ac41', '8', '10033', 'Auslauf Beschriftung', 7, '7', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_auslauf', 'SELECT
  coalesce(CASE 
    WHEN name_number IS NOT NULL AND (rsa IS NOT NULL AND rsa::numeric <> 0) THEN
      name_number || ''\''
    ELSE name_number
  end) ||
  coalesce(CASE 
    WHEN rsa IS NOT NULL AND rsa::numeric <> 0 THEN
      ''RSA: '' || TO_CHAR(rsa::numeric, ''99990.00'') || ''\''
    ELSE ''''
  end) AS label
FROM verundentsorgung.aw_pkt_auslauf
WHERE id = $id;', 'select $1 geometry', '0', '0', '7e081fd5-d024-4b94-8adb-dd803e466de2', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a9ff884b-fd73-45fd-9c0f-1d608ce9f9ef', 'unbekannt', '107_wa', 'Orginal(107)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_wasserwerk', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and okr != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okr != 0 THEN
            ''OKR: ''||trim(to_char(okr ,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_wasserwerk 
WHERE id = $id;', 'select $1 geometry', '0', '0', '54efb464-b018-47c0-b76e-c72b71d65058', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('89c2d99b-2a45-4d61-9307-8cb352992308', 'unbekannt', '10000_ta', 'Netz Beschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ta_lin_netz', 'select 
    coalesce(case when c.kurztext = ''unbekannt'' then ''''
    	else c.langtext||'' '' end , '''') 
    ||
    coalesce(case when e.kurztext = ''unbekannt'' then ''''
    	else e.langtext||'' '' end , '''')
    ||
    coalesce(case when d.kurztext = ''unbekannt'' then ''''
    	else d.langtext end , '''')
from verundentsorgung.ta_lin_netz p
left join verundentsorgung.st_vw_verwendung c on p.id_st_vw_verwendung = c.id
left join verundentsorgung.st_vw_dimension d on p.id_st_vw_dimension = d.id
left join verundentsorgung.st_vw_kabeltyp e on p.id_st_vw_kabeltyp = e.id
where p.id = $id;', 'select $1 geometry', '0', '0', 'd0a368f2-f577-400d-91ec-89db93b4ab21', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('f806e8a2-ad79-4520-ab71-ccfe859fb7df', 'unbekannt', '10002_ta', 'Netzknoten Beschriftung Schacht', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ta_pkt_netzknoten', 'select coalesce(CASE WHEN NAME_NUMBER like ''%'' AND ( deckelhoehe != 0 OR sohlhoehe !=0 ) THEN NAME_NUMBER||''\'' else NAME_NUMBER end, '''')
       ||
       coalesce(CASE WHEN deckelhoehe != 0 AND sohlhoehe !=0     THEN ''DH: ''||deckelhoehe||''\''
            WHEN deckelhoehe != 0 AND sohlhoehe is null THEN ''DH: ''||deckelhoehe  END , '''')
       ||
       coalesce(CASE WHEN sohlhoehe !=0 THEN ''SH: ''||sohlhoehe
       END , '''')
       as LABEL
from verundentsorgung.ta_pkt_netzknoten
where id = $id', 'select $1 geometry', '0', '0', '3b9a4c6d-f786-4a07-b765-587e2e93f13d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b0aafeaf-b99e-4026-99e6-1c67c6d15a2b', 'unbekannt', '10006', 'Einlaufnummer', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_lin_haltung', 'select b.kurztext
 from verundentsorgung.aw_lin_haltung 
 a left join 
 verundentsorgung.st_vw_einlaufnummer b 
 on b.id = a.id_st_vw_einlaufnummer
 where a.id = $id;


', 'select $1 geometry', '0', '0', 'ba2d11ef-77d7-49fd-ab29-1f262daee092', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('267da953-c008-41df-89b8-f7b5adc9a797', 'unbekannt', '10007', 'Auslaufnummer', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_lin_haltung', 'select b.kurztext
 from verundentsorgung.aw_lin_haltung 
 a left join 
 verundentsorgung.st_vw_auslaufnummer b 
 on b.id = a.id_st_vw_auslaufnummer
 where a.id = $id;


', 'select $1 geometry', '0', '0', 'ba2d11ef-77d7-49fd-ab29-1f262daee092', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('72a18c5c-110c-41d5-afb0-38258e6e6393', 'unbekannt', 'zvg_ta_lin_leitung_dummy', 'zvg_ta_lin_leitung_dummy', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'unbekannt', 'Fehlende Regel', 'select $1 geometry', '0', '0', '3b9a4c6d-f786-4a07-b765-587e2e93f13d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', '11', 'Schutzrohr', NULL, '001', '2025-06-20 12:13:42.932352+02', '2100-01-01 00:00:00+01', '2025-06-20 12:13:42.932352+02', 'unbekannt', '2025-06-20 12:13:42.932352+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_lin_schutzrohr', 'SELECT 
    COALESCE(''SR '', '''') ||
    COALESCE(
        CASE 
            WHEN UPPER(b.kurztext) IN (''AZ'',''GG'',''GGG'',''ST'') THEN 
                COALESCE(b.kurztext, '''') || 
                CASE 
                    WHEN a.innendurchmesser IS NOT NULL THEN 
                        '' '' || COALESCE(a.innendurchmesser::text, '''') 
                    ELSE 
                        ''''
                END

            WHEN UPPER(b.kurztext) IN (''PE'',''PE 100'',''PE 100 TS'',''PE 63'',''PE 80'',''PE-HD'',''PEX'',''PVC'',''KWK'',''PE 100 RC'') THEN 
                COALESCE(b.kurztext, '''') ||
                CASE 
                    WHEN COALESCE(a.aussendurchmesser, 0) > 0 THEN 
                        '' d '' || COALESCE(a.aussendurchmesser::text, '''') 
                    ELSE 
                        ''''
                END ||
                CASE 
                    WHEN COALESCE(a.wandstaerke, 0) > 0 THEN 
                        '' x '' || COALESCE(a.wandstaerke::text, '''') 
                    ELSE 
                        ''''
                END

            ELSE 
                COALESCE(b.kurztext, '''')
        END,
    '''') AS bezeichnung, a.innendurchmesser, a.wandstaerke
FROM verundentsorgung.wa_lin_schutzrohr a
LEFT JOIN verundentsorgung.st_vw_material b 
    ON a.id_st_vw_material = b.id
            where a.ID = $id;', 'unbekannt', '0', '0', 'd1aeff45-1972-4ba2-97ea-af589dac5f6c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('c1128598-6483-4afb-a4d8-63f3b5196cf6', 'unbekannt', '1031_wa', 'Orginal(1031)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_schacht', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and ((deckelhoehe is not null and deckelhoehe != 0) or (gelaendehoehe  is not null and gelaendehoehe !=0)) THEN
            NAME_NUMBER||CHR(13)||CHR(10)
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN deckelhoehe IS NOT NULL AND deckelhoehe != 0 AND deckelhoehe IS NOT NULL AND deckelhoehe !=0 THEN
            ''OKD: ''||deckelhoehe||CHR(13)||CHR(10)
            WHEN deckelhoehe IS NOT NULL and deckelhoehe != 0 then
            ''OKD: ''||deckelhoehe
       end, '''') ||
       coalesce(CASE WHEN gelaendehoehe IS NOT NULL and gelaendehoehe !=0 THEN
            ''GH: ''||gelaendehoehe
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_schacht where ID = $id;', 'select $1 geometry', '0', '0', '40cf2570-764b-4c04-8420-935e1f549e82', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('00000000-0000-0000-0000-000000000001', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'unbekannt', 'select ''x'' where 1=0;', 'select $1 geometry', '0', '0', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('e021260c-8763-4085-9531-35f2b2841a7a', 'unbekannt', '7', 'Schutzrohr Anfang', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra-gh" !=0 then a."sra-gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sra-okr" !=0 then a."sra-okr" end, '''' )
FROM verundentsorgung.aw_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '03407c80-04f4-4acd-810f-92f8d1762fff', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d61e70d1-bdc8-4fce-922b-658e3da6ed63', 'unbekannt', '8', 'Schutzrohr Ende', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre-gh" !=0 then a."sre-gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sre-okr" !=0 then a."sre-okr" end, '''' )
FROM verundentsorgung.aw_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '03407c80-04f4-4acd-810f-92f8d1762fff', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b9a0cb0c-1619-42af-b476-9677879b426b', 'unbekannt', '10001_ta', 'Netzknoten Beschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ta_pkt_netzknoten', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( GH != 0 OR OK !=0 ) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN GH != 0 AND OK !=0 THEN
            ''GH: ''||GH||''\''
            WHEN  GH != 0 then
            ''GH: ''||GH
       end, '''') ||
       coalesce(CASE WHEN  OK !=0 THEN
            ''OK: ''||OK end, '''') as label
from verundentsorgung.ta_pkt_netzknoten
where id = $id', 'select $1 geometry', '0', '0', '3b9a4c6d-f786-4a07-b765-587e2e93f13d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b47b894f-ef4f-4d87-8376-b5d97cfbf90f', 'unbekannt', '107', 'Orginal(107)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_brunnen', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and okg != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, ''''
       )||
       coalesce(CASE WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg ,''99990.00''))
       end, ''''
       )
       as LABEL
FROM verundentsorgung.wa_pkt_brunnen 
WHERE id = $id', 'select $1 geometry', '0', '0', '07994ab1-91b2-4bf6-84c1-fa393f083f42', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('7c441c85-e0bb-4256-990f-b79a32a3df8c', 'unbekannt', '110', 'Orginal(110)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_abscheider', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG != 0 THEN
            ''GH: ''||trim(to_char(OKG ,''99990.00''))||''\''
       end, '''') as  LABEL
from verundentsorgung.aw_pkt_abscheider WHERE id = $id', 'select $1 geometry', '0', '0', '36e23161-af70-46e2-88ea-2e83f0a25a73', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ecbfb2de-3cab-4088-a867-c42dbae9db58', 'unbekannt', '105', 'Orginal(105)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_wasserzaehler', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (OKWZ != 0 or  hoehe_okr  !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKWZ != 0 AND hoehe_okr !=0 THEN
            ''GH: ''||trim(to_char(OKWZ,''99990.00''))||''\''
            WHEN OKWZ != 0 THEN
            ''GH: ''||trim(to_char(OKWZ,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN hoehe_okr !=0 THEN
            ''OKR: ''||trim(to_char(hoehe_okr,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_wasserzaehler  WHERE id = $id;', 'select $1 geometry', '0', '0', '0a21fc84-121e-4160-89b3-b60c3b9b8fae', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('91f29928-92f2-4814-806b-93bcf86b6469', 'unbekannt', '10035', 'Drossel/Dücker', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_dueker', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\P''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\P''
       end, '''') as LABEL
FROM verundentsorgung.aw_pkt_dueker
where ID = $id', 'select $1 geometry', '0', '0', '8b53ebc8-2091-4fb7-bf0c-8fb4ca7000da', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('50561f55-deba-49a6-9b49-d5fb4ad86478', 'unbekannt', '14', 'Schutzrohr Anfang Wasser', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra_gh"::numeric !=0 then a."sra_gh"::numeric end, '''' )
||
coalesce('' \OKR:''||case when a."sra_okr"::numeric !=0 then a."sra_okr"::numeric end, '''' )
FROM verundentsorgung.wa_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'd1aeff45-1972-4ba2-97ea-af589dac5f6c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('8717dd53-ea0d-43cc-a38e-daa5b7c066b9', 'unbekannt', '114_name_number', 'Verbindung_Name_number', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_verbindungen', 'select name_number ||coalesce(label_zusatz,'''')
FROM verundentsorgung.wa_pkt_verbindungen 
WHERE id = $id;', 'select $1 geometry', '0', '0', '1b43644a-80ee-4908-b526-a20d6c10f051', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('2a5f0672-2176-455a-936f-1172e8616bbb', '5', '218', 'Klaertank', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_klaertank', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric <> 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_klaertank WHERE id = $id', 'select $1 geometry', '0', '0', '684e1a37-3a3b-40fb-b5d3-7e53f75f9714', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1467732d-3348-44bc-8042-13fd423e3ddb', 'unbekannt', '1', 'Beprobungspunkt', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_beprobungspunkt', 'select name_number 
from verundentsorgung.wa_pkt_beprobungspunkt
where id = $id', 'select $1 geometry', '0', '0', 'c74eba4c-ed19-4200-a404-fa4944e835c3', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('cff2fc44-98f5-4e0d-9ff2-686c07af3fe3', 'unbekannt', '3', 'Schachtdeckel', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schachtdeckel', 'select name_number 
from verundentsorgung.aw_pkt_schachtdeckel
where id = $id', 'select $1 geometry', '0', '0', '5fa42204-76d8-4587-98cd-0d11e72482f9', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1f45adfa-1328-4c69-9d31-c117155069b0', 'unbekannt', '4', 'Schutzrohr.', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_lin_schutzrohr', 'SELECT 
  ''SR '' ||
  COALESCE(NULLIF(b.kurztext, ''unbekannt''), '''') ||
  '' DN '' ||
  COALESCE(a.nennweite::text, '''') AS bezeichnung
FROM verundentsorgung.aw_lin_schutzrohr a
LEFT JOIN verundentsorgung.st_vw_material b 
  ON a.id_st_vw_material = b.id
where a.id = $id', 'select $1 geometry', '0', '0', '03407c80-04f4-4acd-810f-92f8d1762fff', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a09dbc15-8880-431e-8971-14acc2812516', 'unbekannt', '22', 'Schacht Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_schacht', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_schacht  
where ID = $id;', 'select $1 geometry', '0', '0', '40cf2570-764b-4c04-8420-935e1f549e82', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('6f6c2dde-44e4-46d6-8f98-315489c51e2d', 'unbekannt', '14_wa', 'Armatur Symbol', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_armatur', 'select coalesce(case when name_number is not null and (okg != 0 or  okr !=0) then
            NAME_NUMBER
       else NAME_NUMBER
       end, '''')||'', ''||COALESCE(layout->>''pkt_symbolname'', '''')
       as label
from verundentsorgung.wa_pkt_armatur 
WHERE id = $id;', 'select $1 geometry', '0', '0', 'ffc32c06-8ce2-44bf-9dd3-c7647572a665', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('185851ea-e54c-4dfc-b9cf-f7671b9d7c0f', 'unbekannt', '109', 'Orginal(109)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_behaelter', 'SELECT COALESCE(CASE WHEN NAME_NUMBER IS NOT NULL and hoehe_okr != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
      COALESCE( CASE WHEN hoehe_okr != 0 THEN
            ''GH: ''||trim(to_char(hoehe_okr ,''99990.00''))
       END ,'''')
      as  LABEL
FROM verundentsorgung.wa_pkt_behaelter
WHERE id = $id;', 'select $1 geometry', '0', '0', 'ab489551-ad40-40dd-8674-446a7e515714', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('5fdaa421-7f56-4e55-887c-ef31233970ea', 'unbekannt', '19', 'Hydrant Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_hydrant', 'SELECT Name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_hydrant  
where ID = $id;', 'select $1 geometry', '0', '0', '57131dd6-c225-4fb9-b10e-22e395baac27', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('8645b0ac-f6fb-40eb-a6c0-06e766d95ddc', 'unbekannt', '21', 'Pumpwerk Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_pumpwerk', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_pumpwerk  
where ID = $id;', 'select $1 geometry', '0', '0', '99708376-a2ef-405f-98e5-230af3d1d0f0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('725a3d97-acfc-481e-b9d0-b87190f8369d', 'unbekannt', '23', 'Schieber Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_schieber', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_schieber  
where ID = $id;', 'select $1 geometry', '0', '0', '63f0c549-5f24-4e69-90c6-33a2bf4513e4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('2018e88a-2af0-422f-9fc3-108c24a9e2d2', 'unbekannt', '24', 'Verschiedenes Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_verschiedenes', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_verschiedenes  
where ID = $id;', 'select $1 geometry', '0', '0', '355a01ba-2c37-4072-9f8c-8f05f8886d64', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('2848c515-2033-4495-96f5-ffafd7a1d80e', 'unbekannt', '25', 'Wasserzähler Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_wasserzaehler', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_wasserzaehler  
where ID = $id;', 'select $1 geometry', '0', '0', '0a21fc84-121e-4160-89b3-b60c3b9b8fae', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('48d1d295-9c64-45bf-b763-3c972400d861', 'unbekannt', '27', 'Entlüftung Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_entlueftung', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_entlueftung  
where ID = $id;', 'select $1 geometry', '0', '0', 'f0f2c59c-4176-40b0-a282-911107e7bb9d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9dd13349-0cc3-4595-8431-8844618f366b', 'unbekannt', '1025_wa', 'Druckminderer Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_druckminderer', 'SELECT  COALESCE(layout->>''pkt_symbolname'', '''')||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and okg != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg ,''99990.00''))
       END , '''')
       as LABEL
from verundentsorgung.wa_pkt_druckminderer
where ID = $id;', 'select $1 geometry', '0', '0', 'ae39eba3-8e62-461e-9425-2c4a965e7900', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('e5b13403-3fad-40e5-b3d7-965e4c970303', 'unbekannt', '15', 'Schutzrohr Ende Wasser', NULL, '003', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre_gh"::numeric !=0 then a."sre_gh"::numeric end, '''' )
||
coalesce('' \OKR:''||case when a."sre_okr"::numeric !=0 then a."sre_okr"::numeric end, '''' )
FROM verundentsorgung.wa_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'd1aeff45-1972-4ba2-97ea-af589dac5f6c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d8d38215-ec4d-4512-ae4d-09c76542f47e', 'unbekannt', '31', 'Abscheider Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_abscheider', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_abscheider 
where ID = $id;', 'select $1 geometry', '0', '0', '36e23161-af70-46e2-88ea-2e83f0a25a73', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('27fa618e-9dc4-442d-af36-8074cdea033c', 'unbekannt', '30', 'Schutzrohr Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schutzrohr', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_schutzrohr 
where ID = $id;', 'select $1 geometry', '0', '0', 'ef24ad4e-e41a-4dbc-ac29-8fb18b179499', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d348b6d9-5eca-43d3-9dbf-020f9ada47e0', 'unbekannt', '29', 'Abwasserschaden Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_abwasserschaden', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_abwasserschaden 
where ID = $id;', 'select $1 geometry', '0', '0', '5125b950-7204-4707-bae8-b292eb100995', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('2043cb7d-5003-45d0-a542-28b5875728bd', '8', '32', 'Auslauf Symbol', 7, '7', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_auslauf', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_auslauf 
where ID = $id;', 'select $1 geometry', '0', '0', '7e081fd5-d024-4b94-8adb-dd803e466de2', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('3ef80d08-195f-40b7-8a1b-de4a68ca1f40', '1', '33', 'Beobachtungspunkte Symbol', 1, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_beobachtungspunkt', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_beobachtungspunkt 
where ID = $id;', 'select $1 geometry', '0', '0', '996a5b3e-c39b-4f73-a74e-861afa12fd38', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('47355281-d6e7-4c9b-bf01-4b7bfbeaa6d1', '10', '34', 'Becken Symbol', 9, '10', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_becken', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_becken 
where ID = $id;', 'select $1 geometry', '0', '0', 'aacd98bc-296f-4349-828f-a0e675727fe9', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('7af233c5-19fb-4756-bb34-d918232b802d', 'unbekannt', '35', 'Drossel/Dücker Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_dueker', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_dueker 
where ID = $id;', 'select $1 geometry', '0', '0', '8b53ebc8-2091-4fb7-bf0c-8fb4ca7000da', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b335d0a8-a7b3-4e01-a24d-987f3bf959ce', '9', '37', 'Pumpe Symbol', 8, '8', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_pumpwerk', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_pumpwerk 
where ID = $id;', 'select $1 geometry', '0', '0', 'd22ebf13-23c4-4c3f-babf-c65ec1907462', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d5e944e3-5284-422a-9a59-09576c62dd8a', '5', '38', 'Klaertank Symbol', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_klaertank', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_klaertank 
where ID = $id;', 'select $1 geometry', '0', '0', '684e1a37-3a3b-40fb-b5d3-7e53f75f9714', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ee24c9f8-63c5-4e99-91a1-29c88cc8624d', '5', '39', 'Aufbereitungsanlage klaeranlage', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_klaeranlage', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_klaeranlage 
where ID = $id;', 'select $1 geometry', '0', '0', '4f532dd8-e7ea-48d8-9873-6e5f72b6f4d3', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('37dccfa8-3bac-4b68-95a5-5b0e880fd13a', 'unbekannt', '41', 'Schachtdeckel Symbole', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schachtdeckel', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_schachtdeckel
where ID = $id;', 'select $1 geometry', '0', '0', '5fa42204-76d8-4587-98cd-0d11e72482f9', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('65346203-d1c5-4424-a2d9-4a632b917c47', 'unbekannt', '43', 'Schieber Symbole', 12, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schieber', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_schieber 
where ID = $id;', 'select $1 geometry', '0', '0', '6a583623-5f05-48d4-bc06-de220cc1f522', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('03299925-8f4d-4c49-bd4e-dc70f2e40165', 'unbekannt', '44', 'Sonstige Anlagen Symbole', NULL, '001', '2025-07-02 14:18:14.729696+02', '2100-01-01 00:00:00+01', '2025-07-02 14:18:14.729696+02', 'unbekannt', '2025-07-02 14:18:14.729696+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_sonstige_anlage
where ID = $id;', 'select $1 geometry', '0', '0', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('c4be7202-4567-4cbc-b679-a0c2e7dfcf78', 'unbekannt', '45', 'Spühlhydrant Symbole', 17, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_spuehlhydrant', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_spuehlhydrant 
where ID = $id;', 'select $1 geometry', '0', '0', 'bd947336-571e-475d-ab60-d0c20c9421bf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d56438a1-cd47-407c-9316-5b7cce02f20c', '', '46', 'Verbindung Symbole', 15, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_verbindungen', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') ||coalesce(label_zusatz,'''')
       as LABEL
from verundentsorgung.aw_pkt_verbindungen 
where ID = $id;', 'select $1 geometry', '0', '0', '2c491d08-ea29-4bf8-b0d3-49fed93ea66a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d7130410-ef23-48a1-bea4-2fe23bc0966e', 'unbekannt', '48', 'Loeschwasser Symbole', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_loeschwasserentnahmestelle', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_loeschwasserentnahmestelle 
where ID = $id;', 'select $1 geometry', '0', '0', '31ff9686-c314-4b55-a23a-721f2c70bb0a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('706a35d0-ac74-498e-90ea-d1e454804b8d', 'unbekannt', '10002_ka', 'KA Netzknoten', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select coalesce(CASE WHEN NAME_NUMBER like ''%'' AND ( deckelhoehe != 0 OR sohlhoehe !=0 ) THEN NAME_NUMBER||''\'' else NAME_NUMBER end, '''')
       ||
       coalesce(CASE WHEN deckelhoehe != 0 AND sohlhoehe !=0     THEN ''DH: ''||deckelhoehe||''\''
            WHEN deckelhoehe != 0 AND sohlhoehe is null THEN ''DH: ''||deckelhoehe  END , '''')
       ||
       coalesce(CASE WHEN sohlhoehe !=0 THEN ''SH: ''||sohlhoehe
       END , '''')
       as LABEL
from verundentsorgung.ka_pkt_kabelnetzknoten
where id = $id', 'select $1 geometry', '0', '0', '72c47630-bd3f-4999-8a2b-15f88a97a10f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ea57c2d3-dc44-40f4-9cbc-0dde1e96e4af', 'unbekannt', '10001_ka', 'Kabelnetknoten', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( GH != 0 OR OK !=0 ) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN GH != 0 AND OK !=0 THEN
            ''GH: ''||GH||''\''
            WHEN  GH != 0 then
            ''GH: ''||GH
       end, '''') ||
       coalesce(CASE WHEN  OK !=0 THEN
            ''OK: ''||OK end, '''') as label
from verundentsorgung.ka_pkt_kabelnetzknoten
where id = $id', 'select $1 geometry', '0', '0', '72c47630-bd3f-4999-8a2b-15f88a97a10f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('6d5820bf-1b71-4c84-8ada-dcf4063c3843', 'unbekannt', '23_aw', 'Name_number', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_lin_haltung', 'select name_number 
 from verundentsorgung.aw_lin_haltung 
 where id = $id;


', 'select $1 geometry', '0', '0', 'ba2d11ef-77d7-49fd-ab29-1f262daee092', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('4612a6cb-b63e-4a75-85fe-c51e1f81ef21', 'unbekannt', '10004_ta', 'Mantelrohrbeschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ta_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."gh" !=0 then a."gh" end, '''' )
||
coalesce('' \OKR:''||case when a."okr" !=0 then a."okr" end, '''' )
FROM verundentsorgung.ta_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('735725d0-edbe-4748-ad42-1eddb0f77739', 'unbekannt', '10004_ka', 'Mantelrohrbeschriftung_ka', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select mantelrohrtext 
FROM verundentsorgung.ka_pkt_kabelnetzknoten a
where id = $id;', 'select $1 geometry', '0', '0', '72c47630-bd3f-4999-8a2b-15f88a97a10f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('278beb02-7319-47c4-b930-bfb082cea329', 'unbekannt', '10000_ka', 'KA Netz', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ka_lin_kabelnetz', 'select coalesce(    coalesce(case when c.kurztext = ''unbekannt'' then ''''
    	else c.langtext||'' '' end , '''') 
    ||
    coalesce(case when e.kurztext = ''unbekannt'' then ''''
    	else e.langtext||'' '' end , '''')
    ||
    coalesce(case when d.kurztext = ''unbekannt'' then ''''
    	else d.langtext end , ''''),'''')
from verundentsorgung.ka_lin_kabelnetz p
left join verundentsorgung.st_vw_verwendung c on p.id_st_vw_verwendung = c.id
left join verundentsorgung.st_vw_dimension d on p.id_st_vw_dimension = d.id
left join verundentsorgung.st_vw_kabeltyp e on p.id_st_vw_kabeltyp = e.id
where p.id = $id;', 'select $1 geometry', '0', '0', '8fa9873a-0440-4c81-b5c7-e9d0067e40b7', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9fe8b215-8056-4159-8963-771a076961ef', '4', '36', 'Einleitungsstelle Name Symbol', 4, '4', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_einleitungsstellen', 'select
coalesce(CASE WHEN a.NAME_NUMBER IS NOT NULL AND (a.sohlhoehe IS NOT NULL AND a.sohlhoehe != 0) THEN
            a.NAME_NUMBER||'', ''||b.kurztext ||''\''
       else a.NAME_NUMBER||'', ''||b.kurztext 
       end, '''') ||
       coalesce(CASE WHEN a.sohlhoehe IS NOT NULL and a.sohlhoehe  != 0 THEN
            ''RSE: ''||trim(to_char(a.sohlhoehe ,''99990.00''))
       end, '''' ) as LABEL
FROM verundentsorgung.aw_pkt_einleitungsstellen a
left join verundentsorgung.st_vw_abwassereinleittyp b on b.id = a.id_st_vw_abwassereinleittyp 
WHERE a.id = $id;', 'select $1 geometry', '0', '0', '3f9b099d-fae6-4c27-afc8-15f75064443c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('09c1a485-6421-4432-9a7c-b5eb508bcecb', 'unbekannt', '8_ta', 'Schutzrohr Ende..', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ta_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre_gh" !=0 then a."sre_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sre_okr" !=0 then a."sre_okr" end, '''' )
FROM verundentsorgung.ta_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('97662717-de12-4b53-bf1c-962381b5d179', 'unbekannt', '7_ta', 'Schutzrohr Anfang..', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ta_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra_gh" !=0 then a."sra_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sra_okr" !=0 then a."sra_okr" end, '''' )
FROM verundentsorgung.ta_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('34492b83-7fcf-4e16-8e6e-e46b8f510a17', 'unbekannt', '4_ta', 'Schutzrohr...', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ta_lin_schutzrohr', 'SELECT 
  COALESCE(NULLIF(c.kurztext, ''unbekannt''), '''') ||
  '' ST '' ||
  COALESCE(d.kurztext::text, '''') AS bezeichnung
FROM verundentsorgung.ta_lin_schutzrohr a
LEFT JOIN verundentsorgung.st_vw_material b 
  ON a.id_st_vw_material = b.id
LEFT JOIN verundentsorgung.st_vw_verwendung c
  ON a.id_st_vw_verwendung = c.id
LEFT JOIN verundentsorgung.st_vw_dimension d
  ON a.id_st_vw_dimension  = d.id  
where a.id = $id', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('3b555a0b-2849-4d81-97be-91d354feea2a', 'unbekannt', '7_ka', 'Schutzrohr Anfang.', NULL, '004', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ka_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra_gh" !=0 then a."sra_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sra_okr" !=0 then a."sra_okr" end, '''' )
FROM verundentsorgung.ka_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('5a47ce82-3bc1-49f6-88b2-80ac21e59495', 'unbekannt', '8_ka', 'Schutzrohr Ende.', NULL, '003', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ka_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre_gh" !=0 then a."sre_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sre_okr" !=0 then a."sre_okr" end, '''' )
FROM verundentsorgung.ka_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b9bd2938-3256-4621-ab66-91c69eb97c08', 'unbekannt', '101_wa', 'Orginal(101)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_armatur', 'select coalesce(case when name_number is not null and (okg != 0 or  okr !=0) then
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(case when okg  != 0 and okr !=0 then
            ''GH: ''||trim(to_char(okg ,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg ,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       end, '''') 
       as label
from verundentsorgung.wa_pkt_armatur 
WHERE id = $id;', 'select $1 geometry', '0', '0', '0c85f0ba-03e1-4eda-8f85-530b1ac93876', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('350525ac-ad26-4670-8aa1-291a79be1e34', 'unbekannt', '35', 'Drossel/Dücker Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_dueker', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_dueker 
where ID = $id;', 'select $1 geometry', '0', '0', 'e8a94900-7eb2-4f73-ba0d-0bea2e83d2dd', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('051df37b-a5b2-4139-a906-127d02bd399e', 'unbekannt', '4_ka', 'Schutzrohr..', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000000', 'verundentsorgung', 'ka_lin_schutzrohr', 'select mantelrohrtext 
FROM verundentsorgung.ka_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('793b3f40-5663-4ab6-b01e-ee3feb10dea5', 'unbekannt', '112', 'Orginal(112)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_fettabscheider', 'SELECT
  COALESCE(
    CASE WHEN NAME_NUMBER IS NOT NULL AND (OKHYD IS NOT NULL OR hoehe_okr IS NOT NULL)
      THEN NAME_NUMBER || ''\''
      ELSE NAME_NUMBER
    END, ''''
  )
  ||
  COALESCE(
    CASE
      WHEN OKHYD != 0 AND hoehe_okr != 0 THEN ''OKHY: '' || TRIM(TO_CHAR(OKHYD, ''99990.00'')) || ''\P''
      WHEN OKHYD != 0 THEN ''OKHY: '' || TRIM(TO_CHAR(OKHYD, ''99990.00''))
    END, ''''
  )
  ||
  COALESCE(
    CASE WHEN hoehe_okr != 0 THEN ''OKR: '' || TRIM(TO_CHAR(hoehe_okr, ''99990.00'')) END, ''''
  )
  AS label 
FROM verundentsorgung.wa_pkt_hydrant
WHERE ID = $id', 'select $1 geometry', '0', '0', 'b25b636d-8e30-4d0d-b616-5463c3ac5b97', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('8f28966e-e53d-4bfe-a6bf-0f98c7a5bbe9', 'unbekannt', '10053', 'Spühlhydrant - Bezeichnung', 17, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_spuehlhydrant', 'select NAME_NUMBER  from verundentsorgung.aw_pkt_spuehlhydrant where ID = $id

', 'select $1 geometry', '0', '0', '7c45c554-0e88-4e8b-a6bf-df059961c8e2', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('969c792d-9974-438d-87bb-d7c421ffea5a', 'unbekannt', '128', 'Schadensbeschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schlammfang', 'select NAME_NUMBER from wa_pkt_wasserschaden  where ID = $id', 'select $1 geometry', '0', '0', '5125b950-7204-4707-bae8-b292eb100995', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b8657110-b31e-4e96-94c2-c540cc32c085', 'unbekannt', '7', 'Schutzrohr Anfang', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra-gh" !=0 then a."sra-gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sra-okr" !=0 then a."sra-okr" end, '''' )
FROM verundentsorgung.aw_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '03407c80-04f4-4acd-810f-92f8d1762fff', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('0aa29ae9-7ac4-4da0-adc7-4be8d054358f', 'unbekannt', '212', 'Abscheider', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_abscheider', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (sohlhoehe  IS NOT NULL AND sohlhoehe  != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN sohlhoehe  IS NOT NULL and sohlhoehe  != 0 THEN
            ''GH: ''||trim(to_char(sohlhoehe  ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_abscheider where ID = $id', 'select $1 geometry', '0', '0', '00000000-0000-0000-0000-000000000000', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('dab9f36a-8e92-4533-abe5-dc5ce9fafbee', 'unbekannt', '8', 'Schutzrohr Ende', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre-gh" !=0 then a."sre-gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sre-okr" !=0 then a."sre-okr" end, '''' )
FROM verundentsorgung.aw_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '03407c80-04f4-4acd-810f-92f8d1762fff', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('315aa0ee-9e70-447d-ad98-3ddfb6171e2d', 'unbekannt', '110', 'Orginal(110)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_abscheider', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG != 0 THEN
            ''GH: ''||trim(to_char(OKG ,''99990.00''))||''\''
       end, '''') as  LABEL
from verundentsorgung.aw_pkt_abscheider WHERE id = $id', 'select $1 geometry', '0', '0', '36e23161-af70-46e2-88ea-2e83f0a25a73', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('051912b8-a1d1-4b4d-be2c-8d01ae94a9e7', '7', '10041', 'Komlexer Schacht-Anschrieb-Zuordnung', 6, '6', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schacht', 'select coalesce(label_zusatz,'''') from verundentsorgung.aw_pkt_schacht where ID = $id', 'select $1 geometry', '0', '0', '5ca2e497-9bd7-42bb-aaab-8bd2e9a958f3', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b72f8f50-3e37-4bbe-9c35-5cfdbfb14f97', 'unbekannt', '4', 'Schutzrohr.', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_lin_schutzrohr', 'SELECT 
  ''SR '' ||
  COALESCE(NULLIF(b.kurztext, ''unbekannt''), '''') ||
  '' DN '' ||
  COALESCE(a.nennweite::text, '''') || '' '' ||
  COALESCE(a.laenge::text, '''')||''m'' AS bezeichnung
FROM verundentsorgung.aw_lin_schutzrohr a
LEFT JOIN verundentsorgung.st_vw_material b 
  ON a.id_st_vw_material = b.id
where a.id = $id', 'select $1 geometry', '0', '0', '03407c80-04f4-4acd-810f-92f8d1762fff', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('477e8cab-b2fe-43ea-bab1-e931cd5146e3', 'unbekannt', '114', 'Original(114)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_verbindungen', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 AND okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       END , '''')||coalesce(label_zusatz,'''')
       as LABEL
FROM verundentsorgung.wa_pkt_verbindungen 
WHERE id = $id;', 'select $1 geometry', '0', '0', '5125b950-7204-4707-bae8-b292eb100995', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('c28b3852-20e5-4d7e-b601-6efd6bfaf4ff', 'unbekannt', '31', 'Abscheider Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_abscheider', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_abscheider 
where ID = $id;', 'select $1 geometry', '0', '0', '36e23161-af70-46e2-88ea-2e83f0a25a73', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('18e0628c-f02a-4da2-8f3f-cedc9cd551e9', 'unbekannt', '10004_ta', 'Mantelrohrbeschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ta_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."gh" !=0 then a."gh" end, '''' )
||
coalesce('' \OKR:''||case when a."okr" !=0 then a."okr" end, '''' )
FROM verundentsorgung.ta_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ce5e5cf7-d522-446a-a7b3-0a42963dcdf8', 'unbekannt', '7_ka', 'Schutzrohr Anfang.', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ka_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra_gh" !=0 then a."sra_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sra_okr" !=0 then a."sra_okr" end, '''' )
FROM verundentsorgung.ka_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('3c8206fe-93b0-452c-b722-ee2115b1e151', 'unbekannt', '8_ka', 'Schutzrohr Ende.', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ka_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre_gh" !=0 then a."sre_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sre_okr" !=0 then a."sre_okr" end, '''' )
FROM verundentsorgung.ka_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('34626ad6-3ed0-4511-97f0-31cd3457f8f6', 'unbekannt', '4_ka', 'Schutzrohr..', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ka_lin_schutzrohr', 'SELECT 
  ''SR '' ||
  COALESCE(NULLIF(b.kurztext, ''unbekannt''), '''') ||
  '' DN '' ||
  COALESCE(a.nennweite::text, '''') AS bezeichnung
FROM verundentsorgung.ka_lin_schutzrohr a
LEFT JOIN verundentsorgung.st_vw_material b 
  ON a.id_st_vw_material = b.id
where a.id = $id', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('f4bb44a8-d557-4aa7-a38a-791f3b026894', 'unbekannt', '8_ta', 'Schutzrohr Ende..', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ta_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre_gh" !=0 then a."sre_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sre_okr" !=0 then a."sre_okr" end, '''' )
FROM verundentsorgung.ta_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('64e3030a-16a6-4296-bba1-8f8e9ee6eecc', 'unbekannt', '7_ta', 'Schutzrohr Anfang..', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ta_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra_gh" !=0 then a."sra_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sra_okr" !=0 then a."sra_okr" end, '''' )
FROM verundentsorgung.ta_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('0d7f1ef8-00df-4437-bec8-d57b6f5c1b69', 'unbekannt', '4_ta', 'Schutzrohr...', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ta_lin_schutzrohr', 'SELECT 
  COALESCE(NULLIF(c.kurztext, ''unbekannt''), '''') ||
  '' ST '' ||
  COALESCE(d.kurztext::text, '''') AS bezeichnung
FROM verundentsorgung.ta_lin_schutzrohr a
LEFT JOIN verundentsorgung.st_vw_material b 
  ON a.id_st_vw_material = b.id
LEFT JOIN verundentsorgung.st_vw_verwendung c
  ON a.id_st_vw_verwendung = c.id
LEFT JOIN verundentsorgung.st_vw_dimension d
  ON a.id_st_vw_dimension  = d.id  
where a.id = $id', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('69355dd4-6289-4d03-bbfd-a00ea50fbcdb', 'deckelhoehe nicht geführt', '1032', 'Orginal(1032)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_koaleszenzabscheider', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and ((Z is not null and Z != 0) or ( okg is not null and okg !=0)) THEN
            NAME_NUMBER||''\P''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN Z IS NOT NULL AND Z != 0 AND Z IS NOT NULL AND Z !=0 THEN
            ''OKD: ''||trim(to_char(Z,''99990.00''))||''\P''
            WHEN Z IS NOT NULL and Z != 0 then
            ''OKD: ''||trim(to_char(Z,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okg IS NOT NULL and okg !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') as
       LABEL
from wa_pkt_schachtdeckel  where ID = $id;', 'select $1 geometry', '0', '0', '91f65644-622e-4f33-9fbf-00c79221f506', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1faa991e-b34a-428b-8989-7fa8a80adcfd', '1', '10017', 'Kodierung, Station', 1, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_beobachtungspunkt', 'SELECT OBSERVATION_CODE || TO_CHAR(POSITION::numeric, ''99.0'')
FROM verundentsorgung.aw_pkt_beobachtungspunkt
WHERE POSITION::numeric < 100 AND ID = $id', 'select $1 geometry', '0', '0', 'c53589b6-a0da-48af-8a00-f2ae80ff8953', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('7cbc2eb0-a3b3-4809-ae34-1bc248229ce8', '4', '201', 'Einleitungsstelle Name', 4, '4', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_einleitungsstellen', 'select
coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (sohlhoehe IS NOT NULL AND sohlhoehe != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN sohlhoehe IS NOT NULL and sohlhoehe  != 0 THEN
            ''RSE: ''||trim(to_char(sohlhoehe ,''99990.00''))
       end, '''' ) as LABEL
FROM verundentsorgung.aw_pkt_einleitungsstellen
WHERE id = $id', 'select $1 geometry', '0', '0', '533acac3-d6c5-4744-9424-e8f6d8f2f496', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a83035a9-90f9-46c7-95e9-47b56bd92332', 'unbekannt', '10005', 'Material, Profilart, Länge, Gefälle ', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_lin_haltung', 'select verundentsorgung.label_def($id)


', 'select $1 geometry', '0', '0', '963206c9-6101-44da-bc4e-ffcb3a3bf34e', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('dbc1d5fb-3823-4322-abbe-477d2f977fb8', 'unbekannt', '10011', 'Komplexer Schacht-Anschrieb', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schacht', 'select verundentsorgung.label_schacht($id);', 'select $1 geometry', '0', '0', '5ca2e497-9bd7-42bb-aaab-8bd2e9a958f3', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9da9acb4-79ae-4973-8670-d11f2ad8c2af', 'unbekannt', 'zvg_wa_lin_bauwerkskante_dummy', 'zvg_wa_lin_bauwerkskante_dummy', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_lin_bauwerkskante', 'select $1 name_number', 'select $1 geometry', '0', '0', '80bb6a88-e887-440c-87be-d6a809282c06', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('6e2089e6-20d7-4b90-98b2-eef7999e2253', 'unbekannt', 'zvg_wa_lin_wasserleitung_dummy', 'zvg_wa_lin_wasserleitung_dummy', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_lin_wasserleitung', 'select $1 name_number', 'select $1 geometry', '0', '0', '18893f00-c47f-474f-8381-0ecb153fdf21', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a1b1a14a-ffe1-4dc0-8cc2-af9eb29f89f2', 'unbekannt', '28', 'Druckmindere name _number ', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_druckminderer', 'select name_number 
from verundentsorgung.wa_pkt_druckminderer
where id = $id;', 'select $1 geometry', '0', '0', 'c97ec5b4-007f-404e-8912-827e3fb1c44f', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('edcb6a1b-6a6e-4022-9475-245f3427fc9a', 'unbekannt', '20', 'Pumpwerk', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_pumpwerk', 'select name_number 
from verundentsorgung.wa_pkt_pumpwerk
where id = $id;', 'select $1 geometry', '0', '0', '5295bcdd-d92f-46cf-8ea7-43694278cef3', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('17f72a73-eafe-453e-b082-fd8f2b56cd32', 'unbekannt', '104', 'Orginal(104)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_sonstige_anlage where ID = $id', 'select $1 geometry', '0', '0', 'c3de878e-287f-4668-a54d-681a3c9b6e58', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d6b19b93-e307-4a89-8aa5-9c7b1d6c897e', 'unbekannt', 'zvg_wa_lin_schutzrohr_dummy', 'zvg_wa_lin_schutzrohr_dummy', NULL, '004', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_lin_schutzrohr', 'select $1 name_number', 'select $1 geometry', '0', '0', 'e21dd3e6-c595-4a9a-a529-86dd78848332', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('e4046296-0c96-4675-81ea-ec274ee2fff3', 'unbekannt', '18', 'Behaelter Symbol', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_behaelter', 'SELECT COALESCE(layout->>''pkt_symbolname'', '''')||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            NAME_NUMBER
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_behaelter 
where ID = $id;', 'select $1 geometry', '0', '0', 'f08ccdeb-2a2f-45f8-8e9e-1446af186e4c', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('6c4b1e26-8134-4fce-a951-45ffb3e0c7a0', 'unbekannt', '26', 'Brunnen Symbol', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_brunnen', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_brunnen  
where ID = $id;', 'select $1 geometry', '0', '0', '67f88ba9-6e41-4c66-bf05-d7f0113cdd21', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('19ed568b-d698-4359-8967-6e389ee59f22', '10', '10034', 'Becken Beschriftung', 9, '10', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_becken', 'SELECT  
  COALESCE(
    CASE 
      WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric IS NOT NULL) 
      THEN NAME_NUMBER || ''\'' 
      ELSE NAME_NUMBER 
    END, 
    ''''
  )
  ||
  COALESCE(
    CASE 
      WHEN OKG IS NOT NULL AND OKG::numeric is not null 
      THEN ''GH: '' || TRIM(TO_CHAR(OKG::numeric, ''99990.00'')) || ''\'' 
    END, 
    ''''
  ) AS label
FROM verundentsorgung.aw_pkt_becken
WHERE id = $id', 'select $1 geometry', '0', '0', '49d2d839-2050-4767-9f67-368fd33f2fa7', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('4801f001-ddaf-4723-9b9f-827d5e522b92', 'unbekannt', '128_wa', 'Schadensbeschriftung_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_wasserschaden', 'select NAME_NUMBER 
from verundentsorgung.wa_pkt_wasserschaden 
where ID = $id;', 'select $1 geometry', '0', '0', 'ec5e97a0-1cf7-45c1-a1fe-0dbe5b9e7b4a', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('4f410c32-9769-4fc5-b166-580056aeea28', 'unbekannt', 'zvg_wa_pkt_hausanschlusspunkt_dummy', 'zvg_wa_pkt_hausanschlusspunkt_dummy', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_hausanschlusspunkt', 'select $1 name_number', 'select $1 geometry', '0', '0', '7ecddc91-33ba-49d4-84f1-a10f97fc3955', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('5d362673-46da-4e2a-a53e-06f08241a273', 'gibt es gerade nicht', '118', 'Anlagenbeschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_wehr', 'SELECT name_number FROM wa_facility WHERE id = $id', 'select $1 geometry', '0', '0', '6a8f3e54-ba4f-4053-b16c-70aaab9da3c6', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('77b0f040-4187-4853-bbbf-c8c699591a8f', 'unbekannt', '2', 'Loeschwasser', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_loeschwasserentnahmestelle', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG != 0 THEN
            ''GH: ''||trim(to_char(OKG ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_loeschwasserentnahmestelle
where ID = $id', 'select $1 geometry', '0', '0', '51ee2138-290e-4c24-a2c4-64665df35bc3', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('66d6fe57-a642-4ca3-bce9-10f551a9bd23', '9', '214', 'Pumpe Name', 8, '8', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_pumpwerk', 'select max(coalesce(case when p.name_number is not null and ( c.deckelhoehe  != 0 or p.sohlhoehe !=0) then
            p.name_number||''\''
       else p.NAME_NUMBER
       end, '''') ||
       coalesce(case when c.deckelhoehe != 0 and p.sohlhoehe !=0 then
            ''D: ''||c.deckelhoehe||''\''
            WHEN  c.deckelhoehe != 0 then
            ''D: ''||c.deckelhoehe
       end, '''') ||
       coalesce(CASE WHEN  p.sohlhoehe !=0 THEN
            ''S: ''||p.sohlhoehe
       end, '''') 
)     as  label  
from verundentsorgung.aw_pkt_pumpwerk p, verundentsorgung.aw_pkt_schachtdeckel c 
where c.name_number_objekt = p.name_number
and p.id = $id', 'select $1 geometry', '0', '0', '6e9836a7-ab3d-4514-9c66-100c3c7b7774', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('f7032b8a-178c-4e1f-add3-27139e4d237e', 'unbekannt', '101', 'Orginal(101)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schutzrohr', 'select ZVG_MANTELROHRTEXT  from WW_FITTING where FID = $id', 'select $1 geometry', '0', '0', '72a3ea54-2a55-4250-b694-b8724d07ce18', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('81030378-ca66-433e-be35-39317dda68d2', 'unbekannt', '203', 'Verbindung label_dev', NULL, '003', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_verbindungen', 'select verundentsorgung.label_def_knoten($id)', 'select $1 geometry', '0', '0', '48db0644-896f-46fb-92ea-d32f766bb910', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('25bf63b4-402a-4d89-b558-4c885f950929', 'unbekannt', '17', 'wa druckstation', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_druckstation', 'SELECT COALESCE(layout->>''pkt_symbolname'', '''')||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            NAME_NUMBER
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_druckstation
where ID = id;', 'select $1 geometry', '0', '0', '531440bd-7445-44d1-b841-f9c767145427', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('699a4417-77d2-4acf-a502-8745ec6cf284', 'unbekannt', 'zvg_ka_pkt_kabelnetzknoten_dummy', 'zvg_ka_pkt_kabelnetzknoten_dummy', NULL, '009', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select mantelrohrtext 
FROM verundentsorgung.ka_pkt_kabelnetzknoten a
where id = $id;', 'select $1 geometry', '0', '0', '7f2c3c5e-c4bb-4744-9d89-e5ee97737e3d', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('f246df1b-bbb7-49a8-9411-8d25147118dc', '5', '216', 'Aufbereitungsanlage Name', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_klaeranlage', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric <> 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_klaeranlage WHERE id = $id', 'select $1 geometry', '0', '0', '46ad188c-6c3e-4a37-8ce3-080bc459e140', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('8f0a0930-3245-4485-a986-1672eee467f9', 'unbekannt', '112_wa', 'Original(112)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_hydrant', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (OKHYD != 0 or  hoehe_okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKHYD != 0 AND hoehe_okr !=0 THEN
            ''OKHY: ''||trim(to_char(OKHYD,''99990.00''))||''\''
            WHEN OKHYD != 0 THEN
            ''OKHY: ''||trim(to_char(OKHYD,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN hoehe_okr !=0 THEN
            ''OKR: ''||trim(to_char(hoehe_okr ,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_hydrant 
where ID = $id;', 'select $1 geometry', '0', '0', 'ee083853-9f78-4e56-a82a-f1ab749f8f1b', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('29f443c9-fe81-49e7-8fdc-dbf113bdef1c', 'unbekannt', '217', 'Schieber Name', 12, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schieber', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( OKS != 0 OR OKR !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKS != 0 AND OKR !=0 THEN
            ''OKS: ''||OKS||''\''
            WHEN  OKS != 0 then
            ''OKS: ''||OKS
       end, '''') ||
       coalesce(CASE WHEN  OKR !=0 THEN
            ''OKR: ''||OKR
       end, '''') as  
       LABEL
from verundentsorgung.aw_pkt_schieber WHERE id = $id', 'select $1 geometry', '0', '0', '803c249f-76f0-4888-abf5-60695eac6de9', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('52afeb1f-bc08-4138-b5b3-135e3d9d08a7', '2', '10004', 'Fliesspfeil', 2, '002', '2025-04-30 15:53:48.256753+02', '2100-01-01 00:00:00+01', '2025-04-30 15:53:48.256753+02', 'unbekannt', '2025-04-30 15:53:48.256753+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_lin_haltung', 'select ''.'' from verundentsorgung.aw_lin_haltung 
where ID = $id;', 'SELECT round(degrees(st_azimuth(st_startpoint( $1 ), st_endpoint( $1 )))::numeric, 2) AS richtungswinkel, st_lineinterpolatepoint(st_makeline(st_startpoint( $1 ), st_endpoint( $1 )), 0.5::double precision) AS pkt_haltungsmitte WHERE ( $2  = ANY (ARRAY[''''Regenwasserkanal''''::text, ''''Schmutzwasserkanal''''::text, ''''Mischwasserkanal''''::text])) AND st_length( $1 ) > 5::double precision', '1', '1', '963206c9-6101-44da-bc4e-ffcb3a3bf34e', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d3a2ad95-0528-4300-b905-d324c49f7c5b', 'unbekannt', '10024', 'Sonstige Anlagen Name', NULL, '001', '2025-07-02 14:18:14.729696+02', '2100-01-01 00:00:00+01', '2025-07-02 14:18:14.729696+02', 'unbekannt', '2025-07-02 14:18:14.729696+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\P''
       else NAME_NUMBER
       end, '''') ||
      coalesce( CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\P''
       end, '''' )as LABEL
from aw_pkt_sonstige_anlage  where ID = $id', 'select $1 geometry', '0', '0', 'c3de878e-287f-4668-a54d-681a3c9b6e58', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b7bfdfd2-6818-454c-a12d-258d32caa44c', 'unbekannt', '10029', 'Verschiedenes Name_number', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_verschiedenes', 'select name_number 
 from verundentsorgung.wa_pkt_verschiedenes
  where ID = $id;', 'select $1 geometry', '0', '0', '9d9effe1-42ac-4a4d-9c8e-6db2a4c68a6c', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b20ea9cc-8b26-49b8-bb71-16d64b2f6528', 'unbekannt', '1007', 'BD: Leitung (STD)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_lin_wasserleitung', 'SELECT
  coalesce(CASE
    WHEN upper(b.kurztext) IN (''AZ'',''GG'',''GGG'',''STAHL'',''ST'',''UNBEKANNT'') THEN
      b.kurztext ||
      COALESCE('' '' || a.nennweite, '''')
    WHEN upper(b.kurztext) IN (''PE'',''PE 100'',''PE 100 TS'',''PE 100 RC'', ''PE 63'',''PE 80'',''PE-HD'',''PEX'',''PVC'',''KWK'',''ST'') THEN
      b.kurztext ||
      COALESCE(
        CASE WHEN a.aussendurchmesser::numeric > 0 THEN '' d '' || a.aussendurchmesser ELSE '''' END, ''''
      ) ||
      COALESCE(
        CASE WHEN a.wandstaerke::numeric > 0 THEN '' x '' || trim(to_char(a.wandstaerke::numeric,''9999990D00'')) ELSE '''' END, ''''
      ) ||
      COALESCE(
        CASE WHEN l.langtext = ''Horizontalspülbohrung'' THEN '' '' || l.langtext ELSE '''' END, ''''
      )
    ELSE NULL
  end) AS r
FROM verundentsorgung.wa_lin_wasserleitung a
LEFT JOIN verundentsorgung.st_vw_material    b ON a.id_st_vw_material = b.id
LEFT JOIN verundentsorgung.st_vw_verlegetyp  l ON a.id_st_vw_verlegetyp = l.id
WHERE a.id = $id;', 'select $1 geometry', '0', '0', '18893f00-c47f-474f-8381-0ecb153fdf21', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('7e6196eb-5eb7-4513-b78a-527f5ab5cc67', 'unbekannt', '113', 'Orginal(113)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_hausanschlusspunkt', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '' '' 
       )
       ||
      coalesce( CASE WHEN okg != 0 AND okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, ''''
       )
       ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_hausanschlusspunkt
WHERE id = $id;
', 'select $1 geometry', '0', '0', '7ecddc91-33ba-49d4-84f1-a10f97fc3955', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('92f093cf-e6a7-4240-ae27-c82af3070572', 'unbekannt', '10054', 'Verbindung Beschriftung NAME_NUMBER GH OKR', 15, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_verbindungen', 'select coalesce(NAME_NUMBER||
coalesce(''\''||case when okg != 0 then
''GH:''||to_char(okg,''99.99'') end, '''')||
coalesce(''\''||''OKR: ''||case when OKR !=0 then
to_char(OKR,''99.99'')end, '''') )||coalesce(label_zusatz,'''')  S 
from verundentsorgung.aw_pkt_verbindungen 
where  ID = $id and sohlhoehe  is not null 
and OKR is not null ', 'select $1 geometry', '0', '0', '48db0644-896f-46fb-92ea-d32f766bb910', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('781d7ec5-2aeb-4b67-9c58-4ccfcd81dced', 'unbekannt', '114_wa', 'Orginal(114)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_verbindungen', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 AND okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       END , '''')
       as LABEL
FROM verundentsorgung.wa_pkt_verbindungen 
WHERE id = $id;', 'select $1 geometry', '0', '0', 'e5ac6569-a923-491f-ba13-f7f0b00cfda5', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('c8fa3fec-bff0-4d52-ae02-233ba31b415a', 'unbekannt', '3', 'Schachtdeckel', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schachtdeckel', 'select name_number 
from verundentsorgung.aw_pkt_schachtdeckel
where id = $id', 'select $1 geometry', '0', '0', 'aacdaf73-7cd9-4505-9256-5dd94e9ef5f6', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('461a0a17-96df-495e-8702-4da9a685e2d0', 'unbekannt', '1011_wa', 'Orginal(1011)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_schieber', 'select coalesce(case when name_number is not null and (oks  != 0 or  okr !=0) then
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN oks  != 0 AND okr !=0 THEN
            ''OKS: ''||trim(to_char(oks ,''99990.00''))||''\''
            WHEN oks  != 0 THEN
            ''OKS: ''||trim(to_char(oks ,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       end, '''') as
       LABEL
FROM verundentsorgung.wa_pkt_schieber
where id = $id
and id_st_vw_schiebertyp != ''bda881cd-bca9-4296-8db7-1f968d9eb3ef'';', 'select $1 geometry', '0', '0', 'e6a71cad-0748-4557-a9cb-09eb1fa50031', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('97e4af54-db25-4b5d-b335-610538d04123', 'unbekannt', '1019_wa', 'Orginal VA(1019)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_schachtdeckel', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and ((deckelhoehe  is not null and deckelhoehe  != 0) or (okg is not null and okg !=0)) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN deckelhoehe IS NOT NULL AND deckelhoehe != 0 AND deckelhoehe IS NOT NULL AND deckelhoehe !=0 THEN
            ''OKD: ''||trim(to_char(deckelhoehe,''99990.00''))||''\''
            WHEN deckelhoehe IS NOT NULL and deckelhoehe != 0 then
            ''OKD: ''||trim(to_char(deckelhoehe,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okg IS NOT NULL and okg !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') as
       LABEL
from verundentsorgung.wa_pkt_schachtdeckel  where ID = $id;', 'select $1 geometry', '0', '0', '76590fef-f134-4b32-bd76-ef9aa3bb98c6', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a6adf2ce-21e1-4de6-9302-92e6abe45221', 'unbekannt', '104_wa', 'Original(104)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_entlueftung', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  hoehe_okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 AND hoehe_okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''')  ||
       coalesce(CASE WHEN hoehe_okr  !=0 THEN
            ''OKR: ''||trim(to_char(hoehe_okr,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_entlueftung 
WHERE id = $id;', 'select $1 geometry', '0', '0', 'e34e5188-2ba1-4399-8ace-f23bf42b5d24', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b37611d3-bb28-48a9-81ca-7244e77b454a', '8', '10033', 'Auslauf Beschriftung', 7, '7', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_auslauf', 'SELECT
  coalesce(CASE 
    WHEN name_number IS NOT NULL AND (rsa IS NOT NULL AND rsa::numeric <> 0) THEN
      name_number || ''\''
    ELSE name_number
  end) ||
  coalesce(CASE 
    WHEN rsa IS NOT NULL AND rsa::numeric <> 0 THEN
      ''RSA: '' || TO_CHAR(rsa::numeric, ''99990.00'') || ''\''
    ELSE ''''
  end) AS label
FROM verundentsorgung.aw_pkt_auslauf
WHERE id = $id;', 'select $1 geometry', '0', '0', '149102ec-0b3d-4039-b4b0-ba70fcdb4c17', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('95bfb246-1866-40ff-bc9c-5679159e704e', 'unbekannt', '107_wa', 'Orginal(107)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_wasserwerk', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and okr != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okr != 0 THEN
            ''OKR: ''||trim(to_char(okr ,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_wasserwerk 
WHERE id = $id;', 'select $1 geometry', '0', '0', 'c0d23b88-d745-45dc-b1a5-810022d9c2e3', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('7cc2096a-3f68-41ad-ae4c-081223a243e4', 'unbekannt', '10000_ta', 'Netz Beschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ta_lin_netz', 'select 
    coalesce(case when c.kurztext = ''unbekannt'' then ''''
    	else c.langtext||'' '' end , '''') 
    ||
    coalesce(case when e.kurztext = ''unbekannt'' then ''''
    	else e.langtext||'' '' end , '''')
    ||
    coalesce(case when d.kurztext = ''unbekannt'' then ''''
    	else d.langtext end , '''')
from verundentsorgung.ta_lin_netz p
left join verundentsorgung.st_vw_verwendung c on p.id_st_vw_verwendung = c.id
left join verundentsorgung.st_vw_dimension d on p.id_st_vw_dimension = d.id
left join verundentsorgung.st_vw_kabeltyp e on p.id_st_vw_kabeltyp = e.id
where p.id = $id;', 'select $1 geometry', '0', '0', 'a80fdc96-3307-4d8c-a0b1-a412e765045f', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('7a1c6f19-7371-44bd-9208-22cf91e5a715', 'unbekannt', '10002_ta', 'Netzknoten Beschriftung Schacht', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ta_pkt_netzknoten', 'select coalesce(CASE WHEN NAME_NUMBER like ''%'' AND ( deckelhoehe != 0 OR sohlhoehe !=0 ) THEN NAME_NUMBER||''\'' else NAME_NUMBER end, '''')
       ||
       coalesce(CASE WHEN deckelhoehe != 0 AND sohlhoehe !=0     THEN ''DH: ''||deckelhoehe||''\''
            WHEN deckelhoehe != 0 AND sohlhoehe is null THEN ''DH: ''||deckelhoehe  END , '''')
       ||
       coalesce(CASE WHEN sohlhoehe !=0 THEN ''SH: ''||sohlhoehe
       END , '''')
       as LABEL
from verundentsorgung.ta_pkt_netzknoten
where id = $id', 'select $1 geometry', '0', '0', 'ff70a71b-c9e2-4f3b-9317-fb5234db387e', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('51a10d78-f019-416d-9d7f-64de2abc0ff3', 'unbekannt', '10006', 'Einlaufnummer', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_lin_haltung', 'select b.kurztext
 from verundentsorgung.aw_lin_haltung 
 a left join 
 verundentsorgung.st_vw_einlaufnummer b 
 on b.id = a.id_st_vw_einlaufnummer
 where a.id = $id;


', 'select $1 geometry', '0', '0', '963206c9-6101-44da-bc4e-ffcb3a3bf34e', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('e93b188c-f7c0-44be-9d3e-4d5e99553788', 'unbekannt', '10007', 'Auslaufnummer', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_lin_haltung', 'select b.kurztext
 from verundentsorgung.aw_lin_haltung 
 a left join 
 verundentsorgung.st_vw_auslaufnummer b 
 on b.id = a.id_st_vw_auslaufnummer
 where a.id = $id;


', 'select $1 geometry', '0', '0', '963206c9-6101-44da-bc4e-ffcb3a3bf34e', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('26dd69d6-0713-4dd9-8201-525d60b52702', 'unbekannt', 'zvg_ta_lin_leitung_dummy', 'zvg_ta_lin_leitung_dummy', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'unbekannt', 'Fehlende Regel', 'select $1 geometry', '0', '0', 'e43323c3-9403-4a60-878c-a8f882f01188', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9ed4a7c6-ded0-46e6-b355-f3a92e5b019f', 'unbekannt', '10035', 'Drossel/Dücker', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_dueker', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\P''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\P''
       end, '''') as LABEL
FROM verundentsorgung.aw_pkt_dueker
where ID = $id', 'select $1 geometry', '0', '0', 'e8a94900-7eb2-4f73-ba0d-0bea2e83d2dd', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('fa81408c-0167-4814-860a-8ce34933962b', '5', '218', 'Klaertank', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_klaertank', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric <> 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_klaertank WHERE id = $id', 'select $1 geometry', '0', '0', '8c58f7fa-cb39-435a-bd38-b6e6a549138b', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('90ec0247-ef51-4c94-b5fd-bd03b2fbc96b', 'unbekannt', '11', 'Schutzrohr', NULL, '001', '2025-06-20 12:13:42.932352+02', '2100-01-01 00:00:00+01', '2025-06-20 12:13:42.932352+02', 'unbekannt', '2025-06-20 12:13:42.932352+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_lin_schutzrohr', 'SELECT 
    COALESCE(''SR '', '''') ||
    COALESCE(
        CASE 
            WHEN UPPER(b.kurztext) IN (''AZ'',''GG'',''GGG'',''ST'') THEN 
                COALESCE(b.kurztext, '''') || 
                CASE 
                    WHEN a.innendurchmesser IS NOT NULL THEN 
                        '' '' || COALESCE(a.innendurchmesser::text, '''') 
                    ELSE 
                        ''''
                END

            WHEN UPPER(b.kurztext) IN (''PE'',''PE 100'',''PE 100 TS'',''PE 63'',''PE 80'',''PE-HD'',''PEX'',''PVC'',''KWK'',''PE 100 RC'') THEN 
                COALESCE(b.kurztext, '''') ||
                CASE 
                    WHEN COALESCE(a.aussendurchmesser, 0) > 0 THEN 
                        '' d '' || COALESCE(a.aussendurchmesser::text, '''') 
                    ELSE 
                        ''''
                END ||
                CASE 
                    WHEN COALESCE(a.wandstaerke, 0) > 0 THEN 
                        '' x '' || COALESCE(a.wandstaerke::text, '''') 
                    ELSE 
                        ''''
                END

            ELSE 
                COALESCE(b.kurztext, '''')
        END,
    '''') AS bezeichnung, a.innendurchmesser, a.wandstaerke
FROM verundentsorgung.wa_lin_schutzrohr a
LEFT JOIN verundentsorgung.st_vw_material b 
    ON a.id_st_vw_material = b.id
            where a.ID = $id;', 'unbekannt', '0', '0', 'e21dd3e6-c595-4a9a-a529-86dd78848332', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('fe75dc00-6de0-4472-b4d8-350aa1a07412', 'unbekannt', '1031_wa', 'Orginal(1031)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_schacht', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and ((deckelhoehe is not null and deckelhoehe != 0) or (gelaendehoehe  is not null and gelaendehoehe !=0)) THEN
            NAME_NUMBER||CHR(13)||CHR(10)
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN deckelhoehe IS NOT NULL AND deckelhoehe != 0 AND deckelhoehe IS NOT NULL AND deckelhoehe !=0 THEN
            ''OKD: ''||deckelhoehe||CHR(13)||CHR(10)
            WHEN deckelhoehe IS NOT NULL and deckelhoehe != 0 then
            ''OKD: ''||deckelhoehe
       end, '''') ||
       coalesce(CASE WHEN gelaendehoehe IS NOT NULL and gelaendehoehe !=0 THEN
            ''GH: ''||gelaendehoehe
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_schacht where ID = $id;', 'select $1 geometry', '0', '0', 'c9adad8c-d6d2-449b-a211-19652f676e18', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('264f0e5b-649c-4468-a0f4-c2e6e28b9cf4', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'unbekannt', 'select ''x'' where 1=0;', 'select $1 geometry', '0', '0', 'e43323c3-9403-4a60-878c-a8f882f01188', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ad255652-56ba-49c6-8b92-ef1dfc734a73', 'unbekannt', '114_name_number', 'Verbindung_Name_number', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_verbindungen', 'select name_number 
FROM verundentsorgung.wa_pkt_verbindungen 
WHERE id = $id;', 'select $1 geometry', '0', '0', 'e5ac6569-a923-491f-ba13-f7f0b00cfda5', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('78b45ba4-6afd-4852-897d-e4d524fd7316', 'unbekannt', '10001_ta', 'Netzknoten Beschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ta_pkt_netzknoten', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( GH != 0 OR OK !=0 ) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN GH != 0 AND OK !=0 THEN
            ''GH: ''||GH||''\''
            WHEN  GH != 0 then
            ''GH: ''||GH
       end, '''') ||
       coalesce(CASE WHEN  OK !=0 THEN
            ''OK: ''||OK end, '''') as label
from verundentsorgung.ta_pkt_netzknoten
where id = $id', 'select $1 geometry', '0', '0', 'ff70a71b-c9e2-4f3b-9317-fb5234db387e', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('fdb140fa-fffc-4921-818d-d33a048cf304', 'unbekannt', '23', 'Schieber Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_schieber', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_schieber  
where ID = $id;', 'select $1 geometry', '0', '0', 'e6a71cad-0748-4557-a9cb-09eb1fa50031', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('119d648f-3e46-4cf9-b719-25d3f42d32ac', 'unbekannt', '1019', 'Original VA', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_schieber', 'SELECT 
  coalesce(
    CASE 
      WHEN name_number IS NOT NULL 
        AND (
          COALESCE(REPLACE(zvg_okva::text, '','', ''.'')::numeric, 0) != 0 OR 
          COALESCE(REPLACE(okr::text, '','', ''.'')::numeric, 0) != 0
        )
      THEN name_number || ''\''
      ELSE name_number
    END, ''''
  ) ||
  coalesce(
    CASE 
      WHEN COALESCE(REPLACE(zvg_okva::text, '','', ''.'')::numeric, 0) != 0 
        AND COALESCE(REPLACE(okr::text, '','', ''.'')::numeric, 0) != 0 THEN
          ''OKS: '' || trim(to_char(REPLACE(zvg_okva::text, '','', ''.'')::numeric, ''99990.00'')) || ''\''
      WHEN COALESCE(REPLACE(zvg_okva::text, '','', ''.'')::numeric, 0) != 0 THEN
          ''OKS: '' || trim(to_char(REPLACE(zvg_okva::text, '','', ''.'')::numeric, ''99990.00''))
    END, ''''
  ) ||
  coalesce(
    CASE 
      WHEN COALESCE(REPLACE(okr::text, '','', ''.'')::numeric, 0) != 0 THEN
        ''OKR: '' || trim(to_char(REPLACE(okr::text, '','', ''.'')::numeric, ''99990.00''))
    END, ''''
  ) AS label
FROM verundentsorgung.wa_pkt_schieber
WHERE id = $id
  AND id_st_vw_schiebertyp = ''bda881cd-bca9-4296-8db7-1f968d9eb3ef'';
', 'select $1 geometry', '0', '0', 'e6a71cad-0748-4557-a9cb-09eb1fa50031', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('5f88da67-9304-406e-8ea0-1e090024bbb5', 'unbekannt', '14', 'Schutzrohr Anfang Wasser', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra_gh"::numeric !=0 then a."sra_gh"::numeric end, '''' )
||
coalesce('' \OKR:''||case when a."sra_okr"::numeric !=0 then a."sra_okr"::numeric end, '''' )
FROM verundentsorgung.wa_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'e21dd3e6-c595-4a9a-a529-86dd78848332', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('13a8a5be-6f95-4a17-9314-f5688ef61709', 'unbekannt', '107', 'Orginal(107)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_brunnen', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and okg != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, ''''
       )||
       coalesce(CASE WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg ,''99990.00''))
       end, ''''
       )
       as LABEL
FROM verundentsorgung.wa_pkt_brunnen 
WHERE id = $id', 'select $1 geometry', '0', '0', '67f88ba9-6e41-4c66-bf05-d7f0113cdd21', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('471d54c6-76d1-426b-b7ff-7cd78d4635d1', 'unbekannt', '105', 'Orginal(105)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_wasserzaehler', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (OKWZ != 0 or  hoehe_okr  !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKWZ != 0 AND hoehe_okr !=0 THEN
            ''GH: ''||trim(to_char(OKWZ,''99990.00''))||''\''
            WHEN OKWZ != 0 THEN
            ''GH: ''||trim(to_char(OKWZ,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN hoehe_okr !=0 THEN
            ''OKR: ''||trim(to_char(hoehe_okr,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_wasserzaehler  WHERE id = $id;', 'select $1 geometry', '0', '0', '87aee177-366f-4c27-b534-ee0995ece9a9', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('df7f32c6-fc14-44fd-b1fa-5912d134161e', 'unbekannt', '1', 'Beprobungspunkt', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_beprobungspunkt', 'select name_number 
from verundentsorgung.wa_pkt_beprobungspunkt
where id = $id', 'select $1 geometry', '0', '0', '8a466022-be73-48c1-9d3d-144150269209', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('aff6ed9d-c9e6-4940-93b4-d38205ad783f', 'unbekannt', '22', 'Schacht Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_schacht', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_schacht  
where ID = $id;', 'select $1 geometry', '0', '0', 'c9adad8c-d6d2-449b-a211-19652f676e18', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('198318b1-883c-44f7-8932-574e9fe6c957', 'unbekannt', '14_wa', 'Armatur Symbol', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_armatur', 'select coalesce(case when name_number is not null and (okg != 0 or  okr !=0) then
            NAME_NUMBER
       else NAME_NUMBER
       end, '''')||'', ''||COALESCE(layout->>''pkt_symbolname'', '''')
       as label
from verundentsorgung.wa_pkt_armatur 
WHERE id = $id;', 'select $1 geometry', '0', '0', '0c85f0ba-03e1-4eda-8f85-530b1ac93876', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('077180e1-1a72-454b-8116-24a081b4a8d9', 'unbekannt', '109', 'Orginal(109)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_behaelter', 'SELECT COALESCE(CASE WHEN NAME_NUMBER IS NOT NULL and hoehe_okr != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
      COALESCE( CASE WHEN hoehe_okr != 0 THEN
            ''GH: ''||trim(to_char(hoehe_okr ,''99990.00''))
       END ,'''')
      as  LABEL
FROM verundentsorgung.wa_pkt_behaelter
WHERE id = $id;', 'select $1 geometry', '0', '0', 'f08ccdeb-2a2f-45f8-8e9e-1446af186e4c', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1905b048-868e-45a5-b73f-ff9c2090404a', 'unbekannt', '19', 'Hydrant Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_hydrant', 'SELECT Name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_hydrant  
where ID = $id;', 'select $1 geometry', '0', '0', 'ee083853-9f78-4e56-a82a-f1ab749f8f1b', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('71ba6522-0a72-4fff-8e50-ef64eff35149', 'unbekannt', '21', 'Pumpwerk Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_pumpwerk', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_pumpwerk  
where ID = $id;', 'select $1 geometry', '0', '0', '5295bcdd-d92f-46cf-8ea7-43694278cef3', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1321fe96-e55e-43e6-a2b2-06b1319165b9', 'unbekannt', '24', 'Verschiedenes Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_verschiedenes', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_verschiedenes  
where ID = $id;', 'select $1 geometry', '0', '0', '9d9effe1-42ac-4a4d-9c8e-6db2a4c68a6c', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('044ecaa0-88a5-471e-b48b-77c36418d1d3', 'unbekannt', '25', 'Wasserzähler Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_wasserzaehler', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_wasserzaehler  
where ID = $id;', 'select $1 geometry', '0', '0', '87aee177-366f-4c27-b534-ee0995ece9a9', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b3dec34d-21de-4738-922a-6182b5c51b3c', 'unbekannt', '27', 'Entlüftung Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_entlueftung', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_entlueftung  
where ID = $id;', 'select $1 geometry', '0', '0', 'e34e5188-2ba1-4399-8ace-f23bf42b5d24', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('fe05e47f-fb09-4c56-a8ef-83cfd3255122', 'unbekannt', '1025_wa', 'Druckminderer Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_druckminderer', 'SELECT  COALESCE(layout->>''pkt_symbolname'', '''')||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and okg != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg ,''99990.00''))
       END , '''')
       as LABEL
from verundentsorgung.wa_pkt_druckminderer
where ID = $id;', 'select $1 geometry', '0', '0', 'c97ec5b4-007f-404e-8912-827e3fb1c44f', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('38104a9f-3ebf-493c-ba20-b000d53b182b', 'unbekannt', '30', 'Schutzrohr Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schutzrohr', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_schutzrohr 
where ID = $id;', 'select $1 geometry', '0', '0', '72a3ea54-2a55-4250-b694-b8724d07ce18', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1ed82c1a-f04a-4ad5-9b03-be67615b2ced', '', '6', 'Verbindung Name_number', 15, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_verbindungen', 'select name_number ||coalesce(label_zusatz,'''')
from verundentsorgung.aw_pkt_verbindungen 
where id = $id', 'select $1 geometry', '0', '0', '48db0644-896f-46fb-92ea-d32f766bb910', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('46760bb7-6ed4-467c-8562-afbefaf90881', 'unbekannt', '29', 'Abwasserschaden Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_abwasserschaden', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_abwasserschaden 
where ID = $id;', 'select $1 geometry', '0', '0', '53dd7a77-6200-4ccc-8060-14e0d0e18587', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('4e4c7852-48a9-4794-b51f-aba00f367f58', '8', '32', 'Auslauf Symbol', 7, '7', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_auslauf', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_auslauf 
where ID = $id;', 'select $1 geometry', '0', '0', '149102ec-0b3d-4039-b4b0-ba70fcdb4c17', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('c1728f2a-3fc1-424a-9ae3-a48e9253a30f', '1', '33', 'Beobachtungspunkte Symbol', 1, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_beobachtungspunkt', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_beobachtungspunkt 
where ID = $id;', 'select $1 geometry', '0', '0', 'c53589b6-a0da-48af-8a00-f2ae80ff8953', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('bdc88571-a7e8-4ceb-86b9-f3b9c0c75540', '10', '34', 'Becken Symbol', 9, '10', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_becken', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_becken 
where ID = $id;', 'select $1 geometry', '0', '0', '49d2d839-2050-4767-9f67-368fd33f2fa7', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d28d5106-d7a8-4e5c-a2ee-cec5f3fe232b', '9', '37', 'Pumpe Symbol', 8, '8', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_pumpwerk', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_pumpwerk 
where ID = $id;', 'select $1 geometry', '0', '0', '6e9836a7-ab3d-4514-9c66-100c3c7b7774', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ee6f0d3b-13b0-45c9-8bf2-5bf5ceddae0a', '5', '38', 'Klaertank Symbol', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_klaertank', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_klaertank 
where ID = $id;', 'select $1 geometry', '0', '0', '8c58f7fa-cb39-435a-bd38-b6e6a549138b', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('73f2b593-fe08-4f7e-80fe-b6e722b72048', '5', '39', 'Aufbereitungsanlage klaeranlage', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_klaeranlage', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_klaeranlage 
where ID = $id;', 'select $1 geometry', '0', '0', '46ad188c-6c3e-4a37-8ce3-080bc459e140', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('e534706a-c332-42b3-a9c6-7c5bde816dff', 'unbekannt', '41', 'Schachtdeckel Symbole', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schachtdeckel', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_schachtdeckel
where ID = $id;', 'select $1 geometry', '0', '0', 'aacdaf73-7cd9-4505-9256-5dd94e9ef5f6', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('0d79f8d7-0d72-4186-9044-91483be8e8ab', 'unbekannt', '43', 'Schieber Symbole', 12, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schieber', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_schieber 
where ID = $id;', 'select $1 geometry', '0', '0', '803c249f-76f0-4888-abf5-60695eac6de9', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('04a6adce-386c-4648-b347-38d609b03689', 'unbekannt', '44', 'Sonstige Anlagen Symbole', NULL, '001', '2025-07-02 14:18:14.729696+02', '2100-01-01 00:00:00+01', '2025-07-02 14:18:14.729696+02', 'unbekannt', '2025-07-02 14:18:14.729696+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_sonstige_anlage
where ID = $id;', 'select $1 geometry', '0', '0', 'c3de878e-287f-4668-a54d-681a3c9b6e58', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('7e5fe42c-a523-4005-b4df-3a130d9b4921', 'unbekannt', '45', 'Spühlhydrant Symbole', 17, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_spuehlhydrant', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_spuehlhydrant 
where ID = $id;', 'select $1 geometry', '0', '0', '7c45c554-0e88-4e8b-a6bf-df059961c8e2', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('55c4901c-a0cf-4f69-b8cd-41c21819e55e', 'unbekannt', '48', 'Loeschwasser Symbole', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_loeschwasserentnahmestelle', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_loeschwasserentnahmestelle 
where ID = $id;', 'select $1 geometry', '0', '0', '51ee2138-290e-4c24-a2c4-64665df35bc3', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ae1768a4-4b18-4ae6-94df-04a5f0b9763c', 'unbekannt', '10002_ka', 'KA Netzknoten', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select coalesce(CASE WHEN NAME_NUMBER like ''%'' AND ( deckelhoehe != 0 OR sohlhoehe !=0 ) THEN NAME_NUMBER||''\'' else NAME_NUMBER end, '''')
       ||
       coalesce(CASE WHEN deckelhoehe != 0 AND sohlhoehe !=0     THEN ''DH: ''||deckelhoehe||''\''
            WHEN deckelhoehe != 0 AND sohlhoehe is null THEN ''DH: ''||deckelhoehe  END , '''')
       ||
       coalesce(CASE WHEN sohlhoehe !=0 THEN ''SH: ''||sohlhoehe
       END , '''')
       as LABEL
from verundentsorgung.ka_pkt_kabelnetzknoten
where id = $id', 'select $1 geometry', '0', '0', '7f2c3c5e-c4bb-4744-9d89-e5ee97737e3d', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9c946639-43b2-4bde-801f-d78e243fe703', '3', '42', 'Schacht  Symbol', 3, '3', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schacht', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''')||coalesce(label_zusatz,'''')
       as LABEL
from verundentsorgung.aw_pkt_schacht 
where ID = $id;', 'select $1 geometry', '0', '0', '5ca2e497-9bd7-42bb-aaab-8bd2e9a958f3', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('f210febd-68de-468f-8d97-5bc915a199bc', '', '46', 'Verbindung Symbole', 15, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_verbindungen', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') ||coalesce(label_zusatz,'''')
       as LABEL
from verundentsorgung.aw_pkt_verbindungen 
where ID = $id;', 'select $1 geometry', '0', '0', '48db0644-896f-46fb-92ea-d32f766bb910', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a6a5d98c-061e-45de-8faf-6db3d067ee7f', 'unbekannt', '10001_ka', 'Kabelnetknoten', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( GH != 0 OR OK !=0 ) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN GH != 0 AND OK !=0 THEN
            ''GH: ''||GH||''\''
            WHEN  GH != 0 then
            ''GH: ''||GH
       end, '''') ||
       coalesce(CASE WHEN  OK !=0 THEN
            ''OK: ''||OK end, '''') as label
from verundentsorgung.ka_pkt_kabelnetzknoten
where id = $id', 'select $1 geometry', '0', '0', '7f2c3c5e-c4bb-4744-9d89-e5ee97737e3d', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('f3b22a52-eae0-4183-ad06-1e95b03a4601', 'unbekannt', '23_aw', 'Name_number', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_lin_haltung', 'select name_number 
 from verundentsorgung.aw_lin_haltung 
 where id = $id;


', 'select $1 geometry', '0', '0', '963206c9-6101-44da-bc4e-ffcb3a3bf34e', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b44eae9c-caef-4b23-b0c6-259cc5ab1608', 'unbekannt', '10004_ka', 'Mantelrohrbeschriftung_ka', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select mantelrohrtext 
FROM verundentsorgung.ka_pkt_kabelnetzknoten a
where id = $id;', 'select $1 geometry', '0', '0', '7f2c3c5e-c4bb-4744-9d89-e5ee97737e3d', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('87cff0f6-a621-4815-9f47-bb4f02ddae66', 'unbekannt', '10000_ka', 'KA Netz', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'ka_lin_kabelnetz', 'select coalesce(    coalesce(case when c.kurztext = ''unbekannt'' then ''''
    	else c.langtext||'' '' end , '''') 
    ||
    coalesce(case when e.kurztext = ''unbekannt'' then ''''
    	else e.langtext||'' '' end , '''')
    ||
    coalesce(case when d.kurztext = ''unbekannt'' then ''''
    	else d.langtext end , ''''),'''')
from verundentsorgung.ka_lin_kabelnetz p
left join verundentsorgung.st_vw_verwendung c on p.id_st_vw_verwendung = c.id
left join verundentsorgung.st_vw_dimension d on p.id_st_vw_dimension = d.id
left join verundentsorgung.st_vw_kabeltyp e on p.id_st_vw_kabeltyp = e.id
where p.id = $id;', 'select $1 geometry', '0', '0', '481204fc-1702-44b7-b88b-833625d92509', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('5834de0c-de2d-4ac2-8419-54244904f826', '4', '36', 'Einleitungsstelle Name Symbol', 4, '4', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_einleitungsstellen', 'select
coalesce(CASE WHEN a.NAME_NUMBER IS NOT NULL AND (a.sohlhoehe IS NOT NULL AND a.sohlhoehe != 0) THEN
            a.NAME_NUMBER||'', ''||b.kurztext ||''\''
       else a.NAME_NUMBER||'', ''||b.kurztext 
       end, '''') ||
       coalesce(CASE WHEN a.sohlhoehe IS NOT NULL and a.sohlhoehe  != 0 THEN
            ''RSE: ''||trim(to_char(a.sohlhoehe ,''99990.00''))
       end, '''' ) as LABEL
FROM verundentsorgung.aw_pkt_einleitungsstellen a
left join verundentsorgung.st_vw_abwassereinleittyp b on b.id = a.id_st_vw_abwassereinleittyp 
WHERE a.id = $id;', 'select $1 geometry', '0', '0', '533acac3-d6c5-4744-9424-e8f6d8f2f496', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('744cbaad-e5bc-4853-afc6-2f91a8ce41a2', 'unbekannt', '114', 'Original(114)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_pkt_verbindungen', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (sohlhoehe != 0 or  okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       END , '''' )||
       coalesce(CASE WHEN okg != 0 AND okr !=0 THEN
            ''GH: ''||trim(to_char(okr,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       end, '''')  as 
       LABEL
FROM verundentsorgung.wa_pkt_verbindungen
WHERE id = $id;', 'select $1 geometry', '0', '0', 'e5ac6569-a923-491f-ba13-f7f0b00cfda5', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ae1058d7-aeec-4b3b-80bc-51f74911113b', 'unbekannt', '112', 'Orginal(112)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_fettabscheider', 'SELECT
  COALESCE(
    CASE WHEN NAME_NUMBER IS NOT NULL AND (OKHYD IS NOT NULL OR hoehe_okr IS NOT NULL)
      THEN NAME_NUMBER || ''\''
      ELSE NAME_NUMBER
    END, ''''
  )
  ||
  COALESCE(
    CASE
      WHEN OKHYD != 0 AND hoehe_okr != 0 THEN ''OKHY: '' || TRIM(TO_CHAR(OKHYD, ''99990.00'')) || ''\P''
      WHEN OKHYD != 0 THEN ''OKHY: '' || TRIM(TO_CHAR(OKHYD, ''99990.00''))
    END, ''''
  )
  ||
  COALESCE(
    CASE WHEN hoehe_okr != 0 THEN ''OKR: '' || TRIM(TO_CHAR(hoehe_okr, ''99990.00'')) END, ''''
  )
  AS label 
FROM verundentsorgung.wa_pkt_hydrant
WHERE ID = $id', 'select $1 geometry', '0', '0', 'e539c889-7331-4bd0-ab5e-bbbb2f60b08e', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('34a9b554-a557-4b46-b85d-2b823c309126', 'unbekannt', '104_wasserspiegel', 'Orginal(104)_wasserspiegel', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''WS: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_sonstige_anlage where ID = $id', 'select $1 geometry', '0', '0', '9a73a257-b9f5-4eeb-b62c-f23b14263c4a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('843a0c3f-2518-405d-85e0-2af029791c76', 'unbekannt', '10001_ka_schutzrohr', 'Kabel Schutzrohr', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'gws', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ka_pkt_schutzrohr', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( GH != 0 OR OK !=0 ) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN GH != 0 AND OK !=0 THEN
            ''GH: ''||GH||''\''
            WHEN  GH != 0 then
            ''GH: ''||GH
       end, '''') ||
       coalesce(CASE WHEN  OK !=0 THEN
            ''OK: ''||OK end, '''') as label
from verundentsorgung.ka_pkt_schutzrohr
where id = $id', 'select $1 geometry', '0', '0', '22910ce1-e0d3-49a7-befe-35afe0ab0919', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('0447b243-3c6a-4b3f-9362-9aed4a8040c9', 'unbekannt', '10000_ka_schutz', 'Schutzrohr Verwendung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'gws', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ka_lin_schutzrohr', 'select coalesce(    coalesce(case when c.kurztext = ''unbekannt'' then ''''
    	else c.langtext||'' '' end , '''') 
    ||
    coalesce(case when e.kurztext = ''unbekannt'' then ''''
    	else e.langtext||'' '' end , '''')
    ||
    coalesce(case when d.kurztext = ''unbekannt'' then ''''
    	else d.langtext end , ''''),'''')
from verundentsorgung.ka_lin_schutzrohr p
left join verundentsorgung.st_vw_verwendung c on p.id_st_vw_verwendung = c.id
left join verundentsorgung.st_vw_dimension d on p.id_st_vw_dimension = d.id
left join verundentsorgung.st_vw_kabeltyp e on p.id_st_vw_kabeltyp = e.id
where p.id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('fc9927f1-0ba7-4927-8800-6ae57cb7ed0b', 'unbekannt', '10004_ka_2', 'Mantelrohrbeschriftung_ka_schutzrohr', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'ka_lin_schutzrohr', 'select mantelrohrtext 
FROM verundentsorgung.ka_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('72f2fecc-e8d2-465f-88be-81dfb9bc0c0d', 'unbekannt', '10029_sr', 'Schutzrohr_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'gws', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_schutzrohr', 'select mantelrohrtext from 
verundentsorgung.wa_pkt_schutzrohr
 where id = $id;', 'select $1 geometry', '0', '0', 'e416ad01-b88d-42d3-be8c-6828bdd3c49a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9d55c9f7-5c3f-4a56-a42b-01bfb382bedc', 'unbekannt', '1007', 'BD: Leitung (STD)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_lin_wasserleitung', 'SELECT
  coalesce(CASE
    WHEN upper(b.kurztext) IN (''AZ'',''GG'',''GGG'',''STAHL'',''ST'',''UNBEKANNT'') THEN
      b.kurztext ||
      COALESCE('' '' || round(a.nennweite,0), '''')
    WHEN upper(b.kurztext) IN (''PE'',''PE 100'',''PE 100 TS'',''PE 100 RC'', ''PE 63'',''PE 80'',''PE-HD'',''PEX'',''PVC'',''KWK'',''ST'') THEN
      b.kurztext ||
      COALESCE(
        CASE WHEN a.aussendurchmesser::numeric > 0 THEN '' d '' || a.aussendurchmesser ELSE '''' END, ''''
      ) ||
      COALESCE(
        CASE WHEN a.wandstaerke::numeric > 0 THEN '' x '' || trim(to_char(a.wandstaerke::numeric,''9999990D00'')) ELSE '''' END, ''''
      ) ||
      COALESCE(
        CASE WHEN l.langtext = ''Horizontalspülbohrung'' THEN '' '' || l.langtext ELSE '''' END, ''''
      )
    ELSE NULL
  end) AS r
FROM verundentsorgung.wa_lin_wasserleitung a
LEFT JOIN verundentsorgung.st_vw_material    b ON a.id_st_vw_material = b.id
LEFT JOIN verundentsorgung.st_vw_verlegetyp  l ON a.id_st_vw_verlegetyp = l.id
WHERE a.id = $id;', 'select $1 geometry', '0', '0', 'c31890f0-4b91-403b-a9c2-7727189d498e', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('7a7498ad-deab-4feb-89a5-d310e1d126bc', '3', '42', 'Schacht  Symbol', 3, '3', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_schacht', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''')||coalesce(label_zusatz,'''')
       as LABEL
from verundentsorgung.aw_pkt_schacht 
where ID = $id;', 'select $1 geometry', '0', '0', '38dea46b-5dfb-4885-a0ed-e31b25fbdba0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('92254a89-1c73-4d21-8bfd-978b6813449e', '', '6', 'Verbindung Name_number', 15, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_verbindungen', 'select name_number ||coalesce(label_zusatz,'''')
from verundentsorgung.aw_pkt_verbindungen 
where id = $id', 'select $1 geometry', '0', '0', '2c491d08-ea29-4bf8-b0d3-49fed93ea66a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('711991df-c6f1-4f04-8263-23cd67bc2841', 'unbekannt', '10054', 'Verbindung Beschriftung NAME_NUMBER GH OKR', 15, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_verbindungen', 'select coalesce(NAME_NUMBER||
coalesce(''\''||case when okg != 0 then
''GH:''||to_char(okg,''99.99'') end, '''')||
coalesce(''\''||''OKR: ''||case when OKR !=0 then
to_char(OKR,''99.99'')end, '''') )||coalesce(label_zusatz,'''')  S 
from verundentsorgung.aw_pkt_verbindungen 
where  ID = $id and sohlhoehe  is not null 
and OKR is not null ', 'select $1 geometry', '0', '0', '2c491d08-ea29-4bf8-b0d3-49fed93ea66a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('64ee6d4d-8947-47f1-8e74-48f034813699', 'unbekannt', '15', 'Schutzrohr Ende Wasser', NULL, '003', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'wa_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre_gh"::numeric !=0 then a."sre_gh"::numeric end, '''' )
||
coalesce('' \OKR:''||case when a."sre_okr"::numeric !=0 then a."sre_okr"::numeric end, '''' )
FROM verundentsorgung.wa_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'e21dd3e6-c595-4a9a-a529-86dd78848332', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1d0da151-4c75-4731-8d7f-c7d8bcbfa09a', 'unbekannt', '1011', 'Orginal(1011)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'aw_pkt_benzinabscheider', 'SELECT
  COALESCE(
    CASE
      WHEN name_number IS NOT NULL AND (oks != 0 OR hoehe_okr != 0) THEN name_number || ''\P''
      ELSE name_number
    END, ''''
  )
  ||
  COALESCE(
    CASE
      WHEN oks != 0 AND hoehe_okr != 0 THEN ''OKS: '' || TRIM(TO_CHAR(oks, ''99990.00'')) || ''\P''
      WHEN oks != 0 THEN ''OKS: '' || TRIM(TO_CHAR(oks, ''99990.00''))
    END, ''''
  )
  ||
  COALESCE(
    CASE
      WHEN hoehe_okr != 0 THEN ''OKR: '' || TRIM(TO_CHAR(hoehe_okr, ''99990.00''))
    END, ''''
  ) AS label
FROM verundentsorgung.wa_pkt_schieber a
LEFT JOIN verundentsorgung.st_vw_schiebertyp b ON b.id = a.id_st_vw_schiebertyp
WHERE a.id = $id
  AND b.kurztext != ''HAPL'';', 'select $1 geometry', '0', '0', '91ec0230-08fd-416b-ac8f-68ec4c357b3e', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('661f052f-7e9a-499c-b7f0-769b6885adfa', 'unbekannt', '1011', 'Orginal(1011)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_benzinabscheider', 'SELECT
  COALESCE(
    CASE
      WHEN name_number IS NOT NULL AND (oks != 0 OR hoehe_okr != 0) THEN name_number || ''\P''
      ELSE name_number
    END, ''''
  )
  ||
  COALESCE(
    CASE
      WHEN oks != 0 AND hoehe_okr != 0 THEN ''OKS: '' || TRIM(TO_CHAR(oks, ''99990.00'')) || ''\P''
      WHEN oks != 0 THEN ''OKS: '' || TRIM(TO_CHAR(oks, ''99990.00''))
    END, ''''
  )
  ||
  COALESCE(
    CASE
      WHEN hoehe_okr != 0 THEN ''OKR: '' || TRIM(TO_CHAR(hoehe_okr, ''99990.00''))
    END, ''''
  ) AS label
FROM verundentsorgung.wa_pkt_schieber a
LEFT JOIN verundentsorgung.st_vw_schiebertyp b ON b.id = a.id_st_vw_schiebertyp
WHERE a.id = $id
  AND b.kurztext != ''HAPL'';', 'select $1 geometry', '0', '0', 'e2d99a8f-1c9f-4b4d-a210-35e064bdd576', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9ecb825f-e138-4419-98b4-480b7197d96c', '3', '10001', 'Name, Deckel- und Sohlhöhe (10001)', 3, '3', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000003', 'verundentsorgung', 'aw_pkt_schacht', 'SELECT coalesce(CASE WHEN M.NAME_NUMBER IS NOT NULL AND ( C.deckelhoehe  != 0 OR M.Sohlhoehe  !=0) THEN
            M.NAME_NUMBER||''\''
       else m.NAME_NUMBER
       end, '''' )||
       coalesce(CASE WHEN C.deckelhoehe  <> 0 AND M.Sohlhoehe !=0 THEN
            ''D: ''||trim(TO_CHAR(C.deckelhoehe ,''9990.00''))||''\''
            WHEN  C.deckelhoehe  != 0 THEN
            ''D: ''||trim(TO_CHAR(C.deckelhoehe ,''9990.00''))
       end, '''') ||
       coalesce(CASE WHEN  M.Sohlhoehe !=0 THEN
            ''S: ''||trim(TO_CHAR(M.Sohlhoehe,''990.00''))
       end, '''' )||coalesce(label_zusatz,'''')
       as label
FROM verundentsorgung.aw_pkt_schachtdeckel C, verundentsorgung.aw_pkt_schacht M WHERE name_number_objekt = M.name_number
and m.ID = $id', 'select $1 geometry', '0', '0', '5ca2e497-9bd7-42bb-aaab-8bd2e9a958f3', 'd9fa80ac-591f-4c23-b6d3-d9fe91e91596', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('57e7cc39-1ff8-4df4-a2d3-d3d1209d312c', 'unbekannt', '1019', 'Original VA', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000001', 'verundentsorgung', 'wa_pkt_schieber', 'SELECT 
  coalesce(
    CASE 
      WHEN name_number IS NOT NULL 
        AND (
          COALESCE(REPLACE(zvg_okva::text, '','', ''.'')::numeric, 0) != 0 OR 
          COALESCE(REPLACE(okr::text, '','', ''.'')::numeric, 0) != 0
        )
      THEN name_number || ''\''
      ELSE name_number
    END, ''''
  ) ||
  coalesce(
    CASE 
      WHEN COALESCE(REPLACE(zvg_okva::text, '','', ''.'')::numeric, 0) != 0 
        AND COALESCE(REPLACE(okr::text, '','', ''.'')::numeric, 0) != 0 THEN
          ''OKVA: '' || trim(to_char(REPLACE(zvg_okva::text, '','', ''.'')::numeric, ''99990.00'')) || ''\''
      WHEN COALESCE(REPLACE(zvg_okva::text, '','', ''.'')::numeric, 0) != 0 THEN
          ''OKVA: '' || trim(to_char(REPLACE(zvg_okva::text, '','', ''.'')::numeric, ''99990.00''))
    END, ''''
  ) ||
  coalesce(
    CASE 
      WHEN COALESCE(REPLACE(okr::text, '','', ''.'')::numeric, 0) != 0 THEN
        ''OKR: '' || trim(to_char(REPLACE(okr::text, '','', ''.'')::numeric, ''99990.00''))
    END, ''''
  ) AS label
FROM verundentsorgung.wa_pkt_schieber
WHERE id = $id
  AND id_st_vw_schiebertyp = ''bda881cd-bca9-4296-8db7-1f968d9eb3ef'';
', 'select $1 geometry', '0', '0', '63f0c549-5f24-4e69-90c6-33a2bf4513e4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1b022f95-89ee-4ada-b1b3-8147d5a2823a', 'deckelhoehe nicht geführt', '1032', 'Orginal(1032)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_koaleszenzabscheider', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and ((Z is not null and Z != 0) or ( okg is not null and okg !=0)) THEN
            NAME_NUMBER||''\P''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN Z IS NOT NULL AND Z != 0 AND Z IS NOT NULL AND Z !=0 THEN
            ''OKD: ''||trim(to_char(Z,''99990.00''))||''\P''
            WHEN Z IS NOT NULL and Z != 0 then
            ''OKD: ''||trim(to_char(Z,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okg IS NOT NULL and okg !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') as
       LABEL
from wa_pkt_schachtdeckel  where ID = $id;', 'select $1 geometry', '0', '0', 'fb66c593-1b6b-4c2f-bdfb-3c9822efd59a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('8ea7d53f-e281-4003-a455-da7521534074', '9', '214', 'Pumpe Name', 8, '8', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_pumpwerk', 'select max(coalesce(case when p.name_number is not null and ( c.deckelhoehe  != 0 or p.sohlhoehe !=0) then
            p.name_number||''\''
       else p.NAME_NUMBER
       end, '''') ||
       coalesce(case when c.deckelhoehe != 0 and p.sohlhoehe !=0 then
            ''D: ''||c.deckelhoehe||''\''
            WHEN  c.deckelhoehe != 0 then
            ''D: ''||c.deckelhoehe::numeric
       end, '''') ||
       coalesce(CASE WHEN  p.sohlhoehe !=0 THEN
            ''S: ''||p.sohlhoehe::numeric
       end, '''') 
)     as  label  
from verundentsorgung.aw_pkt_pumpwerk p, verundentsorgung.aw_pkt_schachtdeckel c 
where c.name_number_objekt = p.name_number
and p.id = $id', 'select $1 geometry', '0', '0', 'd22ebf13-23c4-4c3f-babf-c65ec1907462', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b8756eaf-3451-42a4-827d-d0d307c4eda5', '1', '10017', 'Kodierung, Station', 1, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_beobachtungspunkt', 'SELECT OBSERVATION_CODE || TO_CHAR(POSITION::numeric, ''99.0'')
FROM verundentsorgung.aw_pkt_beobachtungspunkt
WHERE POSITION::numeric < 100 AND ID = $id', 'select $1 geometry', '0', '0', '996a5b3e-c39b-4f73-a74e-861afa12fd38', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b6120033-2427-4c85-b48a-44d6390b558f', '4', '201', 'Einleitungsstelle Name', 4, '4', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_einleitungsstellen', 'select
coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (sohlhoehe IS NOT NULL AND sohlhoehe != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN sohlhoehe IS NOT NULL and sohlhoehe  != 0 THEN
            ''RSE: ''||trim(to_char(sohlhoehe ,''99990.00''))
       end, '''' ) as LABEL
FROM verundentsorgung.aw_pkt_einleitungsstellen
WHERE id = $id', 'select $1 geometry', '0', '0', '3f9b099d-fae6-4c27-afc8-15f75064443c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('970e74b1-0e9a-404d-9fea-a5b6533c23a6', 'unbekannt', '10005', 'Material, Profilart, Länge, Gefälle ', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_lin_haltung', 'select verundentsorgung.label_def($id)


', 'select $1 geometry', '0', '0', 'ba2d11ef-77d7-49fd-ab29-1f262daee092', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('7fc3f362-88a9-4a03-ac07-a4ad796790d7', 'unbekannt', 'zvg_wa_lin_bauwerkskante_dummy', 'zvg_wa_lin_bauwerkskante_dummy', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_lin_bauwerkskante', 'select $1 name_number', 'select $1 geometry', '0', '0', '42c776e5-8748-423b-ac8a-73c9816f271d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ae71e0a8-a0f9-4dc6-885e-7e80cef8e2ca', 'unbekannt', 'zvg_wa_lin_wasserleitung_dummy', 'zvg_wa_lin_wasserleitung_dummy', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_lin_wasserleitung', 'select $1 name_number', 'select $1 geometry', '0', '0', 'c31890f0-4b91-403b-a9c2-7727189d498e', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('3bacc6f4-4165-46bc-9481-52062c83ae79', 'unbekannt', '28', 'Druckmindere name _number ', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_druckminderer', 'select name_number 
from verundentsorgung.wa_pkt_druckminderer
where id = $id;', 'select $1 geometry', '0', '0', 'ae39eba3-8e62-461e-9425-2c4a965e7900', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('3cc45bea-bfed-4220-8cb2-91148c9b4fd7', 'unbekannt', '20', 'Pumpwerk', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_pumpwerk', 'select name_number 
from verundentsorgung.wa_pkt_pumpwerk
where id = $id;', 'select $1 geometry', '0', '0', '99708376-a2ef-405f-98e5-230af3d1d0f0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('bdc28ca8-40a4-47c5-8425-0295a1f6e425', 'unbekannt', '104', 'Orginal(104)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_sonstige_anlage where ID = $id', 'select $1 geometry', '0', '0', '9a73a257-b9f5-4eeb-b62c-f23b14263c4a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ad63e538-3416-4004-a904-8a5896a8eca1', 'unbekannt', 'zvg_wa_lin_schutzrohr_dummy', 'zvg_wa_lin_schutzrohr_dummy', NULL, '004', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_lin_schutzrohr', 'select $1 name_number', 'select $1 geometry', '0', '0', 'd1aeff45-1972-4ba2-97ea-af589dac5f6c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ac4602bb-c58a-413e-8be0-63268fb4b0ef', 'unbekannt', '18', 'Behaelter Symbol', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_behaelter', 'SELECT COALESCE(layout->>''pkt_symbolname'', '''')||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            NAME_NUMBER
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_behaelter 
where ID = $id;', 'select $1 geometry', '0', '0', 'ab489551-ad40-40dd-8674-446a7e515714', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b21d00b4-c0e1-4e23-ad36-d773dadefa12', 'unbekannt', '26', 'Brunnen Symbol', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_brunnen', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_brunnen  
where ID = $id;', 'select $1 geometry', '0', '0', '07994ab1-91b2-4bf6-84c1-fa393f083f42', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('f2151973-2778-4912-a748-6c59bbf1deaf', 'unbekannt', '10011', 'Komplexer Schacht-Anschrieb', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schacht', 'select verundentsorgung.label_schacht($id);', 'select $1 geometry', '0', '0', '38dea46b-5dfb-4885-a0ed-e31b25fbdba0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a6befda7-15aa-454a-b6af-4482ba8d07b3', '10', '10034', 'Becken Beschriftung', 9, '10', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_becken', 'SELECT  
  COALESCE(
    CASE 
      WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric IS NOT NULL) 
      THEN NAME_NUMBER || ''\'' 
      ELSE NAME_NUMBER 
    END, 
    ''''
  )
  ||
  COALESCE(
    CASE 
      WHEN OKG IS NOT NULL AND OKG::numeric is not null 
      THEN ''GH: '' || TRIM(TO_CHAR(OKG::numeric, ''99990.00'')) || ''\'' 
    END, 
    ''''
  ) AS label
FROM verundentsorgung.aw_pkt_becken
WHERE id = $id', 'select $1 geometry', '0', '0', 'aacd98bc-296f-4349-828f-a0e675727fe9', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('0c927b49-851d-482c-b040-0dc9ea72a73b', 'unbekannt', '128_wa', 'Schadensbeschriftung_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_wasserschaden', 'select NAME_NUMBER 
from verundentsorgung.wa_pkt_wasserschaden 
where ID = $id;', 'select $1 geometry', '0', '0', '45a8cd1c-a738-4234-841c-77b2fd9843e5', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('eeb1b1a3-c176-458d-b0c5-c936aa5978ed', 'unbekannt', 'zvg_wa_pkt_hausanschlusspunkt_dummy', 'zvg_wa_pkt_hausanschlusspunkt_dummy', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_hausanschlusspunkt', 'select $1 name_number', 'select $1 geometry', '0', '0', 'f1c82a68-fc8f-4ab1-8701-ed3da8ce8b1f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ab7d20b9-340e-4571-8d4b-4a0273710a98', 'unbekannt', '10053', 'Spühlhydrant - Bezeichnung', 17, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_spuehlhydrant', 'select NAME_NUMBER  from verundentsorgung.aw_pkt_spuehlhydrant where ID = $id

', 'select $1 geometry', '0', '0', 'bd947336-571e-475d-ab60-d0c20c9421bf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('f6fc565f-bc42-4b8d-87e4-5a76155f4e7a', 'gibt es gerade nicht', '118', 'Anlagenbeschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_wehr', 'SELECT name_number FROM wa_facility WHERE id = $id', 'select $1 geometry', '0', '0', '531a29c7-f87a-455e-a42b-6234c7587f14', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('2976ba4c-4c9b-4b15-8e21-3529d2e7fec1', 'unbekannt', '2', 'Loeschwasser', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_loeschwasserentnahmestelle', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG != 0 THEN
            ''GH: ''||trim(to_char(OKG ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_loeschwasserentnahmestelle
where ID = $id', 'select $1 geometry', '0', '0', '31ff9686-c314-4b55-a23a-721f2c70bb0a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('98f6297a-3686-472a-be4a-7ec252b15886', 'unbekannt', '101', 'Orginal(101)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schutzrohr', 'select ZVG_MANTELROHRTEXT  from WW_FITTING where FID = $id', 'select $1 geometry', '0', '0', 'ef24ad4e-e41a-4dbc-ac29-8fb18b179499', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('6fd239ae-20b7-4431-a54c-f28ba09344f3', 'unbekannt', '203', 'Verbindung label_dev', NULL, '003', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_verbindungen', 'select verundentsorgung.label_def_knoten($id)', 'select $1 geometry', '0', '0', '2c491d08-ea29-4bf8-b0d3-49fed93ea66a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d14353b7-6c62-400d-ad3c-a32c61689166', 'unbekannt', '17', 'wa druckstation', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_druckstation', 'SELECT COALESCE(layout->>''pkt_symbolname'', '''')||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            NAME_NUMBER
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_druckstation
where ID = id;', 'select $1 geometry', '0', '0', '43c9fed7-2e82-45e8-a7d8-f152ba573317', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('c07758b2-a0c0-4957-ba69-e50c5d0f9109', 'unbekannt', '128', 'Schadensbeschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schlammfang', 'select NAME_NUMBER from wa_pkt_wasserschaden  where ID = $id', 'select $1 geometry', '0', '0', '5125b950-7204-4707-bae8-b292eb100995', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('eacf27ea-1004-4930-bc26-606c2a9a1d4f', 'unbekannt', 'zvg_ka_pkt_kabelnetzknoten_dummy', 'zvg_ka_pkt_kabelnetzknoten_dummy', NULL, '009', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select mantelrohrtext 
FROM verundentsorgung.ka_pkt_kabelnetzknoten a
where id = $id;', 'select $1 geometry', '0', '0', '72c47630-bd3f-4999-8a2b-15f88a97a10f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('be2ee943-b661-4bc3-b17b-462df7aad290', '5', '216', 'Aufbereitungsanlage Name', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_klaeranlage', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric <> 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_klaeranlage WHERE id = $id', 'select $1 geometry', '0', '0', '4f532dd8-e7ea-48d8-9873-6e5f72b6f4d3', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('4ee5c2b5-20d3-4b21-825d-bcd656ec84ba', 'unbekannt', '112_wa', 'Original(112)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_hydrant', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (OKHYD != 0 or  hoehe_okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKHYD != 0 AND hoehe_okr !=0 THEN
            ''OKHY: ''||trim(to_char(OKHYD,''99990.00''))||''\''
            WHEN OKHYD != 0 THEN
            ''OKHY: ''||trim(to_char(OKHYD,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN hoehe_okr !=0 THEN
            ''OKR: ''||trim(to_char(hoehe_okr ,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_hydrant 
where ID = $id;', 'select $1 geometry', '0', '0', '57131dd6-c225-4fb9-b10e-22e395baac27', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('354c6219-64d8-4f5c-9497-22c1e333ef84', 'unbekannt', '217', 'Schieber Name', 12, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schieber', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( OKS != 0 OR OKR !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKS != 0 AND OKR !=0 THEN
            ''OKS: ''||OKS||''\''
            WHEN  OKS != 0 then
            ''OKS: ''||OKS
       end, '''') ||
       coalesce(CASE WHEN  OKR !=0 THEN
            ''OKR: ''||OKR
       end, '''') as  
       LABEL
from verundentsorgung.aw_pkt_schieber WHERE id = $id', 'select $1 geometry', '0', '0', '6a583623-5f05-48d4-bc06-de220cc1f522', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('234a6486-116c-403f-be27-c7928c27c8b1', '7', '10041', 'Komlexer Schacht-Anschrieb-Zuordnung', 6, '6', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schacht', 'select ID||coalesce(label_zusatz,'''') from verundentsorgung.aw_pkt_schacht where ID = $id', 'select $1 geometry', '0', '0', '38dea46b-5dfb-4885-a0ed-e31b25fbdba0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('2392e06c-dc7c-4a3e-8949-d6d143f16e53', '2', '10004', 'Fliesspfeil', 2, '002', '2025-04-30 15:53:48.256753+02', '2100-01-01 00:00:00+01', '2025-04-30 15:53:48.256753+02', 'unbekannt', '2025-04-30 15:53:48.256753+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_lin_haltung', 'select ''.'' from verundentsorgung.aw_lin_haltung 
where ID = $id;', 'SELECT round(degrees(st_azimuth(st_startpoint( $1 ), st_endpoint( $1 )))::numeric, 2) AS richtungswinkel, st_lineinterpolatepoint(st_makeline(st_startpoint( $1 ), st_endpoint( $1 )), 0.5::double precision) AS pkt_haltungsmitte WHERE ( $2  = ANY (ARRAY[''''Regenwasserkanal''''::text, ''''Schmutzwasserkanal''''::text, ''''Mischwasserkanal''''::text])) AND st_length( $1 ) > 5::double precision', '1', '1', 'ba2d11ef-77d7-49fd-ab29-1f262daee092', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b8bd600a-9aeb-4f87-bbf5-45d5c7a1d2b4', 'unbekannt', '212', 'Abscheider', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_abscheider', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (sohlhoehe  IS NOT NULL AND sohlhoehe  != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN sohlhoehe  IS NOT NULL and sohlhoehe  != 0 THEN
            ''GH: ''||trim(to_char(sohlhoehe  ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_abscheider where ID = $id', 'select $1 geometry', '0', '0', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('523246fa-e405-45c6-894d-6dd490c808d6', 'unbekannt', '10024', 'Sonstige Anlagen Name', NULL, '001', '2025-07-02 14:18:14.729696+02', '2100-01-01 00:00:00+01', '2025-07-02 14:18:14.729696+02', 'unbekannt', '2025-07-02 14:18:14.729696+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\P''
       else NAME_NUMBER
       end, '''') ||
      coalesce( CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\P''
       end, '''' )as LABEL
from aw_pkt_sonstige_anlage  where ID = $id', 'select $1 geometry', '0', '0', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('75ba8f6c-5d6c-4b2c-b7b8-455295c7b2d2', 'unbekannt', '10029', 'Verschiedenes Name_number', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_verschiedenes', 'select name_number 
 from verundentsorgung.wa_pkt_verschiedenes
  where ID = $id;', 'select $1 geometry', '0', '0', '355a01ba-2c37-4072-9f8c-8f05f8886d64', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9839dba1-b94f-4363-9edf-9c6f14a53c1a', 'unbekannt', '113', 'Orginal(113)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_hausanschlusspunkt', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '' '' 
       )
       ||
      coalesce( CASE WHEN okg != 0 AND okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, ''''
       )
       ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_hausanschlusspunkt
WHERE id = $id;
', 'select $1 geometry', '0', '0', 'f1c82a68-fc8f-4ab1-8701-ed3da8ce8b1f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('2da2b1f0-d4c0-40c8-8b7e-edb02b43f7ec', 'unbekannt', '1011_wa', 'Orginal(1011)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_schieber', 'select coalesce(case when name_number is not null and (oks  != 0 or  okr !=0) then
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN oks  != 0 AND okr !=0 THEN
            ''OKS: ''||trim(to_char(oks ,''99990.00''))||''\''
            WHEN oks  != 0 THEN
            ''OKS: ''||trim(to_char(oks ,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       end, '''') as
       LABEL
FROM verundentsorgung.wa_pkt_schieber
where id = $id
and id_st_vw_schiebertyp != ''bda881cd-bca9-4296-8db7-1f968d9eb3ef'';', 'select $1 geometry', '0', '0', '63f0c549-5f24-4e69-90c6-33a2bf4513e4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('032702eb-d8cc-4986-b146-7532d05c6dad', 'unbekannt', '1019_wa', 'Orginal VA(1019)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_schachtdeckel', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and ((deckelhoehe  is not null and deckelhoehe  != 0) or (okg is not null and okg !=0)) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN deckelhoehe IS NOT NULL AND deckelhoehe != 0 AND deckelhoehe IS NOT NULL AND deckelhoehe !=0 THEN
            ''OKD: ''||trim(to_char(deckelhoehe,''99990.00''))||''\''
            WHEN deckelhoehe IS NOT NULL and deckelhoehe != 0 then
            ''OKD: ''||trim(to_char(deckelhoehe,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okg IS NOT NULL and okg !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') as
       LABEL
from verundentsorgung.wa_pkt_schachtdeckel  where ID = $id;', 'select $1 geometry', '0', '0', 'f70f3426-e182-4cfc-91c9-d59d74a4b407', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('30bf9d9c-e9a0-417e-a76e-98421547c4a2', '3', '10001', 'Name, Deckel- und Sohlhöhe (10001)', 3, '3', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schacht', 'SELECT coalesce(CASE WHEN M.NAME_NUMBER IS NOT NULL AND ( C.deckelhoehe  != 0 OR M.Sohlhoehe  !=0) THEN
            M.NAME_NUMBER||''\''
       else m.NAME_NUMBER
       end, '''' )||
       coalesce(CASE WHEN C.deckelhoehe  <> 0 AND M.Sohlhoehe !=0 THEN
            ''D: ''||trim(TO_CHAR(C.deckelhoehe ,''9990.00''))||''\''
            WHEN  C.deckelhoehe  != 0 THEN
            ''D: ''||trim(TO_CHAR(C.deckelhoehe ,''9990.00''))
       end, '''') ||
       coalesce(CASE WHEN  M.Sohlhoehe !=0 THEN
            ''S: ''||trim(TO_CHAR(M.Sohlhoehe,''990.00''))
       end, '''' )||coalesce(label_zusatz,'''')
       as label
FROM verundentsorgung.aw_pkt_schachtdeckel C, verundentsorgung.aw_pkt_schacht M WHERE name_number_objekt = M.name_number
and m.ID = $id', 'select $1 geometry', '0', '0', '38dea46b-5dfb-4885-a0ed-e31b25fbdba0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('937465f0-b3de-4a0a-96cf-ca930f483ebe', 'unbekannt', '114_wa', 'Orginal(114)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_verbindungen', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 AND okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       END , '''')||coalesce(label_zusatz,'''')
       as LABEL
FROM verundentsorgung.wa_pkt_verbindungen 
WHERE id = $id;', 'select $1 geometry', '0', '0', '1b43644a-80ee-4908-b526-a20d6c10f051', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('35200535-2531-4b93-971b-77d89a087946', 'unbekannt', '101_wa', 'Orginal(101)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_armatur', 'select coalesce(case when name_number is not null and (okg != 0 or  okr !=0) then
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(case when okg  != 0 and okr !=0 then
            ''GH: ''||trim(to_char(okg ,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg ,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       end, '''') 
       as label
from verundentsorgung.wa_pkt_armatur 
WHERE id = $id;', 'select $1 geometry', '0', '0', 'ffc32c06-8ce2-44bf-9dd3-c7647572a665', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('cf4adce0-0289-4bf6-84af-dcc36e78f716', 'unbekannt', '104_wa', 'Original(104)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_entlueftung', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  hoehe_okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 AND hoehe_okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''')  ||
       coalesce(CASE WHEN hoehe_okr  !=0 THEN
            ''OKR: ''||trim(to_char(hoehe_okr,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_entlueftung 
WHERE id = $id;', 'select $1 geometry', '0', '0', 'f0f2c59c-4176-40b0-a282-911107e7bb9d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('800db879-0652-4617-9edb-409ff596f73a', '8', '10033', 'Auslauf Beschriftung', 7, '7', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_auslauf', 'SELECT
  coalesce(CASE 
    WHEN name_number IS NOT NULL AND (rsa IS NOT NULL AND rsa::numeric <> 0) THEN
      name_number || ''\''
    ELSE name_number
  end) ||
  coalesce(CASE 
    WHEN rsa IS NOT NULL AND rsa::numeric <> 0 THEN
      ''RSA: '' || TO_CHAR(rsa::numeric, ''99990.00'') || ''\''
    ELSE ''''
  end) AS label
FROM verundentsorgung.aw_pkt_auslauf
WHERE id = $id;', 'select $1 geometry', '0', '0', '7e081fd5-d024-4b94-8adb-dd803e466de2', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ec2d0dd1-d867-4887-9e6b-c022d6efd7d7', 'unbekannt', '107_wa', 'Orginal(107)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_wasserwerk', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and okr != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okr != 0 THEN
            ''OKR: ''||trim(to_char(okr ,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_wasserwerk 
WHERE id = $id;', 'select $1 geometry', '0', '0', '54efb464-b018-47c0-b76e-c72b71d65058', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('e490e253-b1b6-4c4c-bf9d-ac1fdd5ed95e', 'unbekannt', '10000_ta', 'Netz Beschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ta_lin_netz', 'select 
    coalesce(case when c.kurztext = ''unbekannt'' then ''''
    	else c.langtext||'' '' end , '''') 
    ||
    coalesce(case when e.kurztext = ''unbekannt'' then ''''
    	else e.langtext||'' '' end , '''')
    ||
    coalesce(case when d.kurztext = ''unbekannt'' then ''''
    	else d.langtext end , '''')
from verundentsorgung.ta_lin_netz p
left join verundentsorgung.st_vw_verwendung c on p.id_st_vw_verwendung = c.id
left join verundentsorgung.st_vw_dimension d on p.id_st_vw_dimension = d.id
left join verundentsorgung.st_vw_kabeltyp e on p.id_st_vw_kabeltyp = e.id
where p.id = $id;', 'select $1 geometry', '0', '0', 'd0a368f2-f577-400d-91ec-89db93b4ab21', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('e7986267-854b-409a-9a1c-a5311db596c8', 'unbekannt', '10002_ta', 'Netzknoten Beschriftung Schacht', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ta_pkt_netzknoten', 'select coalesce(CASE WHEN NAME_NUMBER like ''%'' AND ( deckelhoehe != 0 OR sohlhoehe !=0 ) THEN NAME_NUMBER||''\'' else NAME_NUMBER end, '''')
       ||
       coalesce(CASE WHEN deckelhoehe != 0 AND sohlhoehe !=0     THEN ''DH: ''||deckelhoehe||''\''
            WHEN deckelhoehe != 0 AND sohlhoehe is null THEN ''DH: ''||deckelhoehe  END , '''')
       ||
       coalesce(CASE WHEN sohlhoehe !=0 THEN ''SH: ''||sohlhoehe
       END , '''')
       as LABEL
from verundentsorgung.ta_pkt_netzknoten
where id = $id', 'select $1 geometry', '0', '0', '3b9a4c6d-f786-4a07-b765-587e2e93f13d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('0ee183c6-038b-47b4-87b1-0625d6e7de5f', 'unbekannt', '10006', 'Einlaufnummer', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_lin_haltung', 'select b.kurztext
 from verundentsorgung.aw_lin_haltung 
 a left join 
 verundentsorgung.st_vw_einlaufnummer b 
 on b.id = a.id_st_vw_einlaufnummer
 where a.id = $id;


', 'select $1 geometry', '0', '0', 'ba2d11ef-77d7-49fd-ab29-1f262daee092', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('327d0023-f06c-4057-8593-afec74852765', 'unbekannt', '10007', 'Auslaufnummer', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_lin_haltung', 'select b.kurztext
 from verundentsorgung.aw_lin_haltung 
 a left join 
 verundentsorgung.st_vw_auslaufnummer b 
 on b.id = a.id_st_vw_auslaufnummer
 where a.id = $id;


', 'select $1 geometry', '0', '0', 'ba2d11ef-77d7-49fd-ab29-1f262daee092', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('76c58d65-0b16-40c5-9568-c6c00e71bf1e', 'unbekannt', 'zvg_ta_lin_leitung_dummy', 'zvg_ta_lin_leitung_dummy', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'unbekannt', 'Fehlende Regel', 'select $1 geometry', '0', '0', '3b9a4c6d-f786-4a07-b765-587e2e93f13d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('64a22599-ab25-4dde-9c68-c4d67269f6e8', 'unbekannt', '11', 'Schutzrohr', NULL, '001', '2025-06-20 12:13:42.932352+02', '2100-01-01 00:00:00+01', '2025-06-20 12:13:42.932352+02', 'unbekannt', '2025-06-20 12:13:42.932352+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_lin_schutzrohr', 'SELECT 
    COALESCE(''SR '', '''') ||
    COALESCE(
        CASE 
            WHEN UPPER(b.kurztext) IN (''AZ'',''GG'',''GGG'',''ST'') THEN 
                COALESCE(b.kurztext, '''') || 
                CASE 
                    WHEN a.innendurchmesser IS NOT NULL THEN 
                        '' '' || COALESCE(a.innendurchmesser::text, '''') 
                    ELSE 
                        ''''
                END

            WHEN UPPER(b.kurztext) IN (''PE'',''PE 100'',''PE 100 TS'',''PE 63'',''PE 80'',''PE-HD'',''PEX'',''PVC'',''KWK'',''PE 100 RC'') THEN 
                COALESCE(b.kurztext, '''') ||
                CASE 
                    WHEN COALESCE(a.aussendurchmesser, 0) > 0 THEN 
                        '' d '' || COALESCE(a.aussendurchmesser::text, '''') 
                    ELSE 
                        ''''
                END ||
                CASE 
                    WHEN COALESCE(a.wandstaerke, 0) > 0 THEN 
                        '' x '' || COALESCE(a.wandstaerke::text, '''') 
                    ELSE 
                        ''''
                END

            ELSE 
                COALESCE(b.kurztext, '''')
        END,
    '''') AS bezeichnung, a.innendurchmesser, a.wandstaerke
FROM verundentsorgung.wa_lin_schutzrohr a
LEFT JOIN verundentsorgung.st_vw_material b 
    ON a.id_st_vw_material = b.id
            where a.ID = $id;', 'unbekannt', '0', '0', 'd1aeff45-1972-4ba2-97ea-af589dac5f6c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1eef7e5e-8293-4314-807d-8242312b84bd', 'unbekannt', '1031_wa', 'Orginal(1031)_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_schacht', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and ((deckelhoehe is not null and deckelhoehe != 0) or (gelaendehoehe  is not null and gelaendehoehe !=0)) THEN
            NAME_NUMBER||CHR(13)||CHR(10)
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN deckelhoehe IS NOT NULL AND deckelhoehe != 0 AND deckelhoehe IS NOT NULL AND deckelhoehe !=0 THEN
            ''OKD: ''||deckelhoehe||CHR(13)||CHR(10)
            WHEN deckelhoehe IS NOT NULL and deckelhoehe != 0 then
            ''OKD: ''||deckelhoehe
       end, '''') ||
       coalesce(CASE WHEN gelaendehoehe IS NOT NULL and gelaendehoehe !=0 THEN
            ''GH: ''||gelaendehoehe
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_schacht where ID = $id;', 'select $1 geometry', '0', '0', '40cf2570-764b-4c04-8420-935e1f549e82', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('5bcf45a2-51f5-46d6-8a81-ffd16c0c9d69', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'unbekannt', 'select ''x'' where 1=0;', 'select $1 geometry', '0', '0', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('6cda9bea-fd31-44fe-adce-6a22acdd2f02', 'unbekannt', '7', 'Schutzrohr Anfang', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra-gh" !=0 then a."sra-gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sra-okr" !=0 then a."sra-okr" end, '''' )
FROM verundentsorgung.aw_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '03407c80-04f4-4acd-810f-92f8d1762fff', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('371a8c36-ab1d-46a3-8224-6772907fde20', 'unbekannt', '8', 'Schutzrohr Ende', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre-gh" !=0 then a."sre-gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sre-okr" !=0 then a."sre-okr" end, '''' )
FROM verundentsorgung.aw_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '03407c80-04f4-4acd-810f-92f8d1762fff', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d29183fc-cac2-4036-875e-505794fefb94', 'unbekannt', '10001_ta', 'Netzknoten Beschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ta_pkt_netzknoten', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( GH != 0 OR OK !=0 ) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN GH != 0 AND OK !=0 THEN
            ''GH: ''||GH||''\''
            WHEN  GH != 0 then
            ''GH: ''||GH
       end, '''') ||
       coalesce(CASE WHEN  OK !=0 THEN
            ''OK: ''||OK end, '''') as label
from verundentsorgung.ta_pkt_netzknoten
where id = $id', 'select $1 geometry', '0', '0', '3b9a4c6d-f786-4a07-b765-587e2e93f13d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('343f2bbd-966b-4c2d-81b8-02206a89c13e', 'unbekannt', '107', 'Orginal(107)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_brunnen', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and okg != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, ''''
       )||
       coalesce(CASE WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg ,''99990.00''))
       end, ''''
       )
       as LABEL
FROM verundentsorgung.wa_pkt_brunnen 
WHERE id = $id', 'select $1 geometry', '0', '0', '07994ab1-91b2-4bf6-84c1-fa393f083f42', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ddf0d562-cd13-4b48-9113-d8ec93b7dec5', 'unbekannt', '110', 'Orginal(110)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_abscheider', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG != 0 THEN
            ''GH: ''||trim(to_char(OKG ,''99990.00''))||''\''
       end, '''') as  LABEL
from verundentsorgung.aw_pkt_abscheider WHERE id = $id', 'select $1 geometry', '0', '0', '36e23161-af70-46e2-88ea-2e83f0a25a73', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('8107b528-4b30-47d3-8b77-22331a5711b2', 'unbekannt', '105', 'Orginal(105)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_wasserzaehler', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (OKWZ != 0 or  hoehe_okr  !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKWZ != 0 AND hoehe_okr !=0 THEN
            ''GH: ''||trim(to_char(OKWZ,''99990.00''))||''\''
            WHEN OKWZ != 0 THEN
            ''GH: ''||trim(to_char(OKWZ,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN hoehe_okr !=0 THEN
            ''OKR: ''||trim(to_char(hoehe_okr,''99990.00''))
       end, '''') 
       as LABEL
FROM verundentsorgung.wa_pkt_wasserzaehler  WHERE id = $id;', 'select $1 geometry', '0', '0', '0a21fc84-121e-4160-89b3-b60c3b9b8fae', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('58e08d36-9994-4b24-81fa-c74f896287d8', 'unbekannt', '10035', 'Drossel/Dücker', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_dueker', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\P''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\P''
       end, '''') as LABEL
FROM verundentsorgung.aw_pkt_dueker
where ID = $id', 'select $1 geometry', '0', '0', '8b53ebc8-2091-4fb7-bf0c-8fb4ca7000da', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('5ff17416-d6f4-49d5-8f67-54b2e1e1ef69', 'unbekannt', '14', 'Schutzrohr Anfang Wasser', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra_gh"::numeric !=0 then a."sra_gh"::numeric end, '''' )
||
coalesce('' \OKR:''||case when a."sra_okr"::numeric !=0 then a."sra_okr"::numeric end, '''' )
FROM verundentsorgung.wa_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'd1aeff45-1972-4ba2-97ea-af589dac5f6c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a83bb6df-7244-4eb1-a201-54adc82c7e2a', 'unbekannt', '114_name_number', 'Verbindung_Name_number', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_verbindungen', 'select name_number ||coalesce(label_zusatz,'''')
FROM verundentsorgung.wa_pkt_verbindungen 
WHERE id = $id;', 'select $1 geometry', '0', '0', '1b43644a-80ee-4908-b526-a20d6c10f051', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('b9d90d2c-28e1-4187-8fe3-674f7f959158', '5', '218', 'Klaertank', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_klaertank', 'SELECT coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric <> 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''GH: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_klaertank WHERE id = $id', 'select $1 geometry', '0', '0', '684e1a37-3a3b-40fb-b5d3-7e53f75f9714', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('c77bea25-6a17-4ae9-af1b-368aa769e591', 'unbekannt', '1', 'Beprobungspunkt', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_beprobungspunkt', 'select name_number 
from verundentsorgung.wa_pkt_beprobungspunkt
where id = $id', 'select $1 geometry', '0', '0', 'c74eba4c-ed19-4200-a404-fa4944e835c3', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('2163c090-d376-433d-8223-9d895dd459f9', 'unbekannt', '3', 'Schachtdeckel', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schachtdeckel', 'select name_number 
from verundentsorgung.aw_pkt_schachtdeckel
where id = $id', 'select $1 geometry', '0', '0', '5fa42204-76d8-4587-98cd-0d11e72482f9', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9cb3406f-1333-4f8d-9641-dbefc9a256a2', 'unbekannt', '4', 'Schutzrohr.', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_lin_schutzrohr', 'SELECT 
  ''SR '' ||
  COALESCE(NULLIF(b.kurztext, ''unbekannt''), '''') ||
  '' DN '' ||
  COALESCE(a.nennweite::text, '''') AS bezeichnung
FROM verundentsorgung.aw_lin_schutzrohr a
LEFT JOIN verundentsorgung.st_vw_material b 
  ON a.id_st_vw_material = b.id
where a.id = $id', 'select $1 geometry', '0', '0', '03407c80-04f4-4acd-810f-92f8d1762fff', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d944093f-7b7c-4d1c-923b-186a4d871ac5', 'unbekannt', '22', 'Schacht Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_schacht', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_schacht  
where ID = $id;', 'select $1 geometry', '0', '0', '40cf2570-764b-4c04-8420-935e1f549e82', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('c4e4649a-0f89-4f1a-9e8d-b5cdbdb6ddde', 'unbekannt', '14_wa', 'Armatur Symbol', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_armatur', 'select coalesce(case when name_number is not null and (okg != 0 or  okr !=0) then
            NAME_NUMBER
       else NAME_NUMBER
       end, '''')||'', ''||COALESCE(layout->>''pkt_symbolname'', '''')
       as label
from verundentsorgung.wa_pkt_armatur 
WHERE id = $id;', 'select $1 geometry', '0', '0', 'ffc32c06-8ce2-44bf-9dd3-c7647572a665', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('bd3f8bd2-2530-479e-a92b-46265d7c7258', 'unbekannt', '109', 'Orginal(109)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_behaelter', 'SELECT COALESCE(CASE WHEN NAME_NUMBER IS NOT NULL and hoehe_okr != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
      COALESCE( CASE WHEN hoehe_okr != 0 THEN
            ''GH: ''||trim(to_char(hoehe_okr ,''99990.00''))
       END ,'''')
      as  LABEL
FROM verundentsorgung.wa_pkt_behaelter
WHERE id = $id;', 'select $1 geometry', '0', '0', 'ab489551-ad40-40dd-8674-446a7e515714', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d872493a-7ec8-4acc-88e5-df5a7f10abb7', 'unbekannt', '19', 'Hydrant Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_hydrant', 'SELECT Name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_hydrant  
where ID = $id;', 'select $1 geometry', '0', '0', '57131dd6-c225-4fb9-b10e-22e395baac27', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('64915720-f3c3-444b-a31d-1c9b5bc7b6d5', 'unbekannt', '21', 'Pumpwerk Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_pumpwerk', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_pumpwerk  
where ID = $id;', 'select $1 geometry', '0', '0', '99708376-a2ef-405f-98e5-230af3d1d0f0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('da94e65f-168a-4e40-849e-0656b92d1dd0', 'unbekannt', '23', 'Schieber Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_schieber', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_schieber  
where ID = $id;', 'select $1 geometry', '0', '0', '63f0c549-5f24-4e69-90c6-33a2bf4513e4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('faa3f0d6-5827-4b47-9cb4-45947524d2e0', 'unbekannt', '24', 'Verschiedenes Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_verschiedenes', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_verschiedenes  
where ID = $id;', 'select $1 geometry', '0', '0', '355a01ba-2c37-4072-9f8c-8f05f8886d64', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('bab22ee6-85ea-47b4-a217-818dffaa4f64', 'unbekannt', '25', 'Wasserzähler Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_wasserzaehler', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_wasserzaehler  
where ID = $id;', 'select $1 geometry', '0', '0', '0a21fc84-121e-4160-89b3-b60c3b9b8fae', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a9e2ae3c-1f24-4c3d-821a-4616672a9020', 'unbekannt', '27', 'Entlüftung Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_entlueftung', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.wa_pkt_entlueftung  
where ID = $id;', 'select $1 geometry', '0', '0', 'f0f2c59c-4176-40b0-a282-911107e7bb9d', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('689cc910-e164-403b-b9ac-d8993ccf8c7c', 'unbekannt', '1025_wa', 'Druckminderer Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_druckminderer', 'SELECT  COALESCE(layout->>''pkt_symbolname'', '''')||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and okg != 0 THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg ,''99990.00''))
       END , '''')
       as LABEL
from verundentsorgung.wa_pkt_druckminderer
where ID = $id;', 'select $1 geometry', '0', '0', 'ae39eba3-8e62-461e-9425-2c4a965e7900', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('fde44566-e355-4e82-9332-b7c1c9e54b40', 'unbekannt', '15', 'Schutzrohr Ende Wasser', NULL, '003', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre_gh"::numeric !=0 then a."sre_gh"::numeric end, '''' )
||
coalesce('' \OKR:''||case when a."sre_okr"::numeric !=0 then a."sre_okr"::numeric end, '''' )
FROM verundentsorgung.wa_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'd1aeff45-1972-4ba2-97ea-af589dac5f6c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('9143625c-070b-4f96-af76-523ee05e4072', 'unbekannt', '31', 'Abscheider Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_abscheider', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_abscheider 
where ID = $id;', 'select $1 geometry', '0', '0', '36e23161-af70-46e2-88ea-2e83f0a25a73', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('af4bfed1-339c-4d23-804c-40970ef1de39', 'unbekannt', '30', 'Schutzrohr Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schutzrohr', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_schutzrohr 
where ID = $id;', 'select $1 geometry', '0', '0', 'ef24ad4e-e41a-4dbc-ac29-8fb18b179499', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('db677c82-fd50-438d-8123-b212b7807ee4', 'unbekannt', '29', 'Abwasserschaden Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_abwasserschaden', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_abwasserschaden 
where ID = $id;', 'select $1 geometry', '0', '0', '5125b950-7204-4707-bae8-b292eb100995', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('59f7916a-1095-4fba-83ed-a396be6e68c2', '8', '32', 'Auslauf Symbol', 7, '7', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_auslauf', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_auslauf 
where ID = $id;', 'select $1 geometry', '0', '0', '7e081fd5-d024-4b94-8adb-dd803e466de2', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('599067fa-f099-4c2c-a09f-bf627e39378f', '1', '33', 'Beobachtungspunkte Symbol', 1, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_beobachtungspunkt', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_beobachtungspunkt 
where ID = $id;', 'select $1 geometry', '0', '0', '996a5b3e-c39b-4f73-a74e-861afa12fd38', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('5cf5440f-bdab-439d-8a65-0f3ac9be5c74', '10', '34', 'Becken Symbol', 9, '10', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_becken', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_becken 
where ID = $id;', 'select $1 geometry', '0', '0', 'aacd98bc-296f-4349-828f-a0e675727fe9', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('c9d14516-2880-479c-a559-c156c72604c6', 'unbekannt', '35', 'Drossel/Dücker Symbol', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_dueker', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_dueker 
where ID = $id;', 'select $1 geometry', '0', '0', '8b53ebc8-2091-4fb7-bf0c-8fb4ca7000da', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('e726cc87-1f26-4d27-b410-43c7a51807df', '9', '37', 'Pumpe Symbol', 8, '8', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_pumpwerk', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_pumpwerk 
where ID = $id;', 'select $1 geometry', '0', '0', 'd22ebf13-23c4-4c3f-babf-c65ec1907462', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('bab5ca99-dc26-4e02-838a-ad15da57d1e4', '5', '38', 'Klaertank Symbol', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_klaertank', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_klaertank 
where ID = $id;', 'select $1 geometry', '0', '0', '684e1a37-3a3b-40fb-b5d3-7e53f75f9714', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('a892779b-9f0a-4d7a-918f-f33ff55d91fe', '5', '39', 'Aufbereitungsanlage klaeranlage', 5, '5', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_klaeranlage', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_klaeranlage 
where ID = $id;', 'select $1 geometry', '0', '0', '4f532dd8-e7ea-48d8-9873-6e5f72b6f4d3', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('ab9ecff5-5a04-415f-b27c-a9034a00e6bf', 'unbekannt', '41', 'Schachtdeckel Symbole', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schachtdeckel', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_schachtdeckel
where ID = $id;', 'select $1 geometry', '0', '0', '5fa42204-76d8-4587-98cd-0d11e72482f9', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('0ff0c0a2-2094-49dc-a8a1-62d32216be32', 'unbekannt', '43', 'Schieber Symbole', 12, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schieber', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_schieber 
where ID = $id;', 'select $1 geometry', '0', '0', '6a583623-5f05-48d4-bc06-de220cc1f522', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('70ec1db9-b5ce-4deb-ae13-0527f795e944', 'unbekannt', '44', 'Sonstige Anlagen Symbole', NULL, '001', '2025-07-02 14:18:14.729696+02', '2100-01-01 00:00:00+01', '2025-07-02 14:18:14.729696+02', 'unbekannt', '2025-07-02 14:18:14.729696+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_sonstige_anlage
where ID = $id;', 'select $1 geometry', '0', '0', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('cdb576db-4426-4245-948f-e98277565573', 'unbekannt', '45', 'Spühlhydrant Symbole', 17, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_spuehlhydrant', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_spuehlhydrant 
where ID = $id;', 'select $1 geometry', '0', '0', 'bd947336-571e-475d-ab60-d0c20c9421bf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('104ea22f-4bd1-408e-b8a7-0fe26041c60b', '', '46', 'Verbindung Symbole', 15, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_verbindungen', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') ||coalesce(label_zusatz,'''')
       as LABEL
from verundentsorgung.aw_pkt_verbindungen 
where ID = $id;', 'select $1 geometry', '0', '0', '2c491d08-ea29-4bf8-b0d3-49fed93ea66a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('3b9ca88d-099e-4365-b71a-642a4533481a', 'unbekannt', '48', 'Loeschwasser Symbole', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_loeschwasserentnahmestelle', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''') 
       as LABEL
from verundentsorgung.aw_pkt_loeschwasserentnahmestelle 
where ID = $id;', 'select $1 geometry', '0', '0', '31ff9686-c314-4b55-a23a-721f2c70bb0a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('22346357-b323-47f9-bca5-c2291946e6a2', 'unbekannt', '10002_ka', 'KA Netzknoten', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select coalesce(CASE WHEN NAME_NUMBER like ''%'' AND ( deckelhoehe != 0 OR sohlhoehe !=0 ) THEN NAME_NUMBER||''\'' else NAME_NUMBER end, '''')
       ||
       coalesce(CASE WHEN deckelhoehe != 0 AND sohlhoehe !=0     THEN ''DH: ''||deckelhoehe||''\''
            WHEN deckelhoehe != 0 AND sohlhoehe is null THEN ''DH: ''||deckelhoehe  END , '''')
       ||
       coalesce(CASE WHEN sohlhoehe !=0 THEN ''SH: ''||sohlhoehe
       END , '''')
       as LABEL
from verundentsorgung.ka_pkt_kabelnetzknoten
where id = $id', 'select $1 geometry', '0', '0', '72c47630-bd3f-4999-8a2b-15f88a97a10f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('becb8202-1fd3-4f6d-a792-6b9bff16ff73', 'unbekannt', '10001_ka', 'Kabelnetknoten', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( GH != 0 OR OK !=0 ) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN GH != 0 AND OK !=0 THEN
            ''GH: ''||GH||''\''
            WHEN  GH != 0 then
            ''GH: ''||GH
       end, '''') ||
       coalesce(CASE WHEN  OK !=0 THEN
            ''OK: ''||OK end, '''') as label
from verundentsorgung.ka_pkt_kabelnetzknoten
where id = $id', 'select $1 geometry', '0', '0', '72c47630-bd3f-4999-8a2b-15f88a97a10f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('300c6377-2dd4-4af1-9588-ba58ad0c1b00', 'unbekannt', '23_aw', 'Name_number', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_lin_haltung', 'select name_number 
 from verundentsorgung.aw_lin_haltung 
 where id = $id;


', 'select $1 geometry', '0', '0', 'ba2d11ef-77d7-49fd-ab29-1f262daee092', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d433093d-7dc1-458b-8c5d-a69ea11cbe5b', 'unbekannt', '10004_ta', 'Mantelrohrbeschriftung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ta_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."gh" !=0 then a."gh" end, '''' )
||
coalesce('' \OKR:''||case when a."okr" !=0 then a."okr" end, '''' )
FROM verundentsorgung.ta_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('96e8a0be-f080-4d67-97fc-d1056ab8f74d', 'unbekannt', '10004_ka', 'Mantelrohrbeschriftung_ka', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ka_pkt_kabelnetzknoten', 'select mantelrohrtext 
FROM verundentsorgung.ka_pkt_kabelnetzknoten a
where id = $id;', 'select $1 geometry', '0', '0', '72c47630-bd3f-4999-8a2b-15f88a97a10f', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('60839525-1f8e-4154-af30-fd47498cfb72', 'unbekannt', '10000_ka', 'KA Netz', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ka_lin_kabelnetz', 'select coalesce(    coalesce(case when c.kurztext = ''unbekannt'' then ''''
    	else c.langtext||'' '' end , '''') 
    ||
    coalesce(case when e.kurztext = ''unbekannt'' then ''''
    	else e.langtext||'' '' end , '''')
    ||
    coalesce(case when d.kurztext = ''unbekannt'' then ''''
    	else d.langtext end , ''''),'''')
from verundentsorgung.ka_lin_kabelnetz p
left join verundentsorgung.st_vw_verwendung c on p.id_st_vw_verwendung = c.id
left join verundentsorgung.st_vw_dimension d on p.id_st_vw_dimension = d.id
left join verundentsorgung.st_vw_kabeltyp e on p.id_st_vw_kabeltyp = e.id
where p.id = $id;', 'select $1 geometry', '0', '0', '8fa9873a-0440-4c81-b5c7-e9d0067e40b7', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('39e19d0d-4025-4dbd-821a-1d6a21dda599', '4', '36', 'Einleitungsstelle Name Symbol', 4, '4', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_einleitungsstellen', 'select
coalesce(CASE WHEN a.NAME_NUMBER IS NOT NULL AND (a.sohlhoehe IS NOT NULL AND a.sohlhoehe != 0) THEN
            a.NAME_NUMBER||'', ''||b.kurztext ||''\''
       else a.NAME_NUMBER||'', ''||b.kurztext 
       end, '''') ||
       coalesce(CASE WHEN a.sohlhoehe IS NOT NULL and a.sohlhoehe  != 0 THEN
            ''RSE: ''||trim(to_char(a.sohlhoehe ,''99990.00''))
       end, '''' ) as LABEL
FROM verundentsorgung.aw_pkt_einleitungsstellen a
left join verundentsorgung.st_vw_abwassereinleittyp b on b.id = a.id_st_vw_abwassereinleittyp 
WHERE a.id = $id;', 'select $1 geometry', '0', '0', '3f9b099d-fae6-4c27-afc8-15f75064443c', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('6b380c37-22ed-44a2-bace-1870fb9d105d', 'unbekannt', '8_ta', 'Schutzrohr Ende..', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ta_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre_gh" !=0 then a."sre_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sre_okr" !=0 then a."sre_okr" end, '''' )
FROM verundentsorgung.ta_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d2f1a505-c095-4f4b-b3aa-2caefcf433a9', 'unbekannt', '7_ta', 'Schutzrohr Anfang..', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ta_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra_gh" !=0 then a."sra_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sra_okr" !=0 then a."sra_okr" end, '''' )
FROM verundentsorgung.ta_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1462ec53-0969-4880-9969-d711bf252526', 'unbekannt', '4_ta', 'Schutzrohr...', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ta_lin_schutzrohr', 'SELECT 
  COALESCE(NULLIF(c.kurztext, ''unbekannt''), '''') ||
  '' ST '' ||
  COALESCE(d.kurztext::text, '''') AS bezeichnung
FROM verundentsorgung.ta_lin_schutzrohr a
LEFT JOIN verundentsorgung.st_vw_material b 
  ON a.id_st_vw_material = b.id
LEFT JOIN verundentsorgung.st_vw_verwendung c
  ON a.id_st_vw_verwendung = c.id
LEFT JOIN verundentsorgung.st_vw_dimension d
  ON a.id_st_vw_dimension  = d.id  
where a.id = $id', 'select $1 geometry', '0', '0', 'b4b690a9-5916-42e0-84c8-74965ddbbcb4', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1823582b-f4c4-4501-91a7-c03fb38b1925', 'unbekannt', '7_ka', 'Schutzrohr Anfang.', NULL, '004', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ka_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sra_gh" !=0 then a."sra_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sra_okr" !=0 then a."sra_okr" end, '''' )
FROM verundentsorgung.ka_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('79286c83-3a94-4bc2-a269-f856a132b0fe', 'unbekannt', '8_ka', 'Schutzrohr Ende.', NULL, '003', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ka_lin_schutzrohr', 'select 
coalesce('' \GH:''||case when a."sre_gh" !=0 then a."sre_gh" end, '''' )
||
coalesce('' \OKR:''||case when a."sre_okr" !=0 then a."sre_okr" end, '''' )
FROM verundentsorgung.ka_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('51f77631-0b4e-4b2d-a577-3a6ad89108f1', 'unbekannt', '114', 'Original(114)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_verbindungen', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL and (okg != 0 or  okr !=0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN okg != 0 AND okr !=0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))||''\''
            WHEN okg != 0 THEN
            ''GH: ''||trim(to_char(okg,''99990.00''))
       end, '''') ||
       coalesce(CASE WHEN okr !=0 THEN
            ''OKR: ''||trim(to_char(okr,''99990.00''))
       END , '''')||coalesce(label_zusatz,'''')
       as LABEL
FROM verundentsorgung.wa_pkt_verbindungen 
WHERE id = $id;', 'select $1 geometry', '0', '0', '5125b950-7204-4707-bae8-b292eb100995', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('fac17e06-f50d-446f-8980-f58b20d7bf71', 'unbekannt', '112', 'Orginal(112)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_fettabscheider', 'SELECT
  COALESCE(
    CASE WHEN NAME_NUMBER IS NOT NULL AND (OKHYD IS NOT NULL OR hoehe_okr IS NOT NULL)
      THEN NAME_NUMBER || ''\''
      ELSE NAME_NUMBER
    END, ''''
  )
  ||
  COALESCE(
    CASE
      WHEN OKHYD != 0 AND hoehe_okr != 0 THEN ''OKHY: '' || TRIM(TO_CHAR(OKHYD, ''99990.00'')) || ''\P''
      WHEN OKHYD != 0 THEN ''OKHY: '' || TRIM(TO_CHAR(OKHYD, ''99990.00''))
    END, ''''
  )
  ||
  COALESCE(
    CASE WHEN hoehe_okr != 0 THEN ''OKR: '' || TRIM(TO_CHAR(hoehe_okr, ''99990.00'')) END, ''''
  )
  AS label 
FROM verundentsorgung.wa_pkt_hydrant
WHERE ID = $id', 'select $1 geometry', '0', '0', 'e539c889-7331-4bd0-ab5e-bbbb2f60b08e', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('900d5b56-4dcc-4e37-8508-38e353508a9e', 'unbekannt', '104_wasserspiegel', 'Orginal(104)_wasserspiegel', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'unbekannt', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_sonstige_anlage', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND (OKG IS NOT NULL AND OKG::numeric != 0) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN OKG IS NOT NULL and OKG::numeric != 0 THEN
            ''WS: ''||trim(to_char(OKG::numeric ,''99990.00''))||''\''
       end, '''') as LABEL
from verundentsorgung.aw_pkt_sonstige_anlage where ID = $id', 'select $1 geometry', '0', '0', '9a73a257-b9f5-4eeb-b62c-f23b14263c4a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('682a08b9-3a6b-4592-8ad2-12877ac6f3c8', 'unbekannt', '10001_ka_schutzrohr', 'Kabel Schutzrohr', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'gws', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ka_pkt_schutzrohr', 'select coalesce(CASE WHEN NAME_NUMBER IS NOT NULL AND ( GH != 0 OR OK !=0 ) THEN
            NAME_NUMBER||''\''
       else NAME_NUMBER
       end, '''') ||
       coalesce(CASE WHEN GH != 0 AND OK !=0 THEN
            ''GH: ''||GH||''\''
            WHEN  GH != 0 then
            ''GH: ''||GH
       end, '''') ||
       coalesce(CASE WHEN  OK !=0 THEN
            ''OK: ''||OK end, '''') as label
from verundentsorgung.ka_pkt_schutzrohr
where id = $id', 'select $1 geometry', '0', '0', '22910ce1-e0d3-49a7-befe-35afe0ab0919', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('23d1cbea-6a94-4ba8-8cf8-eed0a88dce7c', 'unbekannt', '10000_ka_schutz', 'Schutzrohr Verwendung', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'gws', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ka_lin_schutzrohr', 'select coalesce(    coalesce(case when c.kurztext = ''unbekannt'' then ''''
    	else c.langtext||'' '' end , '''') 
    ||
    coalesce(case when e.kurztext = ''unbekannt'' then ''''
    	else e.langtext||'' '' end , '''')
    ||
    coalesce(case when d.kurztext = ''unbekannt'' then ''''
    	else d.langtext end , ''''),'''')
from verundentsorgung.ka_lin_schutzrohr p
left join verundentsorgung.st_vw_verwendung c on p.id_st_vw_verwendung = c.id
left join verundentsorgung.st_vw_dimension d on p.id_st_vw_dimension = d.id
left join verundentsorgung.st_vw_kabeltyp e on p.id_st_vw_kabeltyp = e.id
where p.id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('1032aa48-9c9a-4e31-840f-885a009110f9', 'unbekannt', '10004_ka_2', 'Mantelrohrbeschriftung_ka_schutzrohr', NULL, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'ka_lin_schutzrohr', 'select mantelrohrtext 
FROM verundentsorgung.ka_lin_schutzrohr a
where id = $id;', 'select $1 geometry', '0', '0', '434bf10f-b587-4344-b6c3-fd2e3adf6fdf', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('190d538f-7fac-4c2b-8b27-092cc88c365e', 'unbekannt', '10029_sr', 'Schutzrohr_wa', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'gws', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_schutzrohr', 'select mantelrohrtext from 
verundentsorgung.wa_pkt_schutzrohr
 where id = $id;', 'select $1 geometry', '0', '0', 'e416ad01-b88d-42d3-be8c-6828bdd3c49a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('2e623aee-89dd-4d44-8ded-afec4478b771', 'unbekannt', '1007', 'BD: Leitung (STD)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_lin_wasserleitung', 'SELECT
  coalesce(CASE
    WHEN upper(b.kurztext) IN (''AZ'',''GG'',''GGG'',''STAHL'',''ST'',''UNBEKANNT'') THEN
      b.kurztext ||
      COALESCE('' '' || round(a.nennweite,0), '''')
    WHEN upper(b.kurztext) IN (''PE'',''PE 100'',''PE 100 TS'',''PE 100 RC'', ''PE 63'',''PE 80'',''PE-HD'',''PEX'',''PVC'',''KWK'',''ST'') THEN
      b.kurztext ||
      COALESCE(
        CASE WHEN a.aussendurchmesser::numeric > 0 THEN '' d '' || a.aussendurchmesser ELSE '''' END, ''''
      ) ||
      COALESCE(
        CASE WHEN a.wandstaerke::numeric > 0 THEN '' x '' || trim(to_char(a.wandstaerke::numeric,''9999990D00'')) ELSE '''' END, ''''
      ) ||
      COALESCE(
        CASE WHEN l.langtext = ''Horizontalspülbohrung'' THEN '' '' || l.langtext ELSE '''' END, ''''
      )
    ELSE NULL
  end) AS r
FROM verundentsorgung.wa_lin_wasserleitung a
LEFT JOIN verundentsorgung.st_vw_material    b ON a.id_st_vw_material = b.id
LEFT JOIN verundentsorgung.st_vw_verlegetyp  l ON a.id_st_vw_verlegetyp = l.id
WHERE a.id = $id;', 'select $1 geometry', '0', '0', 'c31890f0-4b91-403b-a9c2-7727189d498e', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('d17eef5b-31b5-4e3f-ac0e-83e9ad4b92ff', '3', '42', 'Schacht  Symbol', 3, '3', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_schacht', 'SELECT name_number||'', ''||coalesce(CASE WHEN NAME_NUMBER IS NOT NULL  THEN
            COALESCE(layout->>''pkt_symbolname'', '''')
       end, '''')||coalesce(label_zusatz,'''')
       as LABEL
from verundentsorgung.aw_pkt_schacht 
where ID = $id;', 'select $1 geometry', '0', '0', '38dea46b-5dfb-4885-a0ed-e31b25fbdba0', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('6f86d3ac-41a8-4cf0-b9d6-0b18b39f3b21', '', '6', 'Verbindung Name_number', 15, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_verbindungen', 'select name_number ||coalesce(label_zusatz,'''')
from verundentsorgung.aw_pkt_verbindungen 
where id = $id', 'select $1 geometry', '0', '0', '2c491d08-ea29-4bf8-b0d3-49fed93ea66a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('0c7657e8-07f1-416a-b8e2-657099cd9d75', 'unbekannt', '10054', 'Verbindung Beschriftung NAME_NUMBER GH OKR', 15, '002', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_verbindungen', 'select coalesce(NAME_NUMBER||
coalesce(''\''||case when okg != 0 then
''GH:''||to_char(okg,''99.99'') end, '''')||
coalesce(''\''||''OKR: ''||case when OKR !=0 then
to_char(OKR,''99.99'')end, '''') )||coalesce(label_zusatz,'''')  S 
from verundentsorgung.aw_pkt_verbindungen 
where  ID = $id and sohlhoehe  is not null 
and OKR is not null ', 'select $1 geometry', '0', '0', '2c491d08-ea29-4bf8-b0d3-49fed93ea66a', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('266e587b-59b4-4e22-837e-c66bb66055ef', 'unbekannt', '1011', 'Orginal(1011)', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'aw_pkt_benzinabscheider', 'SELECT
  COALESCE(
    CASE
      WHEN name_number IS NOT NULL AND (oks != 0 OR hoehe_okr != 0) THEN name_number || ''\P''
      ELSE name_number
    END, ''''
  )
  ||
  COALESCE(
    CASE
      WHEN oks != 0 AND hoehe_okr != 0 THEN ''OKS: '' || TRIM(TO_CHAR(oks, ''99990.00'')) || ''\P''
      WHEN oks != 0 THEN ''OKS: '' || TRIM(TO_CHAR(oks, ''99990.00''))
    END, ''''
  )
  ||
  COALESCE(
    CASE
      WHEN hoehe_okr != 0 THEN ''OKR: '' || TRIM(TO_CHAR(hoehe_okr, ''99990.00''))
    END, ''''
  ) AS label
FROM verundentsorgung.wa_pkt_schieber a
LEFT JOIN verundentsorgung.st_vw_schiebertyp b ON b.id = a.id_st_vw_schiebertyp
WHERE a.id = $id
  AND b.kurztext != ''HAPL'';', 'select $1 geometry', '0', '0', '91ec0230-08fd-416b-ac8f-68ec4c357b3e', '00000000-0000-0000-0000-000000000000', NULL);
INSERT INTO verundentsorgung.st_vw_label_definition (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt, table_schema, table_name, attributregel, geometrieregel, attributregel_aktivstatus, geometrieregel_aktivstatus, id_st_vw_objektbezeichnung, id_st_vw_labeltyp, name_number) VALUES ('e849d76f-4071-47ce-a33b-382abe98c4ba', 'unbekannt', '1019', 'Original VA', NULL, '001', '2025-04-30 10:45:50.063454+02', '2100-01-01 00:00:00+01', '2025-04-30 10:45:50.063454+02', 'unbekannt', '2025-04-30 10:45:50.063454+02', 'gws', '00000000-0000-0000-0000-000000000004', 'verundentsorgung', 'wa_pkt_schieber', 'SELECT 
  coalesce(
    CASE 
      WHEN name_number IS NOT NULL 
        AND (
          COALESCE(REPLACE(zvg_okva::text, '','', ''.'')::numeric, 0) != 0 OR 
          COALESCE(REPLACE(okr::text, '','', ''.'')::numeric, 0) != 0
        )
      THEN name_number || ''\''
      ELSE name_number
    END, ''''
  ) ||
  coalesce(
    CASE 
      WHEN COALESCE(REPLACE(zvg_okva::text, '','', ''.'')::numeric, 0) != 0 
        AND COALESCE(REPLACE(okr::text, '','', ''.'')::numeric, 0) != 0 THEN
          ''OKVA: '' || trim(to_char(REPLACE(zvg_okva::text, '','', ''.'')::numeric, ''99990.00'')) || ''\''
      WHEN COALESCE(REPLACE(zvg_okva::text, '','', ''.'')::numeric, 0) != 0 THEN
          ''OKVA: '' || trim(to_char(REPLACE(zvg_okva::text, '','', ''.'')::numeric, ''99990.00''))
    END, ''''
  ) ||
  coalesce(
    CASE 
      WHEN COALESCE(REPLACE(okr::text, '','', ''.'')::numeric, 0) != 0 THEN
        ''OKR: '' || trim(to_char(REPLACE(okr::text, '','', ''.'')::numeric, ''99990.00''))
    END, ''''
  ) AS label
FROM verundentsorgung.wa_pkt_schieber
WHERE id = $id
  AND id_st_vw_schiebertyp = ''bda881cd-bca9-4296-8db7-1f968d9eb3ef'';
', 'select $1 geometry', '0', '0', '63f0c549-5f24-4e69-90c6-33a2bf4513e4', '00000000-0000-0000-0000-000000000000', NULL);


-- Completed on 2026-09-17 14:21:43

--
-- PostgreSQL database dump complete
--


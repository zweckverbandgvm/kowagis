--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:22:46

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 39685781)
-- Dependencies: 12373
-- Data for Name: st_vw_verschiedenes; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2024-08-07 08:33:32.464169+02', '2100-01-01 00:00:00+01', '2024-08-07 08:33:32.464169+02', 'unbekannt', '2024-08-07 08:33:32.464169+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('1e70affa-993f-4d5c-aa6a-01a4f3fef907', 'unbekannt', 'DUEK', 'Düker', NULL, '001', '2024-08-28 10:01:09.578882+02', '2100-01-01 00:00:00+01', '2024-08-28 10:01:09.578882+02', 'unbekannt', '2024-08-28 10:01:09.578882+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('2296a6dc-68c5-4cd8-ae56-d35b7e86f9b0', 'unbekannt', 'MAROA', 'Schutzrohr', NULL, '001', '2024-08-28 10:01:09.578882+02', '2100-01-01 00:00:00+01', '2024-08-28 10:01:09.578882+02', 'unbekannt', '2024-08-28 10:01:09.578882+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('84c13492-4e23-46fc-9f34-b0dc76a85b5b', 'unbekannt', 'MP', 'Markierungspfosten', NULL, '001', '2024-08-28 10:01:09.578882+02', '2100-01-01 00:00:00+01', '2024-08-28 10:01:09.578882+02', 'unbekannt', '2024-08-28 10:01:09.578882+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('5393ed9e-3cf5-4b67-b625-c1d318839520', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('f95d45f4-6b02-4ef7-b313-4edec1145767', 'unbekannt', 'DUEK', 'Düker', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('1397fdb3-241b-4146-9f85-2418fc3e9f47', 'unbekannt', 'MAROA', 'Schutzrohr', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('6d618bb4-31b9-4c7c-b978-3d4a0cd41f55', 'unbekannt', 'MP', 'Markierungspfosten', NULL, '001', '2025-09-23 15:35:53.417656+02', '2100-01-01 00:00:00+01', '2025-09-23 15:35:53.417656+02', 'unbekannt', '2025-09-23 15:35:53.417656+02', 'unbekannt', '00000000-0000-0000-0000-000000000003');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('8b4c819f-f5cb-4680-91d2-56fc960bfe71', 'unbekannt', 'unbekannt', 'unbekannt', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('bb31ee36-39db-4792-bb0a-0a9082fbebc2', 'unbekannt', 'DUEK', 'Düker', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('1bd26685-ded0-4e9c-8b43-aca140c47f2e', 'unbekannt', 'MAROA', 'Schutzrohr', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_verschiedenes (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('37801b01-9bb5-4d3d-986a-41b78b91260a', 'unbekannt', 'MP', 'Markierungspfosten', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:22:48

--
-- PostgreSQL database dump complete
--


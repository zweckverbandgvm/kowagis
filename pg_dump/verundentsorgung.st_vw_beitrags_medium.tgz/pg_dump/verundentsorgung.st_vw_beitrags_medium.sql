--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 17.3

-- Started on 2026-09-17 14:20:13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 96769 (class 0 OID 62252977)
-- Dependencies: 22824
-- Data for Name: st_vw_beitrags_medium; Type: TABLE DATA; Schema: verundentsorgung; Owner: -
--

INSERT INTO verundentsorgung.st_vw_beitrags_medium (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('00000000-0000-0000-0000-000000000000', 'unbekannt', 'unbekannt', 'unbekannt', 'noch keine Bemerkung', '001', '2022-12-20 23:51:09.192732+01', '2100-01-01 00:00:00+01', '2022-12-20 23:51:09.192732+01', 'unbekannt', '2022-12-20 23:51:09.192732+01', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beitrags_medium (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('beaf7704-1503-487e-a695-59cefaeaef36', 'unbekannt', 'RW', 'RW', NULL, '001', '2026-04-14 16:30:29.453561+02', '2100-01-01 00:00:00+01', '2026-04-14 16:30:29.453561+02', 'unbekannt', '2026-04-14 16:30:29.453561+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beitrags_medium (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('66832682-58fc-4d97-87a0-ebf39c658390', 'unbekannt', 'KEIN', 'KEIN', NULL, '001', '2026-04-14 16:30:29.453561+02', '2100-01-01 00:00:00+01', '2026-04-14 16:30:29.453561+02', 'unbekannt', '2026-04-14 16:30:29.453561+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beitrags_medium (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('04d2a42a-d79c-4076-aa65-ac0b78177170', 'unbekannt', 'SWRW', 'SWRW', NULL, '001', '2026-04-14 16:30:29.453561+02', '2100-01-01 00:00:00+01', '2026-04-14 16:30:29.453561+02', 'unbekannt', '2026-04-14 16:30:29.453561+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beitrags_medium (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('9ae7e9f5-ca6e-45b7-b911-e7e92df9ff7d', 'unbekannt', 'SW', 'SW', NULL, '001', '2026-04-14 16:30:29.453561+02', '2100-01-01 00:00:00+01', '2026-04-14 16:30:29.453561+02', 'unbekannt', '2026-04-14 16:30:29.453561+02', 'unbekannt', '00000000-0000-0000-0000-000000000001');
INSERT INTO verundentsorgung.st_vw_beitrags_medium (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('d4e88940-9c6d-461b-a234-6d9c15134491', 'unbekannt', 'unbekannt', 'unbekannt', 'noch keine Bemerkung', '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beitrags_medium (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('d57a9cd1-edd0-413d-86a5-c897f6054f34', 'unbekannt', 'RW', 'RW', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beitrags_medium (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('239ca7c4-2225-4076-b5ce-89b82fa46709', 'unbekannt', 'KEIN', 'KEIN', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beitrags_medium (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('dffff5ce-846e-4a33-8140-dea2b77a973e', 'unbekannt', 'SWRW', 'SWRW', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');
INSERT INTO verundentsorgung.st_vw_beitrags_medium (id, ident_hist, kurztext, langtext, bemerkung, sortierreihenfolge, gueltig_von, gueltig_bis, angelegt_am, angelegt_von, geaendert_am, geaendert_von, id_st_vw_projekt) VALUES ('551d07f2-4e9c-4b9e-8ad9-698df5469fb5', 'unbekannt', 'SW', 'SW', NULL, '001', '2026-08-10 09:34:42.604071+02', '2100-01-01 00:00:00+01', '2026-08-10 09:34:42.604071+02', 'unbekannt', '2026-08-10 09:34:42.604071+02', 'unbekannt', '00000000-0000-0000-0000-000000000004');


-- Completed on 2026-09-17 14:20:15

--
-- PostgreSQL database dump complete
--

